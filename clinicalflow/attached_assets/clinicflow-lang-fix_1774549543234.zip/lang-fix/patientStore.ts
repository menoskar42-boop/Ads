import { Patient } from '@/types';
import { createStore } from './createStore';
import { CLINIC_IDS } from './clinicStore';

// ── localStorage key ──────────────────────────────────────────────────────────
const LS_KEY = 'cf_registered_patients';

// ── Load any previously registered patients from localStorage ────────────────
function loadRegisteredPatients(): Patient[] {
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (!raw) return [];
    return JSON.parse(raw) as Patient[];
  } catch {
    return [];
  }
}

// ── Save a new patient to localStorage ───────────────────────────────────────
export function persistPatient(patient: Patient): void {
  try {
    const existing = loadRegisteredPatients();
    if (existing.some(p => p.id === patient.id)) return;
    localStorage.setItem(LS_KEY, JSON.stringify([...existing, patient]));
  } catch {
    // localStorage unavailable — graceful degradation
  }
}

// ── Seed data ─────────────────────────────────────────────────────────────────
const mockPatients: Patient[] = [
  { id: 'pt-demo', name: 'Mahmoud Saber', nameAr: 'محمود صابر', phone: '01000000000', email: 'mahmoud.saber@email.com', dateOfBirth: '1990-01-15', gender: 'male', createdAt: '2024-01-01' },
  { id: 'pt-1',  name: 'Ahmed Mohamed',   nameAr: 'أحمد محمد',      phone: '01011111101', dateOfBirth: '1979-05-20', gender: 'male',   nationalId: 'ID-001', clinicId: CLINIC_IDS.NILE_MEDICAL, createdAt: '2023-06-10' },
  { id: 'pt-2',  name: 'Sara Hassan',     nameAr: 'سارة حسن',        phone: '01011111102', dateOfBirth: '1992-03-15', gender: 'female',                       clinicId: CLINIC_IDS.NILE_MEDICAL, createdAt: '2023-08-22' },
  { id: 'pt-3',  name: 'Mohamed Ali',     nameAr: 'محمد علي',         phone: '01011111103', dateOfBirth: '1966-08-10', gender: 'male',   nationalId: 'ID-003', clinicId: CLINIC_IDS.NILE_MEDICAL, createdAt: '2023-03-15' },
  { id: 'pt-4',  name: 'Fatma Ibrahim',   nameAr: 'فاطمة إبراهيم',   phone: '01011111104', dateOfBirth: '1996-01-25', gender: 'female',                       clinicId: CLINIC_IDS.NILE_MEDICAL, createdAt: '2023-11-05' },
  { id: 'pt-5',  name: 'Khaled Samir',    nameAr: 'خالد سمير',        phone: '01011111105', dateOfBirth: '1962-11-30', gender: 'male',                         clinicId: CLINIC_IDS.NILE_MEDICAL, createdAt: '2022-12-01' },
  { id: 'pt-6',  name: 'Noha Kamel',      nameAr: 'نها كامل',         phone: '01011111106', dateOfBirth: '1983-07-12', gender: 'female',                       clinicId: CLINIC_IDS.NILE_MEDICAL, createdAt: '2023-09-18' },
  { id: 'pt-7',  name: 'Omar Khalil',     nameAr: 'عمر خليل',         phone: '01011111107', dateOfBirth: '1989-04-05', gender: 'male',                         clinicId: CLINIC_IDS.NILE_MEDICAL, createdAt: '2023-07-30' },
  { id: 'pt-8',  name: 'Layla Ahmed',     nameAr: 'ليلى أحمد',        phone: '01011111108', dateOfBirth: '1995-09-18', gender: 'female',                       clinicId: CLINIC_IDS.NILE_MEDICAL, createdAt: '2024-01-02' },
  { id: 'pt-20', name: 'Ali Hassan',      nameAr: 'علي حسن',          phone: '01022222201', dateOfBirth: '1985-03-10', gender: 'male',                         clinicId: CLINIC_IDS.CAIRO_HEALTH, createdAt: '2024-04-01' },
  { id: 'pt-21', name: 'Nadia Mostafa',   nameAr: 'ناديا مصطفى',     phone: '01022222202', dateOfBirth: '1991-07-22', gender: 'female',                       clinicId: CLINIC_IDS.CAIRO_HEALTH, createdAt: '2024-04-15' },
  { id: 'pt-22', name: 'Youssef Ramadan', nameAr: 'يوسف رمضان',      phone: '01022222203', dateOfBirth: '1975-11-05', gender: 'male',                         clinicId: CLINIC_IDS.CAIRO_HEALTH, createdAt: '2024-05-02' },
  { id: 'pt-30', name: 'Samira Aziz',     nameAr: 'سميرة عزيز',       phone: '01033333301', dateOfBirth: '1988-01-15', gender: 'female',                       clinicId: CLINIC_IDS.ALEX_CARE,    createdAt: '2024-06-12' },
  { id: 'pt-31', name: 'Hassan El-Sayed', nameAr: 'حسن السيد',         phone: '01033333302', dateOfBirth: '1972-09-30', gender: 'male',                         clinicId: CLINIC_IDS.ALEX_CARE,    createdAt: '2024-07-01' },
];

// ── Merge seed + persisted patients (no duplicates) ───────────────────────────
const persistedPatients = loadRegisteredPatients();
const allInitialPatients = [
  ...mockPatients,
  ...persistedPatients.filter(p => !mockPatients.some(m => m.id === p.id)),
];

export const patientStore = createStore<Patient>(allInitialPatients);
