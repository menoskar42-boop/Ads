import React, { createContext, useContext, useState, ReactNode } from 'react';
import { UserRole, Patient } from '@/types';
import { userStore } from '@/stores/userStore';
import { patientStore } from '@/stores/patientStore';
import { getClinicsForDoctor } from '@/stores/doctorClinicStore';
import { registrationStore } from '@/stores/registrationStore';

export interface AuthUser {
  id: string;
  name: string;
  nameAr: string;
  email: string;
  role: UserRole | 'patient' | 'super_admin';
  specialtyId?: string;
  patientId?: string;
  clinicId: string;
}

interface AuthContextType {
  user: AuthUser | null;
  pendingDoctorClinics: string[] | null;
  pendingDoctorUser: AuthUser | null;
  // Original tab-based methods
  login: (clinicId: string, role: UserRole) => void;
  loginAsSuperAdmin: (password: string) => boolean;
  loginAsPatient: (identifier: string) => boolean;
  // Unified email+password login (works for all roles + registered users)
  loginWithEmail: (email: string, password: string) => Promise<{ ok: boolean; error?: string }>;
  registerPatient: (data: { name: string; phone: string; email: string; password: string }) => boolean;
  selectClinicForDoctor: (clinicId: string) => void;
  switchClinic: () => void;
  logout: () => void;
  isAuthenticated: boolean;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const SUPER_ADMIN_PASSWORD = 'superadmin2024';

// Pre-seeded demo passwords for existing mock users
const passwordStore: Record<string, string> = {
  'u-1':    'admin123',
  'u-2':    'doctor123',
  'u-3':    'doctor123',
  'u-4':    'doctor123',
  'u-5':    'doctor123',
  'u-6':    'reception123',
  'u-10':   'admin123',
  'u-11':   'doctor123',
  'u-12':   'reception123',
  'u-20':   'admin123',
  'u-21':   'doctor123',
  'u-22':   'reception123',
  'pt-demo': 'patient123',
};

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser]                         = useState<AuthUser | null>(null);
  const [pendingDoctorClinics, setPendingDoctorClinics] = useState<string[] | null>(null);
  const [pendingDoctorUser, setPendingDoctorUser]       = useState<AuthUser | null>(null);
  const [isLoading, setIsLoading]               = useState(false);

  // ─── loginWithEmail ───────────────────────────────────────────────────────
  // Works for: patients in patientStore, patients in registrationStore,
  // staff users in userStore, and super admin.
  const loginWithEmail = async (
    email: string,
    password: string,
  ): Promise<{ ok: boolean; error?: string }> => {
    setIsLoading(true);
    await new Promise(r => setTimeout(r, 350)); // brief UX delay
    setIsLoading(false);

    const trimmed = email.trim().toLowerCase();

    // 1. Super Admin
    if (trimmed === 'superadmin@clinicflow.io') {
      if (password === SUPER_ADMIN_PASSWORD) {
        setUser({
          id: 'super-admin', name: 'Super Admin', nameAr: 'المدير العام',
          email: 'superadmin@clinicflow.io', role: 'super_admin', clinicId: 'super',
        });
        return { ok: true };
      }
      return { ok: false, error: 'Incorrect password.' };
    }

    // 2. Staff users (userStore)
    const staffUser = userStore.get(u => u.email.toLowerCase() === trimmed && u.isActive);
    if (staffUser) {
      const stored = passwordStore[staffUser.id];
      if (stored && stored !== password) {
        return { ok: false, error: 'Incorrect password.' };
      }
      if (!stored) passwordStore[staffUser.id] = password; // save on first login
      const authUser: AuthUser = {
        id: staffUser.id, name: staffUser.name, nameAr: staffUser.nameAr,
        email: staffUser.email, role: staffUser.role,
        specialtyId: staffUser.specialtyId, clinicId: staffUser.clinicId,
      };
      if (staffUser.role === 'doctor') {
        const links = getClinicsForDoctor(staffUser.id);
        if (links.length > 1) {
          setPendingDoctorUser(authUser);
          setPendingDoctorClinics(links);
          return { ok: true };
        }
      }
      setUser(authUser);
      return { ok: true };
    }

    // 3. Patients in patientStore
    const patient = patientStore.get(p => p.email?.toLowerCase() === trimmed);
    if (patient) {
      const stored = passwordStore[patient.id];
      if (stored && stored !== password) {
        return { ok: false, error: 'Incorrect password.' };
      }
      if (!stored) passwordStore[patient.id] = password;
      setUser({
        id: patient.id, name: patient.name, nameAr: patient.nameAr,
        email: patient.email || '', role: 'patient',
        patientId: patient.id, clinicId: patient.clinicId ?? '',
      });
      return { ok: true };
    }

    // 4. Newly registered users in registrationStore
    //    (RegisterPage saves here but NOT in patientStore)
    const reg = registrationStore.get(r => r.email.toLowerCase() === trimmed);
    if (reg) {
      // Verify password stored in registration entry
      if (reg.password && reg.password !== password) {
        return { ok: false, error: 'Incorrect password.' };
      }

      if (reg.type === 'patient') {
        // Promote to patientStore so future logins are faster
        const existing = patientStore.get(p => p.email?.toLowerCase() === trimmed);
        if (!existing) {
          const newPatient: Patient = {
            id:          reg.userId || `pt-${Date.now()}`,
            name:        reg.name,
            nameAr:      reg.name,
            phone:       reg.phone,
            email:       reg.email,
            dateOfBirth: '',
            gender:      'male',
            createdAt:   reg.createdAt,
          };
          patientStore.add(newPatient);
          if (reg.password) passwordStore[newPatient.id] = reg.password;
          setUser({
            id: newPatient.id, name: newPatient.name, nameAr: newPatient.nameAr,
            email: newPatient.email || '', role: 'patient',
            patientId: newPatient.id, clinicId: '',
          });
        } else {
          setUser({
            id: existing.id, name: existing.name, nameAr: existing.nameAr,
            email: existing.email || '', role: 'patient',
            patientId: existing.id, clinicId: existing.clinicId ?? '',
          });
        }
        return { ok: true };
      }

      // Doctor / Clinic registered — not yet approved, show pending message
      if (reg.type === 'doctor' || reg.type === 'clinic') {
        return {
          ok: false,
          error: 'Your registration is pending approval. You will receive an email when your account is activated.',
        };
      }
    }

    return { ok: false, error: 'No account found with this email.' };
  };

  // ─── Original methods (kept for backward compat) ──────────────────────────

  const login = (clinicId: string, role: UserRole) => {
    const storeUser = userStore.get(u => u.clinicId === clinicId && u.role === role && u.isActive);
    if (!storeUser) return;
    const authUser: AuthUser = {
      id: storeUser.id, name: storeUser.name, nameAr: storeUser.nameAr,
      email: storeUser.email, role: storeUser.role,
      specialtyId: storeUser.specialtyId, clinicId: storeUser.clinicId,
    };
    if (role === 'doctor') {
      const links = getClinicsForDoctor(storeUser.id);
      if (links.length > 1) {
        setPendingDoctorUser(authUser);
        setPendingDoctorClinics(links);
        return;
      }
    }
    setUser(authUser);
  };

  const selectClinicForDoctor = (clinicId: string) => {
    if (!pendingDoctorUser) return;
    const d = userStore.get(u => u.clinicId === clinicId && u.role === 'doctor' && u.isActive);
    setUser({ ...pendingDoctorUser, clinicId, specialtyId: d?.specialtyId ?? pendingDoctorUser.specialtyId });
    setPendingDoctorClinics(null);
    setPendingDoctorUser(null);
  };

  const switchClinic = () => {
    if (!user || user.role !== 'doctor') return;
    const links = getClinicsForDoctor(user.id);
    if (links.length > 1) {
      setPendingDoctorUser(user);
      setPendingDoctorClinics(links);
      setUser(null);
    }
  };

  const loginAsSuperAdmin = (password: string): boolean => {
    if (password !== SUPER_ADMIN_PASSWORD) return false;
    setUser({
      id: 'super-admin', name: 'Super Admin', nameAr: 'المدير العام',
      email: 'superadmin@clinicflow.io', role: 'super_admin', clinicId: 'super',
    });
    return true;
  };

  const loginAsPatient = (identifier: string): boolean => {
    const trimmed = identifier.trim();
    // Check patientStore first
    let p = patientStore.get(pt => pt.phone === trimmed || (pt.email && pt.email === trimmed));
    // Fallback to registrationStore
    if (!p) {
      const reg = registrationStore.get(r => r.type === 'patient' && (r.phone === trimmed || r.email === trimmed));
      if (reg) {
        const newPt: Patient = {
          id: reg.userId || `pt-${Date.now()}`,
          name: reg.name, nameAr: reg.name,
          phone: reg.phone, email: reg.email,
          dateOfBirth: '', gender: 'male', createdAt: reg.createdAt,
        };
        const existing = patientStore.get(pt => pt.phone === newPt.phone);
        if (!existing) patientStore.add(newPt);
        p = existing || newPt;
      }
    }
    if (!p) return false;
    setUser({
      id: p.id, name: p.name, nameAr: p.nameAr,
      email: p.email || '', role: 'patient',
      patientId: p.id, clinicId: p.clinicId ?? '',
    });
    return true;
  };

  const registerPatient = (data: { name: string; phone: string; email: string; password: string }): boolean => {
    const existing = patientStore.get(p => p.phone === data.phone || (data.email && p.email === data.email));
    if (existing) return false;
    const patient: Patient = {
      id: `pt-${Date.now()}`, name: data.name, nameAr: data.name,
      phone: data.phone, email: data.email,
      dateOfBirth: '', gender: 'male', createdAt: new Date().toISOString(),
    };
    patientStore.add(patient);
    if (data.password) passwordStore[patient.id] = data.password;
    setUser({
      id: patient.id, name: patient.name, nameAr: patient.nameAr,
      email: patient.email || '', role: 'patient',
      patientId: patient.id, clinicId: '',
    });
    return true;
  };

  const logout = () => {
    setUser(null);
    setPendingDoctorClinics(null);
    setPendingDoctorUser(null);
  };

  return (
    <AuthContext.Provider value={{
      user, pendingDoctorClinics, pendingDoctorUser,
      login, loginAsSuperAdmin, loginAsPatient,
      loginWithEmail, registerPatient,
      selectClinicForDoctor, switchClinic, logout,
      isAuthenticated: !!user,
      isLoading,
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within an AuthProvider');
  return ctx;
};
