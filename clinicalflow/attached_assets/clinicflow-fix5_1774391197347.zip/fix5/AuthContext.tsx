import React, { createContext, useContext, useState, ReactNode } from 'react';
import { UserRole, Patient } from '@/types';
import { userStore } from '@/stores/userStore';
import { patientStore } from '@/stores/patientStore';
import { getClinicsForDoctor } from '@/stores/doctorClinicStore';

export interface AuthUser {
  id: string;
  name: string;
  nameAr: string;
  email: string;
  role: UserRole | 'patient' | 'super_admin';
  specialtyId?: string;
  patientId?: string;
  clinicId: string;
}

interface AuthContextType {
  user: AuthUser | null;
  pendingDoctorClinics: string[] | null;
  pendingDoctorUser: AuthUser | null;
  // Original methods (used by staff/admin tabs)
  login: (clinicId: string, role: UserRole) => void;
  loginAsSuperAdmin: (password: string) => boolean;
  loginAsPatient: (identifier: string) => boolean;
  // New unified method (used by email+password UI)
  loginWithEmail: (email: string, password: string) => Promise<{ ok: boolean; error?: string }>;
  registerPatient: (data: { name: string; phone: string; email: string; password: string }) => boolean;
  selectClinicForDoctor: (clinicId: string) => void;
  switchClinic: () => void;
  logout: () => void;
  isAuthenticated: boolean;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const SUPER_ADMIN_PASSWORD = 'superadmin2024';
// Simple in-memory password store keyed by userId
// Populated when registerPatient is called
const passwordStore: Record<string, string> = {
  // Pre-seeded demo accounts
  'u-1':  'admin123',
  'u-2':  'doctor123',
  'u-3':  'doctor123',
  'u-4':  'doctor123',
  'u-5':  'doctor123',
  'u-6':  'reception123',
  'u-10': 'admin123',
  'u-11': 'doctor123',
  'u-12': 'reception123',
  'u-20': 'admin123',
  'u-21': 'doctor123',
  'u-22': 'reception123',
  'pt-demo': 'patient123',
};

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser]                       = useState<AuthUser | null>(null);
  const [pendingDoctorClinics, setPendingDoctorClinics] = useState<string[] | null>(null);
  const [pendingDoctorUser, setPendingDoctorUser]       = useState<AuthUser | null>(null);
  const [isLoading, setIsLoading]             = useState(false);

  // ── loginWithEmail ────────────────────────────────────────────────────────
  // Handles the email + password form. Works entirely in-memory.
  const loginWithEmail = async (
    email: string,
    password: string,
  ): Promise<{ ok: boolean; error?: string }> => {
    setIsLoading(true);
    // Simulate brief async delay so UI feels real
    await new Promise(r => setTimeout(r, 400));
    setIsLoading(false);

    const trimmedEmail = email.trim().toLowerCase();

    // 1. Check super admin
    if (trimmedEmail === 'superadmin@clinicflow.io') {
      if (password === SUPER_ADMIN_PASSWORD) {
        setUser({
          id: 'super-admin',
          name: 'Super Admin',
          nameAr: 'المدير العام',
          email: 'superadmin@clinicflow.io',
          role: 'super_admin',
          clinicId: 'super',
        });
        return { ok: true };
      }
      return { ok: false, error: 'Incorrect password.' };
    }

    // 2. Check patients
    const patient = patientStore.get(
      p => (p.email?.toLowerCase() === trimmedEmail) || p.phone === trimmedEmail,
    );
    if (patient) {
      const stored = passwordStore[patient.id];
      // Accept if password matches, or if no password set yet (first login)
      if (!stored || stored === password) {
        if (!stored) passwordStore[patient.id] = password; // save on first login
        setUser({
          id: patient.id,
          name: patient.name,
          nameAr: patient.nameAr,
          email: patient.email || '',
          role: 'patient',
          patientId: patient.id,
          clinicId: patient.clinicId ?? '',
        });
        return { ok: true };
      }
      return { ok: false, error: 'Incorrect password.' };
    }

    // 3. Check staff users
    const staffUser = userStore.get(
      u => u.email.toLowerCase() === trimmedEmail && u.isActive,
    );
    if (staffUser) {
      const stored = passwordStore[staffUser.id];
      if (!stored || stored === password) {
        if (!stored) passwordStore[staffUser.id] = password;
        const authUser: AuthUser = {
          id:          staffUser.id,
          name:        staffUser.name,
          nameAr:      staffUser.nameAr,
          email:       staffUser.email,
          role:        staffUser.role,
          specialtyId: staffUser.specialtyId,
          clinicId:    staffUser.clinicId,
        };
        // Handle multi-clinic doctor
        if (staffUser.role === 'doctor') {
          const clinicLinks = getClinicsForDoctor(staffUser.id);
          if (clinicLinks.length > 1) {
            setPendingDoctorUser(authUser);
            setPendingDoctorClinics(clinicLinks);
            return { ok: true };
          }
        }
        setUser(authUser);
        return { ok: true };
      }
      return { ok: false, error: 'Incorrect password.' };
    }

    return { ok: false, error: 'No account found with this email.' };
  };

  // ── Original methods (kept for backward compat) ───────────────────────────

  const login = (clinicId: string, role: UserRole) => {
    const storeUser = userStore.get(
      u => u.clinicId === clinicId && u.role === role && u.isActive,
    );
    if (!storeUser) return;
    const authUser: AuthUser = {
      id:          storeUser.id,
      name:        storeUser.name,
      nameAr:      storeUser.nameAr,
      email:       storeUser.email,
      role:        storeUser.role,
      specialtyId: storeUser.specialtyId,
      clinicId:    storeUser.clinicId,
    };
    if (role === 'doctor') {
      const clinicLinks = getClinicsForDoctor(storeUser.id);
      if (clinicLinks.length > 1) {
        setPendingDoctorUser(authUser);
        setPendingDoctorClinics(clinicLinks);
        return;
      }
    }
    setUser(authUser);
  };

  const selectClinicForDoctor = (clinicId: string) => {
    if (!pendingDoctorUser) return;
    const doctorInClinic = userStore.get(
      u => u.clinicId === clinicId && u.role === 'doctor' && u.isActive,
    );
    setUser({
      ...pendingDoctorUser,
      clinicId,
      specialtyId: doctorInClinic?.specialtyId ?? pendingDoctorUser.specialtyId,
    });
    setPendingDoctorClinics(null);
    setPendingDoctorUser(null);
  };

  const switchClinic = () => {
    if (!user || user.role !== 'doctor') return;
    const clinicLinks = getClinicsForDoctor(user.id);
    if (clinicLinks.length > 1) {
      setPendingDoctorUser(user);
      setPendingDoctorClinics(clinicLinks);
      setUser(null);
    }
  };

  const loginAsSuperAdmin = (password: string): boolean => {
    if (password !== SUPER_ADMIN_PASSWORD) return false;
    setUser({
      id:       'super-admin',
      name:     'Super Admin',
      nameAr:   'المدير العام',
      email:    'superadmin@clinicflow.io',
      role:     'super_admin',
      clinicId: 'super',
    });
    return true;
  };

  const loginAsPatient = (identifier: string): boolean => {
    const trimmed = identifier.trim();
    const patient = patientStore.get(
      p => p.phone === trimmed || (p.email && p.email === trimmed),
    );
    if (!patient) return false;
    setUser({
      id:        patient.id,
      name:      patient.name,
      nameAr:    patient.nameAr,
      email:     patient.email || '',
      role:      'patient',
      patientId: patient.id,
      clinicId:  patient.clinicId ?? '',
    });
    return true;
  };

  const registerPatient = (data: {
    name: string; phone: string; email: string; password: string;
  }): boolean => {
    const existing = patientStore.get(
      p => p.phone === data.phone || (data.email && p.email === data.email),
    );
    if (existing) return false;

    const patient: Patient = {
      id:          `pt-${Date.now()}`,
      name:        data.name,
      nameAr:      data.name,
      phone:       data.phone,
      email:       data.email,
      dateOfBirth: '',
      gender:      'male',
      createdAt:   new Date().toISOString(),
    };
    patientStore.add(patient);
    // Save password
    if (data.password) passwordStore[patient.id] = data.password;

    setUser({
      id:        patient.id,
      name:      patient.name,
      nameAr:    patient.nameAr,
      email:     patient.email || '',
      role:      'patient',
      patientId: patient.id,
      clinicId:  '',
    });
    return true;
  };

  const logout = () => {
    setUser(null);
    setPendingDoctorClinics(null);
    setPendingDoctorUser(null);
  };

  return (
    <AuthContext.Provider value={{
      user,
      pendingDoctorClinics,
      pendingDoctorUser,
      login,
      loginAsSuperAdmin,
      loginAsPatient,
      loginWithEmail,
      registerPatient,
      selectClinicForDoctor,
      switchClinic,
      logout,
      isAuthenticated: !!user,
      isLoading,
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within an AuthProvider');
  return ctx;
};
