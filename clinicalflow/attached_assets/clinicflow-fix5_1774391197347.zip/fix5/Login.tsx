import React, { useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { UserRole } from '@/types';
import { clinicStore } from '@/stores/clinicStore';
import { userStore } from '@/stores/userStore';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import {
  Shield, Stethoscope, ClipboardList, User, ArrowLeft,
  Building2, Lock, ChevronRight, Mail, Eye, EyeOff,
  UserPlus, Loader2,
} from 'lucide-react';
import logoImg from '@assets/Untitled_design_1772868317886.png';

type Tab = 'patient' | 'staff' | 'admin';

const Login: React.FC = () => {
  const {
    login,
    loginAsSuperAdmin,
    loginWithEmail,
    pendingDoctorClinics,
    selectClinicForDoctor,
    isLoading,
  } = useAuth();

  const navigate      = useNavigate();
  const [searchParams] = useSearchParams();
  const returnDoctor  = searchParams.get('returnDoctor');

  const [tab, setTab] = useState<Tab>('patient');

  // ── Patient email+password state ──
  const [email, setEmail]           = useState('');
  const [password, setPassword]     = useState('');
  const [showPass, setShowPass]     = useState(false);
  const [loginError, setLoginError] = useState('');

  // ── Staff tab state ──
  const [staffStep, setStaffStep]               = useState<'clinic' | 'role'>('clinic');
  const [selectedClinicId, setSelectedClinicId] = useState('');

  // ── Super Admin state ──
  const [superPassword, setSuperPassword] = useState('');
  const [superError, setSuperError]       = useState(false);
  const [showSuperPass, setShowSuperPass] = useState(false);

  const clinics = clinicStore.getAll().filter(c => c.isActive);

  // ── Doctor multi-clinic selection ─────────────────────────────────────────
  if (pendingDoctorClinics) {
    const doctorClinics = pendingDoctorClinics
      .map(cid => clinicStore.filter(c => c.id === cid)[0])
      .filter(Boolean);
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <Building2 className="h-10 w-10 text-primary mx-auto mb-2" />
            <CardTitle>Select Your Clinic</CardTitle>
            <CardDescription>
              You are registered in multiple clinics. Choose which to enter.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {doctorClinics.map(clinic => (
              <button
                key={clinic.id}
                onClick={() => {
                  selectClinicForDoctor(clinic.id);
                  navigate('/dashboard');
                }}
                className="w-full flex items-center gap-3 p-4 rounded-lg border border-border hover:border-primary hover:bg-primary/5 transition-all text-left"
                data-testid={`clinic-select-${clinic.id}`}
              >
                <Building2 className="h-5 w-5 text-primary shrink-0" />
                <div className="min-w-0 flex-1">
                  <div className="font-medium text-foreground truncate">{clinic.name}</div>
                  <div className="text-sm text-muted-foreground truncate">{clinic.city}</div>
                </div>
                <ChevronRight className="h-4 w-4 text-muted-foreground ml-auto shrink-0" />
              </button>
            ))}
          </CardContent>
        </Card>
      </div>
    );
  }

  // ── Handlers ──────────────────────────────────────────────────────────────

  const handleEmailLogin = async () => {
    setLoginError('');
    if (!email.trim()) { setLoginError('Please enter your email.'); return; }
    if (!password)     { setLoginError('Please enter your password.'); return; }

    const { ok, error } = await loginWithEmail(email, password);
    if (!ok) {
      setLoginError(error || 'Login failed.');
      return;
    }
    // Navigation based on role is handled by App.tsx redirects
    if (returnDoctor) navigate(`/patient/book?doctor=${returnDoctor}`);
    else navigate('/dashboard');
  };

  const getRoleAccounts = (clinicId: string) => {
    const roles: {
      role: UserRole; icon: React.ReactNode; color: string;
      label: string; description: string;
    }[] = [];
    const clinicUsers = userStore.filter(u => u.clinicId === clinicId && u.isActive);
    if (clinicUsers.find(u => u.role === 'admin'))
      roles.push({ role: 'admin', icon: <Shield className="h-5 w-5" />, color: 'text-primary', label: 'Admin', description: 'Full system access' });
    if (clinicUsers.find(u => u.role === 'doctor'))
      roles.push({ role: 'doctor', icon: <Stethoscope className="h-5 w-5" />, color: 'text-chart-1', label: 'Doctor', description: 'Patient care & consultations' });
    if (clinicUsers.find(u => u.role === 'reception'))
      roles.push({ role: 'reception', icon: <ClipboardList className="h-5 w-5" />, color: 'text-chart-2', label: 'Receptionist', description: 'Front desk operations' });
    return roles;
  };

  const handleStaffLogin = (role: UserRole) => {
    login(selectedClinicId, role);
    if (role !== 'doctor') navigate('/dashboard');
  };

  const handleSuperAdmin = () => {
    const ok = loginAsSuperAdmin(superPassword);
    if (ok) navigate('/super-admin');
    else { setSuperError(true); setSuperPassword(''); }
  };

  const selectedClinic = clinics.find(c => c.id === selectedClinicId);

  const TABS: { key: Tab; label: string; icon: React.ReactNode }[] = [
    { key: 'patient', label: 'Patient',      icon: <User className="h-4 w-4" /> },
    { key: 'staff',   label: 'Clinic Staff', icon: <Building2 className="h-4 w-4" /> },
    { key: 'admin',   label: 'Super Admin',  icon: <Shield className="h-4 w-4" /> },
  ];

  // ── Render ────────────────────────────────────────────────────────────────
  return (
    <div
      className="min-h-screen bg-gradient-to-br from-blue-50 via-background to-blue-50/30 flex flex-col"
      dir="ltr"
    >
      {/* Header */}
      <header className="border-b border-border bg-card/80 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-3 hover:opacity-80 transition-opacity">
            <img src={logoImg} alt="ClinicFlow" className="h-9 w-9 rounded-lg object-cover" />
            <span className="font-semibold text-foreground hidden sm:inline">ClinicFlow</span>
          </Link>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" asChild>
              <Link to="/register" className="gap-1.5 flex items-center" data-testid="button-header-register">
                <UserPlus className="h-4 w-4" />
                سجل الآن
              </Link>
            </Button>
            <Button variant="ghost" size="sm" asChild>
              <Link to="/" className="gap-2 flex items-center">
                <ArrowLeft className="h-4 w-4" />
                Back to Home
              </Link>
            </Button>
          </div>
        </div>
      </header>

      {/* Main */}
      <main className="flex-1 flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          <div className="text-center mb-6">
            <h1 className="text-2xl font-bold text-foreground">Welcome back</h1>
            <p className="text-muted-foreground mt-1">Sign in to your ClinicFlow account</p>
          </div>

          {/* Tabs */}
          <div className="flex rounded-lg bg-muted p-1 mb-6 gap-1">
            {TABS.map(t => (
              <button
                key={t.key}
                onClick={() => setTab(t.key)}
                className={`flex-1 flex items-center justify-center gap-1.5 py-2 px-2 rounded-md text-sm font-medium transition-all ${
                  tab === t.key
                    ? 'bg-background text-foreground shadow-sm'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
                data-testid={`tab-${t.key}`}
              >
                {t.icon}
                <span className="hidden sm:inline">{t.label}</span>
              </button>
            ))}
          </div>

          {/* ── PATIENT TAB ── */}
          {tab === 'patient' && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="h-5 w-5 text-blue-600" />
                  Patient Login
                </CardTitle>
                <CardDescription>Sign in with your email and password</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Email */}
                <div className="space-y-1.5">
                  <Label htmlFor="login-email">Email</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
                    <Input
                      id="login-email"
                      type="email"
                      className="pl-9"
                      placeholder="you@example.com"
                      autoComplete="email"
                      value={email}
                      onChange={e => { setEmail(e.target.value); setLoginError(''); }}
                      onKeyDown={e => e.key === 'Enter' && handleEmailLogin()}
                      data-testid="input-email"
                    />
                  </div>
                </div>

                {/* Password */}
                <div className="space-y-1.5">
                  <Label htmlFor="login-password">Password</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
                    <Input
                      id="login-password"
                      type={showPass ? 'text' : 'password'}
                      className="pl-9 pr-10"
                      placeholder="••••••••"
                      autoComplete="current-password"
                      value={password}
                      onChange={e => { setPassword(e.target.value); setLoginError(''); }}
                      onKeyDown={e => e.key === 'Enter' && handleEmailLogin()}
                      data-testid="input-password"
                    />
                    <button
                      type="button"
                      tabIndex={-1}
                      onMouseDown={e => e.preventDefault()}
                      onClick={() => setShowPass(v => !v)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                      data-testid="button-toggle-password"
                    >
                      {showPass ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </div>

                {/* Error */}
                {loginError && (
                  <p className="text-sm text-destructive bg-destructive/5 border border-destructive/20 rounded-md px-3 py-2">
                    {loginError}
                  </p>
                )}

                {/* Demo quick-login */}
                <div className="rounded-lg border border-border bg-muted/40 p-3">
                  <p className="text-xs font-medium text-muted-foreground mb-2">Demo account</p>
                  <button
                    className="w-full flex items-center gap-3 rounded-md hover:bg-background px-2 py-1.5 transition-colors text-left"
                    onClick={() => {
                      setEmail('patient@demo.com');
                      setPassword('patient123');
                      setLoginError('');
                    }}
                    data-testid="button-demo-patient"
                  >
                    <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center shrink-0">
                      <User className="h-4 w-4 text-blue-600" />
                    </div>
                    <div>
                      <div className="text-sm font-medium text-foreground">patient@demo.com</div>
                      <div className="text-xs text-muted-foreground">Demo patient account</div>
                    </div>
                    <ChevronRight className="h-4 w-4 text-muted-foreground ml-auto shrink-0" />
                  </button>
                </div>

                {/* Sign In button */}
                <Button
                  className="w-full"
                  onClick={handleEmailLogin}
                  disabled={isLoading}
                  data-testid="button-patient-login"
                >
                  {isLoading
                    ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Signing in…</>
                    : 'Sign In'
                  }
                </Button>

                <Separator />

                {/* Register */}
                <div className="space-y-1.5 text-center">
                  <p className="text-sm text-muted-foreground">Don't have an account yet?</p>
                  <Button variant="outline" className="w-full gap-2" asChild>
                    <Link to="/register?type=patient" data-testid="button-create-account">
                      <UserPlus className="h-4 w-4" />
                      Create a Patient Account
                    </Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* ── CLINIC STAFF TAB ── */}
          {tab === 'staff' && (
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  {staffStep === 'role' && (
                    <button
                      onClick={() => setStaffStep('clinic')}
                      className="p-1 rounded hover:bg-muted transition-colors"
                      data-testid="button-back-clinic"
                    >
                      <ArrowLeft className="h-4 w-4" />
                    </button>
                  )}
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      <Building2 className="h-5 w-5 text-emerald-600" />
                      {staffStep === 'clinic' ? 'Select Your Clinic' : `Login to ${selectedClinic?.name}`}
                    </CardTitle>
                    <CardDescription>
                      {staffStep === 'clinic' ? 'Choose the clinic you work in' : 'Select your role to continue'}
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                {staffStep === 'clinic' && clinics.map(clinic => (
                  <button
                    key={clinic.id}
                    onClick={() => { setSelectedClinicId(clinic.id); setStaffStep('role'); }}
                    className="w-full flex items-center gap-3 p-3 rounded-lg border border-border hover:border-primary hover:bg-primary/5 transition-all text-left"
                    data-testid={`staff-clinic-${clinic.id}`}
                  >
                    <div className="h-9 w-9 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                      <Building2 className="h-4 w-4 text-primary" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="font-medium text-foreground text-sm truncate">{clinic.name}</div>
                      <div className="text-xs text-muted-foreground truncate">{clinic.city} · {clinic.address}</div>
                    </div>
                    <ChevronRight className="h-4 w-4 text-muted-foreground shrink-0" />
                  </button>
                ))}

                {staffStep === 'role' && selectedClinic && getRoleAccounts(selectedClinic.id).map(r => (
                  <button
                    key={r.role}
                    onClick={() => handleStaffLogin(r.role)}
                    className="w-full flex items-center gap-3 p-3 rounded-lg border border-border hover:border-primary hover:bg-primary/5 transition-all text-left"
                    data-testid={`staff-role-${r.role}`}
                  >
                    <div className={`h-9 w-9 rounded-lg bg-muted flex items-center justify-center shrink-0 ${r.color}`}>
                      {r.icon}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="font-medium text-foreground text-sm">{r.label}</div>
                      <div className="text-xs text-muted-foreground">{r.description}</div>
                    </div>
                    <ChevronRight className="h-4 w-4 text-muted-foreground shrink-0" />
                  </button>
                ))}

                <Separator />
                <p className="text-center text-xs text-muted-foreground">
                  Want to register your clinic?{' '}
                  <Link to="/register?type=clinic" className="text-primary hover:underline font-medium" data-testid="link-register-clinic">
                    Register here
                  </Link>
                </p>
              </CardContent>
            </Card>
          )}

          {/* ── SUPER ADMIN TAB ── */}
          {tab === 'admin' && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="h-5 w-5 text-violet-600" />
                  Super Admin
                </CardTitle>
                <CardDescription>Platform-level administration access</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="super-password">Admin Password</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
                    <Input
                      id="super-password"
                      type={showSuperPass ? 'text' : 'password'}
                      className="pl-9 pr-9"
                      placeholder="Enter admin password"
                      autoComplete="off"
                      value={superPassword}
                      onChange={e => { setSuperPassword(e.target.value); setSuperError(false); }}
                      onKeyDown={e => e.key === 'Enter' && handleSuperAdmin()}
                      data-testid="input-admin-password"
                    />
                    <button
                      type="button"
                      tabIndex={-1}
                      onMouseDown={e => e.preventDefault()}
                      onClick={() => setShowSuperPass(v => !v)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                    >
                      {showSuperPass ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                  {superError && (
                    <p className="text-sm text-destructive">Incorrect password. Please try again.</p>
                  )}
                </div>
                <Button
                  className="w-full bg-violet-600 hover:bg-violet-700"
                  onClick={handleSuperAdmin}
                  data-testid="button-admin-login"
                >
                  Access Admin Panel
                </Button>
              </CardContent>
            </Card>
          )}

          <p className="text-center text-xs text-muted-foreground mt-6">
            By signing in you agree to our{' '}
            <span className="text-primary cursor-pointer hover:underline">Terms of Service</span>
            {' '}and{' '}
            <span className="text-primary cursor-pointer hover:underline">Privacy Policy</span>
          </p>
        </div>
      </main>
    </div>
  );
};

export default Login;
