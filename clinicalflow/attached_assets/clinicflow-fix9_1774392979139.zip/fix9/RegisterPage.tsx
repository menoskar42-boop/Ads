import { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { useLanguage } from '@/contexts/LanguageContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  Stethoscope, Building2, User, CheckCircle, ArrowLeft, Copy, Gift,
} from 'lucide-react';
import { specialtyStore } from '@/stores/specialtyStore';
import { registerUser } from '@/stores/registrationStore';
import { EGYPT_GOVERNORATES } from '@/lib/governorates';
import { RegistrationEntry } from '@/types';
import logoImg from '@assets/Untitled_design_1772868317886.png';

type RegType = 'patient' | 'doctor' | 'clinic';

interface PatientForm { name: string; phone: string; email: string; password: string; usedReferralCode?: string; }
interface DoctorForm  { name: string; phone: string; email: string; specialtyId: string; graduationYear: string; password: string; usedReferralCode?: string; }
interface ClinicForm  { clinicName: string; address: string; city: string; phone: string; adminName: string; email: string; password: string; usedReferralCode?: string; }

// ── Translations ──────────────────────────────────────────────────────────────
const T = {
  en: {
    backHome: 'Back to Home',
    title: 'Create Your Account',
    subtitle: 'Join thousands of patients, doctors, and clinics on ClinicFlow',
    tabPatient: 'Patient', tabDoctor: 'Doctor', tabClinic: 'Clinic',
    regNumDesc: 'Your unique registration number will be generated automatically (e.g., {prefix}-10001)',
    patientReg: 'Patient Registration',
    doctorReg: 'Doctor Registration',
    clinicReg: 'Clinic Registration',
    fullName: 'Full Name', namePh: 'Ahmed Mohamed', doctorNamePh: 'Dr. Sarah Hassan',
    phone: 'Phone Number', phonePh: '+20 1XX XXX XXXX',
    email: 'Email', emailPh: 'ahmed@email.com',
    password: 'Password', passwordPh: 'Create a password',
    specialty: 'Specialty', specialtyPh: 'Select your specialty',
    gradYear: 'Graduation Year', gradYearPh: '2015',
    clinicName: 'Clinic Name', clinicNamePh: 'Al Salam Medical Center',
    address: 'Address', addressPh: '12 Tahrir Square',
    city: 'Governorate', cityPh: 'Select governorate',
    adminName: 'Clinic Admin Name', adminNamePh: 'Dr. Khaled Ibrahim',
    referral: 'Referral Code (optional)', referralPh: 'e.g. PAT-10001',
    createPatient: 'Create Patient Account',
    createDoctor: 'Create Doctor Account',
    createClinic: 'Register Clinic',
    haveAccount: 'Already have an account?', loginLink: 'Login here',
    req: '*',
    successTitle: 'Registration Successful!',
    successSub: 'Welcome to ClinicFlow',
    regNumber: 'Your Registration Number',
    saveNumber: 'Save this number for future reference',
    referralCode: 'Your Referral Code',
    referralShare: 'Share this link to earn rewards when friends join',
    referralUsed: 'Referral code', referralApplied: 'applied — rewards will be issued after your first activity.',
    goLogin: 'Go to Login', goHome: 'Back to Home',
  },
  ar: {
    backHome: 'العودة للرئيسية',
    title: 'إنشاء حسابك',
    subtitle: 'انضم لآلاف المرضى والأطباء والعيادات على ClinicFlow',
    tabPatient: 'مريض', tabDoctor: 'طبيب', tabClinic: 'عيادة',
    regNumDesc: 'سيتم إنشاء رقم تسجيل فريد تلقائياً (مثال: {prefix}-10001)',
    patientReg: 'تسجيل مريض',
    doctorReg: 'تسجيل طبيب',
    clinicReg: 'تسجيل عيادة',
    fullName: 'الاسم الكامل', namePh: 'أحمد محمد', doctorNamePh: 'د. سارة حسن',
    phone: 'رقم الهاتف', phonePh: '01xxxxxxxxx',
    email: 'البريد الإلكتروني', emailPh: 'ahmed@email.com',
    password: 'كلمة المرور', passwordPh: 'أنشئ كلمة مرور',
    specialty: 'التخصص', specialtyPh: 'اختر تخصصك',
    gradYear: 'سنة التخرج', gradYearPh: '2015',
    clinicName: 'اسم العيادة', clinicNamePh: 'مركز السلام الطبي',
    address: 'العنوان', addressPh: '12 ميدان التحرير',
    city: 'المحافظة', cityPh: 'اختر المحافظة',
    adminName: 'اسم مسؤول العيادة', adminNamePh: 'د. خالد إبراهيم',
    referral: 'كود الإحالة (اختياري)', referralPh: 'مثال: PAT-10001',
    createPatient: 'إنشاء حساب مريض',
    createDoctor: 'إنشاء حساب طبيب',
    createClinic: 'تسجيل العيادة',
    haveAccount: 'لديك حساب بالفعل؟', loginLink: 'سجّل دخولك هنا',
    req: '*',
    successTitle: 'تم التسجيل بنجاح!',
    successSub: 'مرحباً بك في ClinicFlow',
    regNumber: 'رقم تسجيلك',
    saveNumber: 'احفظ هذا الرقم للرجوع إليه لاحقاً',
    referralCode: 'كود الإحالة الخاص بك',
    referralShare: 'شارك هذا الرابط لكسب مكافآت عندما ينضم أصدقاؤك',
    referralUsed: 'كود الإحالة', referralApplied: 'تم تطبيقه — ستُمنح المكافآت بعد أول نشاط لك.',
    goLogin: 'الذهاب لتسجيل الدخول', goHome: 'العودة للرئيسية',
  },
} as const;

const TYPE_CONFIG = {
  patient: { icon: <User className="h-5 w-5" />,        color: 'bg-blue-50 text-blue-700 border-blue-200',      activeColor: 'bg-blue-600 text-white border-blue-600',    prefix: 'PAT' },
  doctor:  { icon: <Stethoscope className="h-5 w-5" />, color: 'bg-emerald-50 text-emerald-700 border-emerald-200', activeColor: 'bg-emerald-600 text-white border-emerald-600', prefix: 'DOC' },
  clinic:  { icon: <Building2 className="h-5 w-5" />,   color: 'bg-violet-50 text-violet-700 border-violet-200',   activeColor: 'bg-violet-600 text-white border-violet-600',  prefix: 'CLN' },
};

const RegisterPage = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { language, setLanguage, isRTL } = useLanguage();
  const t   = T[language as 'en' | 'ar'];
  const isAr = language === 'ar';

  const [activeType, setActiveType] = useState<RegType>((searchParams.get('type') as RegType) || 'patient');
  const [registered, setRegistered] = useState<RegistrationEntry | null>(null);
  const [copied, setCopied]         = useState(false);

  // city state for clinic form (controlled separately from react-hook-form)
  const [clinicCity, setClinicCity] = useState('');

  const specialties = specialtyStore.filter(s => s.isActive);

  const patientForm = useForm<PatientForm>({ defaultValues: { name: '', phone: '', email: '', password: '', usedReferralCode: '' } });
  const doctorForm  = useForm<DoctorForm>({ defaultValues: { name: '', phone: '', email: '', specialtyId: '', graduationYear: '', password: '', usedReferralCode: '' } });
  const clinicForm  = useForm<ClinicForm>({ defaultValues: { clinicName: '', address: '', city: '', phone: '', adminName: '', email: '', password: '', usedReferralCode: '' } });

  useEffect(() => {
    const tp = searchParams.get('type') as RegType;
    if (tp && ['patient', 'doctor', 'clinic'].includes(tp)) setActiveType(tp);
  }, [searchParams]);

  const onPatientSubmit = (data: PatientForm) => {
    setRegistered(registerUser({ type: 'patient', name: data.name, email: data.email, phone: data.phone, password: data.password, usedReferralCode: data.usedReferralCode || undefined }));
  };
  const onDoctorSubmit = (data: DoctorForm) => {
    setRegistered(registerUser({ type: 'doctor', name: data.name, email: data.email, phone: data.phone, password: data.password, specialtyId: data.specialtyId, graduationYear: parseInt(data.graduationYear) || undefined, usedReferralCode: data.usedReferralCode || undefined }));
  };
  const onClinicSubmit = (data: ClinicForm) => {
    setRegistered(registerUser({ type: 'clinic', name: data.adminName, clinicName: data.clinicName, email: data.email, phone: data.phone, password: data.password, address: data.address, city: clinicCity || data.city, adminName: data.adminName, usedReferralCode: data.usedReferralCode || undefined }));
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text).then(() => { setCopied(true); setTimeout(() => setCopied(false), 2000); });
  };

  // ── Success screen ────────────────────────────────────────────────────────
  if (registered) {
    const referralLink = `https://clinicflow.eg/ref/${registered.referralCode}`;
    return (
      <div className="min-h-screen bg-gradient-to-br from-background to-muted/30 flex items-center justify-center p-4" dir={isRTL ? 'rtl' : 'ltr'}>
        <Card className="w-full max-w-md">
          <CardContent className="p-8 text-center">
            <div className="h-16 w-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="h-8 w-8 text-emerald-600" />
            </div>
            <h2 className="text-2xl font-bold text-foreground mb-1">{t.successTitle}</h2>
            <p className="text-muted-foreground text-sm mb-6">{t.successSub}، {registered.name}.</p>

            <div className="bg-muted/50 rounded-xl p-4 mb-4">
              <p className="text-xs text-muted-foreground mb-1">{t.regNumber}</p>
              <div className="flex items-center justify-center gap-2">
                <span className="text-2xl font-bold text-primary tracking-wider" data-testid="text-reg-number">{registered.regNumber}</span>
                <button onClick={() => handleCopy(registered.regNumber)} className="text-muted-foreground hover:text-primary transition-colors" data-testid="button-copy-reg-number"><Copy className="h-4 w-4" /></button>
              </div>
              <p className="text-xs text-muted-foreground mt-1">{t.saveNumber}</p>
            </div>

            <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 mb-6">
              <div className="flex items-center justify-center gap-1.5 mb-2">
                <Gift className="h-4 w-4 text-amber-600" />
                <p className="text-xs font-semibold text-amber-700">{t.referralCode}</p>
              </div>
              <div className="flex items-center justify-center gap-2 mb-2">
                <span className="text-lg font-bold text-amber-700 tracking-widest" data-testid="text-referral-code">{registered.referralCode}</span>
                <button onClick={() => handleCopy(registered.referralCode)} className="text-amber-600 hover:text-amber-800 transition-colors" data-testid="button-copy-referral-code"><Copy className="h-4 w-4" /></button>
              </div>
              <p className="text-xs text-amber-600 mb-3">{t.referralShare}</p>
              <div className="flex items-center gap-2 bg-white rounded-lg px-3 py-2 border border-amber-200">
                <span className="text-xs text-muted-foreground truncate flex-1">{referralLink}</span>
                <button onClick={() => handleCopy(referralLink)} className="text-amber-600 flex-shrink-0" data-testid="button-copy-referral-link">
                  {copied ? <CheckCircle className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
                </button>
              </div>
            </div>

            {registered.usedReferralCode && (
              <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3 mb-4 text-xs text-emerald-700">
                {t.referralUsed} <strong>{registered.usedReferralCode}</strong> {t.referralApplied}
              </div>
            )}

            <div className="flex gap-3 flex-col">
              <Button className="w-full" onClick={() => navigate('/login')} data-testid="button-go-to-login">{t.goLogin}</Button>
              <Button variant="outline" className="w-full" onClick={() => navigate('/')} data-testid="button-go-to-home">{t.goHome}</Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // ── Registration form ─────────────────────────────────────────────────────
  const tabLabels: Record<RegType, string> = { patient: t.tabPatient, doctor: t.tabDoctor, clinic: t.tabClinic };
  const regTitles: Record<RegType, string> = { patient: t.patientReg, doctor: t.doctorReg,  clinic: t.clinicReg  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-muted/30" dir={isRTL ? 'rtl' : 'ltr'}>
      {/* Nav */}
      <div className="border-b bg-white/95 backdrop-blur">
        <div className="max-w-3xl mx-auto px-4 h-14 flex items-center justify-between">
          <button onClick={() => navigate('/')} className="flex items-center gap-2" data-testid="link-logo-home">
            <img src={logoImg} alt="ClinicFlow" className="h-7 w-7 rounded-lg" />
            <span className="font-bold text-foreground">ClinicFlow</span>
          </button>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={() => setLanguage(isAr ? 'en' : 'ar')}>
              {isAr ? 'EN' : 'AR'}
            </Button>
            <button onClick={() => navigate('/')} className="text-sm text-muted-foreground hover:text-foreground flex items-center gap-1" data-testid="button-back-to-home">
              <ArrowLeft className={`h-4 w-4 ${isRTL ? 'rotate-180' : ''}`} />
              {t.backHome}
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-xl mx-auto px-4 py-10">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">{t.title}</h1>
          <p className="text-muted-foreground text-sm">{t.subtitle}</p>
        </div>

        {/* Type tabs */}
        <div className="flex gap-3 mb-6">
          {(Object.keys(TYPE_CONFIG) as RegType[]).map(type => {
            const cfg = TYPE_CONFIG[type];
            const isActive = activeType === type;
            return (
              <button
                key={type}
                className={`flex-1 flex flex-col items-center gap-1.5 py-3 px-2 rounded-xl border-2 transition-all ${isActive ? cfg.activeColor : cfg.color}`}
                onClick={() => setActiveType(type)}
                data-testid={`tab-register-${type}`}
              >
                {cfg.icon}
                <span className="text-xs font-semibold">{tabLabels[type]}</span>
              </button>
            );
          })}
        </div>

        <Card>
          <CardHeader className="pb-4">
            <CardTitle className="text-lg">{regTitles[activeType]}</CardTitle>
            <CardDescription>{t.regNumDesc.replace('{prefix}', TYPE_CONFIG[activeType].prefix)}</CardDescription>
          </CardHeader>
          <CardContent>

            {/* ── Patient form ── */}
            {activeType === 'patient' && (
              <form onSubmit={patientForm.handleSubmit(onPatientSubmit)} className="space-y-4">
                <div className="space-y-1.5">
                  <Label htmlFor="p-name">{t.fullName} {t.req}</Label>
                  <Input id="p-name" placeholder={t.namePh} {...patientForm.register('name', { required: true })} data-testid="input-patient-name" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="p-phone">{t.phone} {t.req}</Label>
                  <Input id="p-phone" placeholder={t.phonePh} {...patientForm.register('phone', { required: true })} data-testid="input-patient-phone" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="p-email">{t.email} {t.req}</Label>
                  <Input id="p-email" type="email" placeholder={t.emailPh} {...patientForm.register('email', { required: true })} data-testid="input-patient-email" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="p-password">{t.password} {t.req}</Label>
                  <Input id="p-password" type="password" placeholder={t.passwordPh} {...patientForm.register('password', { required: true, minLength: 6 })} data-testid="input-patient-password" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="p-ref" className="flex items-center gap-1.5">
                    <Gift className="h-3.5 w-3.5 text-amber-500" />{t.referral}
                  </Label>
                  <Input id="p-ref" placeholder={t.referralPh} {...patientForm.register('usedReferralCode')} data-testid="input-patient-referral" />
                </div>
                <Button type="submit" className="w-full" data-testid="button-patient-submit">{t.createPatient}</Button>
              </form>
            )}

            {/* ── Doctor form ── */}
            {activeType === 'doctor' && (
              <form onSubmit={doctorForm.handleSubmit(onDoctorSubmit)} className="space-y-4">
                <div className="space-y-1.5">
                  <Label htmlFor="d-name">{t.fullName} {t.req}</Label>
                  <Input id="d-name" placeholder={t.doctorNamePh} {...doctorForm.register('name', { required: true })} data-testid="input-doctor-name" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="d-phone">{t.phone} {t.req}</Label>
                  <Input id="d-phone" placeholder={t.phonePh} {...doctorForm.register('phone', { required: true })} data-testid="input-doctor-phone" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="d-email">{t.email} {t.req}</Label>
                  <Input id="d-email" type="email" placeholder={t.emailPh} {...doctorForm.register('email', { required: true })} data-testid="input-doctor-email" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="d-spec">{t.specialty} {t.req}</Label>
                  <Select onValueChange={v => doctorForm.setValue('specialtyId', v)} defaultValue="">
                    <SelectTrigger id="d-spec" data-testid="select-doctor-specialty">
                      <SelectValue placeholder={t.specialtyPh} />
                    </SelectTrigger>
                    <SelectContent>
                      {specialties.map(s => (
                        <SelectItem key={s.id} value={s.id}>{isAr ? s.nameAr : s.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="d-grad">{t.gradYear} {t.req}</Label>
                  <Input id="d-grad" type="number" placeholder={t.gradYearPh} min={1970} max={new Date().getFullYear()} {...doctorForm.register('graduationYear', { required: true })} data-testid="input-doctor-grad-year" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="d-password">{t.password} {t.req}</Label>
                  <Input id="d-password" type="password" placeholder={t.passwordPh} {...doctorForm.register('password', { required: true, minLength: 6 })} data-testid="input-doctor-password" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="d-ref" className="flex items-center gap-1.5">
                    <Gift className="h-3.5 w-3.5 text-amber-500" />{t.referral}
                  </Label>
                  <Input id="d-ref" placeholder={t.referralPh} {...doctorForm.register('usedReferralCode')} data-testid="input-doctor-referral" />
                </div>
                <Button type="submit" className="w-full" data-testid="button-doctor-submit">{t.createDoctor}</Button>
              </form>
            )}

            {/* ── Clinic form ── */}
            {activeType === 'clinic' && (
              <form onSubmit={clinicForm.handleSubmit(onClinicSubmit)} className="space-y-4">
                <div className="space-y-1.5">
                  <Label htmlFor="c-name">{t.clinicName} {t.req}</Label>
                  <Input id="c-name" placeholder={t.clinicNamePh} {...clinicForm.register('clinicName', { required: true })} data-testid="input-clinic-name" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="c-address">{t.address} {t.req}</Label>
                  <Input id="c-address" placeholder={t.addressPh} {...clinicForm.register('address', { required: true })} data-testid="input-clinic-address" />
                </div>

                {/* ── Governorate dropdown ── */}
                <div className="space-y-1.5">
                  <Label htmlFor="c-city">{t.city} {t.req}</Label>
                  <Select
                    value={clinicCity}
                    onValueChange={val => {
                      setClinicCity(val);
                      clinicForm.setValue('city', val, { shouldValidate: true });
                    }}
                    data-testid="select-clinic-city"
                  >
                    <SelectTrigger id="c-city">
                      <SelectValue placeholder={t.cityPh} />
                    </SelectTrigger>
                    <SelectContent className="max-h-64 overflow-y-auto">
                      {EGYPT_GOVERNORATES.map(gov => (
                        <SelectItem key={gov.en} value={gov.en}>
                          {isAr ? gov.ar : gov.en}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {/* Hidden input to keep react-hook-form validation happy */}
                  <input type="hidden" {...clinicForm.register('city', { required: true })} value={clinicCity} />
                </div>

                <div className="space-y-1.5">
                  <Label htmlFor="c-phone">{t.phone} {t.req}</Label>
                  <Input id="c-phone" placeholder="+20 2 XXXX XXXX" {...clinicForm.register('phone', { required: true })} data-testid="input-clinic-phone" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="c-admin">{t.adminName} {t.req}</Label>
                  <Input id="c-admin" placeholder={t.adminNamePh} {...clinicForm.register('adminName', { required: true })} data-testid="input-clinic-admin" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="c-email">{t.email} {t.req}</Label>
                  <Input id="c-email" type="email" placeholder="admin@clinic.com" {...clinicForm.register('email', { required: true })} data-testid="input-clinic-email" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="c-password">{t.password} {t.req}</Label>
                  <Input id="c-password" type="password" placeholder={t.passwordPh} {...clinicForm.register('password', { required: true, minLength: 6 })} data-testid="input-clinic-password" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="c-ref" className="flex items-center gap-1.5">
                    <Gift className="h-3.5 w-3.5 text-amber-500" />{t.referral}
                  </Label>
                  <Input id="c-ref" placeholder={t.referralPh} {...clinicForm.register('usedReferralCode')} data-testid="input-clinic-referral" />
                </div>
                <Button type="submit" className="w-full" data-testid="button-clinic-submit">{t.createClinic}</Button>
              </form>
            )}

            <p className="text-center text-sm text-muted-foreground mt-4">
              {t.haveAccount}{' '}
              <button onClick={() => navigate('/login')} className="text-primary hover:underline" data-testid="link-login">
                {t.loginLink}
              </button>
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default RegisterPage;
