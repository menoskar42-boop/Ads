import { useState, useEffect, useCallback } from 'react';
import { Patient } from '@/types';
import { useAuth } from '@/contexts/AuthContext';
import { getToken } from '@/contexts/AuthContext';

const API = '/api';

async function apiFetch<T>(path: string, options?: RequestInit): Promise<T> {
  const token = getToken();
  const res = await fetch(`${API}${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(options?.headers ?? {}),
    },
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: res.statusText }));
    throw new Error(err.error || 'Request failed');
  }
  return res.json();
}

function normalise(p: any): Patient {
  return {
    id:          p.id,
    name:        p.name,
    nameAr:      p.name_ar ?? p.name,
    phone:       p.phone,
    email:       p.email,
    dateOfBirth: p.date_of_birth ?? '',
    gender:      p.gender ?? 'male',
    nationalId:  p.national_id,
    clinicId:    p.clinic_id,
    createdAt:   p.created_at,
  };
}

export const usePatients = () => {
  const { user } = useAuth();
  const [patients, setPatients] = useState<Patient[]>([]);
  const [total, setTotal]       = useState(0);
  const [loading, setLoading]   = useState(false);
  const [error, setError]       = useState<string | null>(null);

  // search + pagination state
  const [search, setSearch]   = useState('');
  const [page, setPage]       = useState(1);
  const limit = 50;

  const load = useCallback(async (q?: string, pg?: number) => {
    if (!user) return;
    setLoading(true);
    setError(null);
    try {
      const params = new URLSearchParams();
      if (q)  params.set('search', q);
      if (pg) params.set('page', String(pg));
      params.set('limit', String(limit));

      const data = await apiFetch<{ data: any[]; total: number }>(`/patients?${params}`);
      setPatients(data.data.map(normalise));
      setTotal(data.total ?? data.data.length);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => { load(search, page); }, [load, search, page]);

  // ── CRUD ──────────────────────────────────────────────────────────────────

  const addPatient = useCallback(async (data: Omit<Patient, 'id' | 'createdAt'>) => {
    const result = await apiFetch<any>('/patients', {
      method: 'POST',
      body: JSON.stringify({
        name:        data.name,
        nameAr:      data.nameAr,
        phone:       data.phone,
        email:       data.email,
        dateOfBirth: data.dateOfBirth,
        gender:      data.gender,
        nationalId:  data.nationalId,
      }),
    });
    const patient = normalise(result);
    setPatients(prev => [patient, ...prev]);
    setTotal(t => t + 1);
    return patient;
  }, []);

  const updatePatient = useCallback(async (id: string, data: Partial<Patient>) => {
    const result = await apiFetch<any>(`/patients/${id}`, {
      method: 'PATCH',
      body: JSON.stringify({
        name:        data.name,
        nameAr:      data.nameAr,
        phone:       data.phone,
        email:       data.email,
        dateOfBirth: data.dateOfBirth,
        gender:      data.gender,
        nationalId:  data.nationalId,
      }),
    });
    const updated = normalise(result);
    setPatients(prev => prev.map(p => p.id === id ? updated : p));
    return updated;
  }, []);

  // Hard-delete is kept as admin-only; soft-delete via backend not yet exposed here
  const deletePatient = useCallback(async (id: string) => {
    setPatients(prev => prev.filter(p => p.id !== id));
    setTotal(t => t - 1);
    // NOTE: add DELETE /api/patients/:id endpoint and call it here when ready
  }, []);

  return {
    patients, total, loading, error,
    search, setSearch,
    page, setPage, limit,
    reload: () => load(search, page),
    addPatient, updatePatient, deletePatient,
  };
};
