import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { LanguageProvider } from "@/contexts/LanguageContext";
import { AuthProvider, useAuth } from "@/contexts/AuthContext";
import Login from "./pages/Login";
import MainLayout from "./components/MainLayout";
import SuperAdmin from "./pages/SuperAdmin";
import QueueScreen from "./pages/QueueScreen";
import DoctorProfilePage from "./pages/DoctorProfilePage";
import ClinicPublicPage from "./pages/ClinicPublicPage";
import LandingPage from "./pages/LandingPage";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      staleTime: 30_000,
    },
  },
});

// ── Determines where an authenticated user should land ────────────────────────
function defaultRoute(role: string): string {
  if (role === 'super_admin') return '/super-admin';
  return '/dashboard';
}

// ── Route guard: redirects to /login if not authenticated ─────────────────────
const ProtectedRoute: React.FC<{ children: React.ReactNode; allowedRoles?: string[] }> = ({
  children,
  allowedRoles,
}) => {
  const { isAuthenticated, user } = useAuth();

  if (!isAuthenticated) return <Navigate to="/login" replace />;

  if (allowedRoles && user && !allowedRoles.includes(user.role)) {
    // Wrong role — send to their default page
    return <Navigate to={defaultRoute(user.role)} replace />;
  }

  return <>{children}</>;
};

// ── App-level routing ─────────────────────────────────────────────────────────
const AppRoutes = () => {
  const { isAuthenticated, user } = useAuth();
  const landing = isAuthenticated && user ? defaultRoute(user.role) : null;

  return (
    <Routes>
      {/* ── Public ── */}
      <Route
        path="/"
        element={landing ? <Navigate to={landing} replace /> : <LandingPage />}
      />
      <Route
        path="/login"
        element={isAuthenticated && user ? <Navigate to={defaultRoute(user.role)} replace /> : <Login />}
      />

      {/* ── Public profile pages (always accessible — SEO / marketing) ── */}
      <Route path="/doctor/:doctorId"  element={<DoctorProfilePage />} />
      <Route path="/clinic/:clinicId"  element={<ClinicPublicPage />} />

      {/* ── Clinic TV queue screen (no auth required — for waiting room display) ── */}
      <Route path="/queue-screen" element={<QueueScreen />} />

      {/* ── Super admin ── */}
      <Route
        path="/super-admin"
        element={
          <ProtectedRoute allowedRoles={['super_admin']}>
            <SuperAdmin />
          </ProtectedRoute>
        }
      />

      {/* ── All authenticated clinic staff routes (admin / doctor / reception) ── */}
      <Route
        path="/*"
        element={
          <ProtectedRoute allowedRoles={['admin', 'doctor', 'reception']}>
            <MainLayout />
          </ProtectedRoute>
        }
      />

      <Route path="*" element={<NotFound />} />
    </Routes>
  );
};

const App = () => (
  <QueryClientProvider client={queryClient}>
    <LanguageProvider>
      <AuthProvider>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <AppRoutes />
          </BrowserRouter>
        </TooltipProvider>
      </AuthProvider>
    </LanguageProvider>
  </QueryClientProvider>
);

export default App;
