import { useState, useEffect, useCallback, useRef } from 'react';
import { Visit, Appointment, Invoice, InvoiceItem, Payment } from '@/types';
import { useAuth } from '@/contexts/AuthContext';
import { getToken } from '@/contexts/AuthContext';

// ── shared fetch helper ───────────────────────────────────────────────────────
const API = '/api';

async function apiFetch<T>(path: string, options?: RequestInit): Promise<T> {
  const token = getToken();
  const res = await fetch(`${API}${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(options?.headers ?? {}),
    },
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: res.statusText }));
    throw new Error(err.error || 'Request failed');
  }
  return res.json();
}

// ── useVisits ─────────────────────────────────────────────────────────────────
export const useVisits = () => {
  const { user } = useAuth();
  const [visits, setVisits]   = useState<Visit[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError]     = useState<string | null>(null);

  const load = useCallback(async (date?: string) => {
    if (!user) return;
    setLoading(true);
    setError(null);
    try {
      const qs = date ? `?date=${date}` : '';
      const data = await apiFetch<any[]>(`/visits${qs}`);
      // Normalise snake_case → camelCase for the existing UI components
      setVisits(data.map(v => ({
        id:             v.id,
        appointmentId:  v.appointment_id,
        patientId:      v.patient_id,
        doctorId:       v.doctor_id,
        specialtyId:    v.specialty_id,
        visitTypeId:    v.visit_type_id,
        invoiceId:      v.invoice_id,
        status:         v.status,
        date:           v.date,
        time:           v.time?.slice(0, 5) ?? '',
        isUrgent:       v.is_urgent,
        arrivalTime:    v.arrival_time,
        clinicId:       v.clinic_id,
        notes:          v.notes,
        isHomeVisit:    v.is_home_visit,
        homeAddress:    v.home_address,
        homeArea:       v.home_area,
        homeCity:       v.home_city,
        createdAt:      v.created_at,
      })));
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, [user]);

  // Initial load + poll every 15 s for live queue updates
  useEffect(() => {
    const today = new Date().toISOString().split('T')[0];
    load(today);
    const id = setInterval(() => load(today), 15_000);
    return () => clearInterval(id);
  }, [load]);

  const updateVisitStatus = useCallback(async (visitId: string, status: Visit['status']) => {
    await apiFetch(`/queue/${visitId}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status }),
    });
    setVisits(prev => prev.map(v => v.id === visitId ? { ...v, status } : v));
  }, []);

  const sendToDoctor = useCallback(async (visitId: string) => {
    await updateVisitStatus(visitId, 'in_consultation');
    return true;
  }, [updateVisitStatus]);

  const completeVisit = useCallback(async (visitId: string) => {
    await updateVisitStatus(visitId, 'completed');
    return true;
  }, [updateVisitStatus]);

  const markWaiting = useCallback(async (visitId: string) => {
    await updateVisitStatus(visitId, 'waiting');
    return true;
  }, [updateVisitStatus]);

  const callNextPatient = useCallback(async (doctorId: string) => {
    // Find first urgent then by arrival in local state (server already sorted)
    const waiting = visits.filter(
      v => v.doctorId === doctorId && v.status === 'waiting' && !v.isHomeVisit
    );
    if (!waiting.length) return null;
    waiting.sort((a, b) => {
      if (a.isUrgent && !b.isUrgent) return -1;
      if (!a.isUrgent && b.isUrgent) return 1;
      return (a.arrivalTime || a.createdAt).localeCompare(b.arrivalTime || b.createdAt);
    });
    const next = waiting[0];
    await updateVisitStatus(next.id, 'in_consultation');
    return next;
  }, [visits, updateVisitStatus]);

  const createVisitWithInvoice = useCallback(async (data: {
    patientId: string; doctorId: string; specialtyId?: string;
    visitTypeId?: string; appointmentId?: string; date: string;
    time: string; clinicId?: string; notes?: string;
    isHomeVisit?: boolean; homeAddress?: string; homeArea?: string; homeCity?: string;
  }) => {
    const result = await apiFetch<{ visit: any; invoice: any }>('/visits', {
      method: 'POST',
      body: JSON.stringify({
        patientId:     data.patientId,
        doctorId:      data.doctorId,
        specialtyId:   data.specialtyId,
        visitTypeId:   data.visitTypeId,
        appointmentId: data.appointmentId,
        date:          data.date,
        time:          data.time,
        notes:         data.notes,
        isHomeVisit:   data.isHomeVisit,
        homeAddress:   data.homeAddress,
        homeArea:      data.homeArea,
        homeCity:      data.homeCity,
      }),
    });
    // Refresh list
    const today = new Date().toISOString().split('T')[0];
    load(today);
    return result;
  }, [load]);

  return {
    visits, loading, error, reload: load,
    createVisitWithInvoice,
    updateVisitStatus,
    sendToDoctor,
    completeVisit,
    markWaiting,
    callNextPatient,
  };
};

// ── useAppointments ───────────────────────────────────────────────────────────
export const useAppointments = () => {
  const { user } = useAuth();
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState(false);

  const normalise = (a: any): Appointment => ({
    id:             a.id,
    patientId:      a.patient_id,
    doctorId:       a.doctor_id,
    specialtyId:    a.specialty_id ?? '',
    visitTypeId:    a.visit_type_id,
    date:           a.date,
    time:           a.time?.slice(0, 5) ?? '',
    status:         a.status,
    isUrgent:       a.is_urgent,
    clinicId:       a.clinic_id,
    notes:          a.notes,
    isHomeVisit:    a.is_home_visit,
    homeAddress:    a.home_address,
    homeArea:       a.home_area,
    homeCity:       a.home_city,
    homeLocationPin: a.home_location_pin,
    createdAt:      a.created_at,
    reminderSentConfirmation: a.reminder_sent_confirmation,
    reminderSent24h: a.reminder_sent_24h,
    reminderSent2h:  a.reminder_sent_2h,
  });

  const load = useCallback(async (date?: string) => {
    if (!user) return;
    setLoading(true);
    try {
      const qs = date ? `?date=${date}` : '';
      const data = await apiFetch<any[]>(`/appointments${qs}`);
      setAppointments(data.map(normalise));
    } catch {
      // leave stale data
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => { load(); }, [load]);

  const createAppointment = useCallback(async (data: {
    patientId: string; doctorId: string; specialtyId: string;
    visitTypeId?: string; date: string; time: string;
    clinicId?: string; notes?: string; isUrgent?: boolean;
    isHomeVisit?: boolean; homeAddress?: string; homeArea?: string;
    homeCity?: string; homeLocationPin?: string;
  }) => {
    const result = await apiFetch<any>('/appointments', {
      method: 'POST',
      body: JSON.stringify({
        patientId:      data.patientId,
        doctorId:       data.doctorId,
        specialtyId:    data.specialtyId,
        visitTypeId:    data.visitTypeId,
        date:           data.date,
        time:           data.time,
        notes:          data.notes,
        isUrgent:       data.isUrgent,
        isHomeVisit:    data.isHomeVisit,
        homeAddress:    data.homeAddress,
        homeArea:       data.homeArea,
        homeCity:       data.homeCity,
      }),
    });
    setAppointments(prev => [normalise(result), ...prev]);
    return normalise(result);
  }, []);

  const cancelAppointment = useCallback(async (id: string) => {
    await apiFetch(`/appointments/${id}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status: 'cancelled' }),
    });
    setAppointments(prev => prev.map(a => a.id === id ? { ...a, status: 'cancelled' } : a));
  }, []);

  const checkInAppointment = useCallback(async (appointmentId: string) => {
    // Check-in = create visit from appointment
    const apt = appointments.find(a => a.id === appointmentId);
    if (!apt) return null;
    try {
      const result = await apiFetch<{ visit: any; invoice: any }>('/visits', {
        method: 'POST',
        body: JSON.stringify({
          patientId:     apt.patientId,
          doctorId:      apt.doctorId,
          specialtyId:   apt.specialtyId,
          visitTypeId:   apt.visitTypeId,
          appointmentId: apt.id,
          date:          apt.date,
          time:          apt.time,
          notes:         apt.notes,
          isHomeVisit:   apt.isHomeVisit,
          homeAddress:   apt.homeAddress,
          homeArea:      apt.homeArea,
          homeCity:      apt.homeCity,
        }),
      });
      // Mark appointment converted locally
      setAppointments(prev => prev.map(a => a.id === appointmentId ? { ...a, status: 'converted' as any } : a));
      return result;
    } catch {
      return null;
    }
  }, [appointments]);

  const markNoShow = useCallback(async (appointmentId: string) => {
    await apiFetch(`/appointments/${appointmentId}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status: 'no_show' }),
    });
    setAppointments(prev => prev.map(a => a.id === appointmentId ? { ...a, status: 'no_show' } : a));
  }, []);

  const markUrgent = useCallback((appointmentId: string) => {
    // Urgent is set via visit creation on the backend; update local display only
    setAppointments(prev => prev.map(a => a.id === appointmentId ? { ...a, isUrgent: true } : a));
  }, []);

  return {
    appointments, loading, reload: load,
    createAppointment, cancelAppointment,
    checkInAppointment, markNoShow, markUrgent,
  };
};

// ── useInvoices ───────────────────────────────────────────────────────────────
export const useInvoices = () => {
  const { user } = useAuth();
  const [invoices, setInvoices]     = useState<Invoice[]>([]);
  const [invoiceItems, setItems]    = useState<InvoiceItem[]>([]);
  const [payments, setPayments]     = useState<Payment[]>([]);
  const [loading, setLoading]       = useState(false);

  const normaliseInvoice = (i: any): Invoice => ({
    id:            i.id,
    visitId:       i.visit_id,
    patientId:     i.patient_id,
    status:        i.status,
    totalAmount:   Number(i.total_amount ?? 0),
    paidAmount:    Number(i.paid_amount ?? 0),
    discountType:  i.discount_type ?? 'none',
    discountValue: Number(i.discount_value ?? 0),
    isActive:      i.is_active ?? true,
    createdAt:     i.created_at,
  });

  const load = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    try {
      const data = await apiFetch<any[]>('/billing/invoices');
      const normInvoices = data.map(normaliseInvoice);
      setInvoices(normInvoices);

      // Flatten items + payments from nested response
      const allItems: InvoiceItem[] = [];
      const allPayments: Payment[]  = [];
      data.forEach(inv => {
        (inv.invoice_items || []).forEach((item: any) => {
          allItems.push({
            id: item.id, invoiceId: inv.id, serviceId: item.service_id,
            quantity: item.quantity, unitPrice: Number(item.unit_price),
            totalPrice: Number(item.total_price), doctorShare: Number(item.doctor_share),
          });
        });
        (inv.payments || []).forEach((p: any) => {
          allPayments.push({
            id: p.id, invoiceId: inv.id, amount: Number(p.amount),
            method: p.method, date: p.date, receivedBy: p.received_by,
            isActive: p.is_active ?? true, createdAt: p.created_at,
          });
        });
      });
      setItems(allItems);
      setPayments(allPayments);
    } catch {
      // leave stale
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => { load(); }, [load]);

  const addInvoiceItem = useCallback(async (invoiceId: string, serviceId: string, quantity = 1) => {
    const result = await apiFetch<any>(`/billing/invoices/${invoiceId}/items`, {
      method: 'POST',
      body: JSON.stringify({ serviceId, quantity }),
    });
    load(); // refresh to get recomputed totals
    return result;
  }, [load]);

  const addPayment = useCallback(async (data: {
    invoiceId: string; amount: number;
    method: Payment['method']; receivedBy?: string;
  }) => {
    const result = await apiFetch<any>(`/billing/invoices/${data.invoiceId}/pay`, {
      method: 'POST',
      body: JSON.stringify({ amount: data.amount, method: data.method }),
    });
    load();
    return result;
  }, [load]);

  const updateInvoiceDiscount = useCallback(async (
    invoiceId: string,
    discountType: Invoice['discountType'],
    discountValue: number,
  ) => {
    await apiFetch(`/billing/invoices/${invoiceId}/discount`, {
      method: 'PATCH',
      body: JSON.stringify({ discountType, discountValue }),
    });
    load();
  }, [load]);

  const refundInvoice = useCallback(async (invoiceId: string) => {
    await apiFetch(`/billing/invoices/${invoiceId}/refund`, { method: 'POST' });
    load();
  }, [load]);

  const recomputeInvoice = useCallback(async (invoiceId: string) => {
    // Server computes automatically via triggers; just refresh
    load();
  }, [load]);

  return {
    invoices, invoiceItems, payments, loading, reload: load,
    addInvoiceItem, addPayment, recomputeInvoice,
    updateInvoiceDiscount, refundInvoice,
    getItemsForInvoice: (id: string) => invoiceItems.filter(i => i.invoiceId === id),
    getPaymentsForInvoice: (id: string) => payments.filter(p => p.invoiceId === id && p.isActive),
  };
};
