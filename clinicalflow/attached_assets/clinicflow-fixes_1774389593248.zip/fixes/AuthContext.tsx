import React, { createContext, useContext, useState, ReactNode } from 'react';
import { UserRole } from '@/types';

// ─── Types ────────────────────────────────────────────────────────────────────
export interface AuthUser {
  id: string;
  name: string;
  nameAr: string;
  email: string;
  role: UserRole | 'patient' | 'super_admin';
  specialtyId?: string;
  patientId?: string;
  clinicId: string;
}

interface AuthContextType {
  user: AuthUser | null;
  login: (email: string, password: string) => Promise<{ ok: boolean; error?: string }>;
  logout: () => void;
  isAuthenticated: boolean;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// ─── Helpers ──────────────────────────────────────────────────────────────────

/** Base URL for the backend API (Replit serves it at the same origin on port 3001, proxied via /api) */
const API = '/api';

function saveSession(token: string, user: AuthUser) {
  localStorage.setItem('cf_token', token);
  localStorage.setItem('cf_user', JSON.stringify(user));
}

function clearSession() {
  localStorage.removeItem('cf_token');
  localStorage.removeItem('cf_user');
}

export function getToken(): string | null {
  return localStorage.getItem('cf_token');
}

// ─── Provider ─────────────────────────────────────────────────────────────────
export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Rehydrate from localStorage on first load
  const [user, setUser] = useState<AuthUser | null>(() => {
    try {
      const raw = localStorage.getItem('cf_user');
      return raw ? (JSON.parse(raw) as AuthUser) : null;
    } catch {
      return null;
    }
  });
  const [isLoading, setIsLoading] = useState(false);

  // ── login ──────────────────────────────────────────────────────────────────
  const login = async (email: string, password: string): Promise<{ ok: boolean; error?: string }> => {
    setIsLoading(true);
    try {
      const res = await fetch(`${API}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });

      const data = await res.json();

      if (!res.ok) {
        return { ok: false, error: data.error || 'Login failed' };
      }

      const authUser: AuthUser = {
        id:          data.user.id,
        name:        data.user.name,
        nameAr:      data.user.name_ar,
        email:       data.user.email,
        role:        data.user.role as AuthUser['role'],
        specialtyId: data.user.specialty_id,
        clinicId:    data.user.clinic_id ?? '',
      };

      saveSession(data.token, authUser);
      setUser(authUser);
      return { ok: true };
    } catch (err) {
      return { ok: false, error: 'Network error. Please try again.' };
    } finally {
      setIsLoading(false);
    }
  };

  // ── logout ─────────────────────────────────────────────────────────────────
  const logout = () => {
    // Fire and forget — tell server to invalidate session
    const token = getToken();
    if (token) {
      fetch(`${API}/auth/logout`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      }).catch(() => {});
    }
    clearSession();
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{
      user,
      login,
      logout,
      isAuthenticated: !!user,
      isLoading,
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within an AuthProvider');
  return context;
};
