import React, { useMemo, useState } from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAppointments } from '@/hooks/useVisits';
import { useAuth } from '@/contexts/AuthContext';
import { formatDate } from '@/lib/dateFormat';
import { Bell, Calendar, X, Clock, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { ScrollArea } from '@/components/ui/scroll-area';

type NotifUrgency = 'high' | 'medium' | 'low';

interface Notification {
  id:            string;
  type:          'reminder_today' | 'reminder_tomorrow' | 'appointment';
  urgency:       NotifUrgency;
  titleEn:       string;
  titleAr:       string;
  descriptionEn: string;
  descriptionAr: string;
}

const NotificationBell: React.FC = () => {
  const { language } = useLanguage();
  const { user } = useAuth();
  const { appointments } = useAppointments();
  const [dismissedIds, setDismissedIds] = useState<Set<string>>(new Set());

  const notifications = useMemo(() => {
    const items: Notification[] = [];
    const today    = new Date().toISOString().split('T')[0];
    const tomorrow = new Date(Date.now() + 86_400_000).toISOString().split('T')[0];

    const active = appointments.filter(
      a => a.status === 'scheduled' || a.status === 'confirmed'
    );

    // Doctors only see their own appointments
    const relevant = user?.role === 'doctor'
      ? active.filter(a => a.doctorId === user.id)
      : active;

    // Today → high urgency
    relevant
      .filter(a => a.date === today)
      .sort((a, b) => a.time.localeCompare(b.time))
      .forEach(a => {
        items.push({
          id:            `rem-today-${a.id}`,
          type:          'reminder_today',
          urgency:       'high',
          titleEn:       `Today at ${a.time}`,
          titleAr:       `اليوم الساعة ${a.time}`,
          descriptionEn: `Patient ID: ${a.patientId.slice(0, 8)}`,
          descriptionAr: `رقم المريض: ${a.patientId.slice(0, 8)}`,
        });
      });

    // Tomorrow → medium urgency
    relevant
      .filter(a => a.date === tomorrow)
      .sort((a, b) => a.time.localeCompare(b.time))
      .forEach(a => {
        items.push({
          id:            `rem-tmrw-${a.id}`,
          type:          'reminder_tomorrow',
          urgency:       'medium',
          titleEn:       `Tomorrow at ${a.time}`,
          titleAr:       `غداً الساعة ${a.time}`,
          descriptionEn: `Patient ID: ${a.patientId.slice(0, 8)}`,
          descriptionAr: `رقم المريض: ${a.patientId.slice(0, 8)}`,
        });
      });

    // Future → low urgency (max 5)
    relevant
      .filter(a => a.date > tomorrow)
      .sort((a, b) => a.date.localeCompare(b.date) || a.time.localeCompare(b.time))
      .slice(0, 5)
      .forEach(a => {
        items.push({
          id:            `apt-${a.id}`,
          type:          'appointment',
          urgency:       'low',
          titleEn:       `${formatDate(a.date, 'en')} at ${a.time}`,
          titleAr:       `${formatDate(a.date, 'ar')} الساعة ${a.time}`,
          descriptionEn: `Scheduled appointment`,
          descriptionAr: `موعد مجدول`,
        });
      });

    return items.filter(n => !dismissedIds.has(n.id));
  }, [appointments, dismissedIds, user]);

  const dismiss    = (id: string) => setDismissedIds(prev => new Set(prev).add(id));
  const dismissAll = () => setDismissedIds(prev => {
    const next = new Set(prev);
    notifications.forEach(n => next.add(n.id));
    return next;
  });

  const count          = notifications.length;
  const hasHighUrgency = notifications.some(n => n.urgency === 'high');

  const getIcon = (type: Notification['type']) => {
    if (type === 'reminder_today')    return <AlertTriangle className="h-4 w-4 text-destructive" />;
    if (type === 'reminder_tomorrow') return <Clock className="h-4 w-4 text-chart-4" />;
    return <Calendar className="h-4 w-4 text-primary" />;
  };

  const getUrgencyStyle = (urgency: NotifUrgency) => {
    if (urgency === 'high')   return 'border-s-2 border-s-destructive bg-destructive/5';
    if (urgency === 'medium') return 'border-s-2 border-s-chart-4';
    return '';
  };

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="icon" className="relative">
          <Bell className={`h-5 w-5 ${hasHighUrgency ? 'text-destructive' : ''}`} />
          {count > 0 && (
            <Badge
              className={`absolute -top-1 -end-1 h-5 min-w-5 px-1 text-xs flex items-center justify-center
                ${hasHighUrgency ? 'bg-destructive' : 'bg-primary'} text-destructive-foreground`}
            >
              {count}
            </Badge>
          )}
        </Button>
      </PopoverTrigger>

      <PopoverContent className="w-80 p-0" align="end">
        <div className="flex items-center justify-between px-4 py-3 border-b border-border">
          <h4 className="font-semibold text-sm text-foreground">
            {language === 'ar' ? 'الإشعارات' : 'Notifications'}
          </h4>
          <div className="flex items-center gap-2">
            {count > 0 && (
              <Button
                variant="ghost" size="sm"
                className="h-6 text-xs text-muted-foreground"
                onClick={dismissAll}
              >
                {language === 'ar' ? 'مسح الكل' : 'Clear all'}
              </Button>
            )}
            <Badge variant="secondary" className="text-xs">{count}</Badge>
          </div>
        </div>

        <ScrollArea className="max-h-96">
          {notifications.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-8">
              {language === 'ar' ? 'لا توجد إشعارات' : 'No notifications'}
            </p>
          ) : (
            <div className="divide-y divide-border">
              {notifications.map(n => (
                <div
                  key={n.id}
                  className={`flex items-start gap-3 px-4 py-3 hover:bg-accent/50 transition-colors ${getUrgencyStyle(n.urgency)}`}
                >
                  <div className="mt-0.5 shrink-0">{getIcon(n.type)}</div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-foreground truncate">
                      {language === 'ar' ? n.titleAr : n.titleEn}
                    </p>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      {language === 'ar' ? n.descriptionAr : n.descriptionEn}
                    </p>
                  </div>
                  <Button
                    variant="ghost" size="icon"
                    className="h-6 w-6 shrink-0"
                    onClick={() => dismiss(n.id)}
                  >
                    <X className="h-3 w-3" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </ScrollArea>
      </PopoverContent>
    </Popover>
  );
};

export default NotificationBell;
