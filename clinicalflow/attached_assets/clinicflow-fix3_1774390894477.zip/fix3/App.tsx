import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { LanguageProvider } from "@/contexts/LanguageContext";
import { AuthProvider, useAuth } from "@/contexts/AuthContext";
import Login from "./pages/Login";
import PatientLayout from "./components/PatientLayout";
import MainLayout from "./components/MainLayout";
import SuperAdmin from "./pages/SuperAdmin";
import QueueScreen from "./pages/QueueScreen";
import DoctorProfilePage from "./pages/DoctorProfilePage";
import ClinicPublicPage from "./pages/ClinicPublicPage";
import LandingPage from "./pages/LandingPage";
import RegisterPage from "./pages/RegisterPage";
import SearchPage from "./pages/SearchPage";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

// ── Where to send an authenticated user ──────────────────────────────────────
const getDefaultRoute = (role: string): string => {
  if (role === 'super_admin') return '/super-admin';
  if (role === 'patient')     return '/patient/appointments';
  return '/dashboard';
};

// ── Protected layout switcher ─────────────────────────────────────────────────
const ProtectedRoutes = () => {
  const { isAuthenticated, user } = useAuth();
  if (!isAuthenticated)               return <Navigate to="/login" replace />;
  if (user?.role === 'super_admin')   return <Navigate to="/super-admin" replace />;
  if (user?.role === 'patient')       return <PatientLayout />;
  return <MainLayout />;
};

// ── Main routing ──────────────────────────────────────────────────────────────
const AppRoutes = () => {
  const { isAuthenticated, user } = useAuth();
  const defaultRedirect = isAuthenticated && user ? getDefaultRoute(user.role) : null;

  return (
    <Routes>
      {/* ── Public / Landing ── */}
      <Route
        path="/"
        element={
          defaultRedirect && user?.role !== 'patient'
            ? <Navigate to={defaultRedirect} replace />
            : <LandingPage />
        }
      />
      <Route path="/search" element={<SearchPage />} />

      {/* ── Auth pages: redirect already-logged-in users ── */}
      <Route
        path="/login"
        element={defaultRedirect ? <Navigate to={defaultRedirect} replace /> : <Login />}
      />
      <Route
        path="/register"
        element={defaultRedirect ? <Navigate to={defaultRedirect} replace /> : <RegisterPage />}
      />

      {/* ── Public profile pages ── */}
      <Route path="/doctor/:doctorId" element={<DoctorProfilePage />} />
      <Route path="/clinic/:clinicId" element={<ClinicPublicPage />} />

      {/* ── TV queue display (no auth needed) ── */}
      <Route path="/queue-screen" element={<QueueScreen />} />

      {/* ── Super Admin ── */}
      <Route
        path="/super-admin"
        element={
          isAuthenticated && user?.role === 'super_admin'
            ? <SuperAdmin />
            : <Navigate to="/login" replace />
        }
      />

      {/* ── Authenticated clinic + patient routes ── */}
      <Route path="/patient/*" element={<ProtectedRoutes />} />
      <Route path="/*"         element={<ProtectedRoutes />} />

      <Route path="*" element={<NotFound />} />
    </Routes>
  );
};

const App = () => (
  <QueryClientProvider client={queryClient}>
    <LanguageProvider>
      <AuthProvider>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <AppRoutes />
          </BrowserRouter>
        </TooltipProvider>
      </AuthProvider>
    </LanguageProvider>
  </QueryClientProvider>
);

export default App;
