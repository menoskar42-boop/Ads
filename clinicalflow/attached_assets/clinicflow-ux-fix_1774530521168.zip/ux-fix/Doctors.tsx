import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '@/contexts/LanguageContext';
import { useUsers } from '@/hooks/useUsers';
import { useSpecialties } from '@/hooks/useSpecialties';
import { usePermissions } from '@/hooks/usePermissions';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Stethoscope, Users, CheckCircle, XCircle, Calendar, Search, CalendarCheck, User, UserPlus, Link2 } from 'lucide-react';
import { addDoctorClinicLink, getDoctorsForClinic } from '@/stores/doctorClinicStore';

const Doctors: React.FC = () => {
  const navigate = useNavigate();
  const { t, language } = useLanguage();
  const { doctors, platformDoctors, addUser, updateUser } = useUsers();
  const { specialties } = useSpecialties();
  const permissions = usePermissions();
  const { user: authUser } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'link' | 'create'>('link');

  const [newDoctor, setNewDoctor] = useState({ name: '', nameAr: '', email: '', phone: '', specialtyId: '' });
  const [createLoading, setCreateLoading] = useState(false);

  const activeDoctors = doctors.filter(d => d.isActive);
  const inactiveDoctors = doctors.filter(d => !d.isActive);

  const filteredDoctors = doctors.filter(d => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase().trim();
    const sp = specialties.find(s => s.id === d.specialtyId);
    return (
      d.name.toLowerCase().includes(q) ||
      d.nameAr.includes(searchQuery.trim()) ||
      sp?.name.toLowerCase().includes(q) ||
      sp?.nameAr.includes(searchQuery.trim())
    );
  });

  const clinicId = authUser?.clinicId || '';
  const linkedDoctorIds = new Set(getDoctorsForClinic(clinicId));
  const availableToLink = platformDoctors.filter(d => !linkedDoctorIds.has(d.id));

  const getSpecialtyName = (id?: string) => {
    if (!id) return '';
    const sp = specialties.find(s => s.id === id);
    return language === 'ar' ? sp?.nameAr : sp?.name;
  };

  const toggleStatus = (id: string, isActive: boolean) => {
    updateUser(id, { isActive: !isActive });
  };

  const handleLinkDoctor = (doctorId: string) => {
    if (!clinicId) return;
    addDoctorClinicLink(doctorId, clinicId);
    setDialogOpen(false);
  };

  const handleCreateDoctor = () => {
    if (!newDoctor.name || !newDoctor.specialtyId) return;
    setCreateLoading(true);
    addUser({
      name: newDoctor.name,
      nameAr: newDoctor.nameAr || newDoctor.name,
      email: newDoctor.email,
      phone: newDoctor.phone,
      role: 'doctor',
      specialtyId: newDoctor.specialtyId,
      clinicId,
      isActive: true,
      password: 'doctor123',
    });
    setCreateLoading(false);
    setNewDoctor({ name: '', nameAr: '', email: '', phone: '', specialtyId: '' });
    setDialogOpen(false);
  };

  const isAr = language === 'ar';

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">{t('doctors.title')}</h1>
          <p className="text-muted-foreground">{activeDoctors.length} {isAr ? 'طبيب نشط' : 'active doctors'}</p>
        </div>
        {permissions.canEditDoctor && (
          <Button onClick={() => setDialogOpen(true)} className="gap-2" data-testid="button-add-doctor">
            <UserPlus className="h-4 w-4" />
            {isAr ? 'إضافة طبيب' : 'Add Doctor'}
          </Button>
        )}
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center"><Stethoscope className="h-6 w-6 text-primary" /></div>
              <div>
                <p className="text-2xl font-bold text-foreground">{doctors.length}</p>
                <p className="text-sm text-muted-foreground">{isAr ? 'إجمالي الأطباء' : 'Total Doctors'}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="h-12 w-12 rounded-lg bg-chart-5/10 flex items-center justify-center"><CheckCircle className="h-6 w-6 text-chart-5" /></div>
              <div>
                <p className="text-2xl font-bold text-foreground">{activeDoctors.length}</p>
                <p className="text-sm text-muted-foreground">{t('doctors.active')}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="h-12 w-12 rounded-lg bg-destructive/10 flex items-center justify-center"><XCircle className="h-6 w-6 text-destructive" /></div>
              <div>
                <p className="text-2xl font-bold text-foreground">{inactiveDoctors.length}</p>
                <p className="text-sm text-muted-foreground">{t('doctors.inactive')}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="relative">
        <Search className="absolute left-3 rtl:left-auto rtl:right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder={isAr ? 'بحث بالاسم أو التخصص...' : 'Search by name or specialty...'}
          value={searchQuery}
          onChange={e => setSearchQuery(e.target.value)}
          className="pl-10 rtl:pl-3 rtl:pr-10"
          data-testid="input-search-doctors"
        />
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {filteredDoctors.map(doctor => (
          <Card key={doctor.id} className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="h-14 w-14 rounded-full bg-chart-2/10 flex items-center justify-center">
                  <Stethoscope className="h-7 w-7 text-chart-2" />
                </div>
                <Badge variant={doctor.isActive ? 'default' : 'secondary'}>
                  {doctor.isActive ? t('doctors.active') : t('doctors.inactive')}
                </Badge>
              </div>
              <h3
                className="text-lg font-semibold text-foreground mb-1 cursor-pointer hover:text-primary transition-colors"
                onClick={() => navigate(`/schedule/${doctor.id}`)}
                data-testid={`link-doctor-schedule-${doctor.id}`}
              >
                {isAr ? doctor.nameAr : doctor.name}
              </h3>
              <p className="text-sm text-muted-foreground mb-4">
                {getSpecialtyName(doctor.specialtyId)}
              </p>
              <div className="grid grid-cols-2 gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  className="gap-1"
                  onClick={() => navigate(`/appointments?doctor=${doctor.id}`)}
                  data-testid={`button-today-appointments-${doctor.id}`}
                >
                  <CalendarCheck className="h-4 w-4" />
                  {isAr ? 'مواعيد اليوم' : "Today's Appts"}
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="gap-1"
                  onClick={() => navigate(`/schedule/${doctor.id}`)}
                  data-testid={`button-schedule-${doctor.id}`}
                >
                  <Calendar className="h-4 w-4" />
                  {isAr ? 'الجدول' : 'Schedule'}
                </Button>
                {permissions.canEditDoctor && (
                  <Button
                    variant="outline"
                    size="sm"
                    className="gap-1"
                    onClick={() => toggleStatus(doctor.id, doctor.isActive)}
                    data-testid={`button-toggle-status-${doctor.id}`}
                  >
                    {doctor.isActive ? <XCircle className="h-4 w-4" /> : <CheckCircle className="h-4 w-4" />}
                    {doctor.isActive ? (isAr ? 'تعطيل' : 'Deactivate') : (isAr ? 'تفعيل' : 'Activate')}
                  </Button>
                )}
              </div>
              <Button
                variant="ghost"
                size="sm"
                className="w-full mt-2 gap-1 text-muted-foreground hover:text-primary"
                onClick={() => navigate(`/doctor/${doctor.id}`)}
                data-testid={`button-view-profile-${doctor.id}`}
              >
                <User className="h-4 w-4" />
                {isAr ? 'عرض الملف الشخصي' : 'View Public Profile'}
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{isAr ? 'إضافة طبيب' : 'Add Doctor'}</DialogTitle>
          </DialogHeader>
          <Tabs value={activeTab} onValueChange={v => setActiveTab(v as 'link' | 'create')}>
            <TabsList className="grid grid-cols-2 w-full">
              <TabsTrigger value="link" className="gap-2">
                <Link2 className="h-4 w-4" />
                {isAr ? 'ربط طبيب موجود' : 'Link Existing'}
              </TabsTrigger>
              <TabsTrigger value="create" className="gap-2">
                <UserPlus className="h-4 w-4" />
                {isAr ? 'إنشاء طبيب جديد' : 'Create New'}
              </TabsTrigger>
            </TabsList>

            <TabsContent value="link" className="mt-4">
              {availableToLink.length === 0 ? (
                <p className="text-center text-muted-foreground py-8 text-sm">
                  {isAr ? 'جميع الأطباء المسجلين مرتبطون بهذه العيادة بالفعل' : 'All registered platform doctors are already linked to this clinic'}
                </p>
              ) : (
                <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
                  {availableToLink.map(doc => (
                    <div
                      key={doc.id}
                      className="flex items-center justify-between p-3 rounded-lg border border-border hover:bg-accent transition-colors"
                    >
                      <div className="flex items-center gap-3">
                        <div className="h-9 w-9 rounded-full bg-primary/10 flex items-center justify-center">
                          <Stethoscope className="h-4 w-4 text-primary" />
                        </div>
                        <div>
                          <p className="text-sm font-medium text-foreground">{isAr ? doc.nameAr : doc.name}</p>
                          <p className="text-xs text-muted-foreground">{getSpecialtyName(doc.specialtyId)}</p>
                        </div>
                      </div>
                      <Button
                        size="sm"
                        onClick={() => handleLinkDoctor(doc.id)}
                        data-testid={`button-link-doctor-${doc.id}`}
                      >
                        {isAr ? 'ربط' : 'Link'}
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </TabsContent>

            <TabsContent value="create" className="mt-4">
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <Label>{isAr ? 'الاسم بالإنجليزية' : 'Name (English)'}</Label>
                    <Input
                      placeholder="Dr. Ahmed Hassan"
                      value={newDoctor.name}
                      onChange={e => setNewDoctor(p => ({ ...p, name: e.target.value }))}
                      data-testid="input-new-doctor-name"
                    />
                  </div>
                  <div className="space-y-1">
                    <Label>{isAr ? 'الاسم بالعربية' : 'Name (Arabic)'}</Label>
                    <Input
                      placeholder="د. أحمد حسن"
                      value={newDoctor.nameAr}
                      onChange={e => setNewDoctor(p => ({ ...p, nameAr: e.target.value }))}
                      data-testid="input-new-doctor-name-ar"
                    />
                  </div>
                </div>
                <div className="space-y-1">
                  <Label>{isAr ? 'التخصص' : 'Specialty'}</Label>
                  <Select value={newDoctor.specialtyId} onValueChange={v => setNewDoctor(p => ({ ...p, specialtyId: v }))}>
                    <SelectTrigger data-testid="select-new-doctor-specialty">
                      <SelectValue placeholder={isAr ? 'اختر التخصص' : 'Select specialty'} />
                    </SelectTrigger>
                    <SelectContent className="max-h-60 overflow-y-auto">
                      {specialties.map(sp => (
                        <SelectItem key={sp.id} value={sp.id}>
                          {isAr ? sp.nameAr : sp.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <Label>{isAr ? 'البريد الإلكتروني' : 'Email'}</Label>
                    <Input
                      type="email"
                      placeholder="doctor@clinic.com"
                      value={newDoctor.email}
                      onChange={e => setNewDoctor(p => ({ ...p, email: e.target.value }))}
                      data-testid="input-new-doctor-email"
                    />
                  </div>
                  <div className="space-y-1">
                    <Label>{isAr ? 'رقم الهاتف' : 'Phone'}</Label>
                    <Input
                      placeholder="01000000000"
                      value={newDoctor.phone}
                      onChange={e => setNewDoctor(p => ({ ...p, phone: e.target.value }))}
                      data-testid="input-new-doctor-phone"
                    />
                  </div>
                </div>
                <p className="text-xs text-muted-foreground">
                  {isAr ? 'كلمة المرور الافتراضية: doctor123' : 'Default password: doctor123'}
                </p>
                <Button
                  className="w-full"
                  onClick={handleCreateDoctor}
                  disabled={!newDoctor.name || !newDoctor.specialtyId || createLoading}
                  data-testid="button-create-doctor-submit"
                >
                  {isAr ? 'إنشاء الطبيب' : 'Create Doctor'}
                </Button>
              </div>
            </TabsContent>
          </Tabs>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Doctors;
