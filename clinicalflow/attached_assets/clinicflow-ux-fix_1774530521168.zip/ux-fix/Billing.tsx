import React, { useState } from 'react';
import { useClinicSettings } from '@/hooks/useClinicSettings';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { useInvoices, useVisits } from '@/hooks/useVisits';
import { usePatients } from '@/hooks/usePatients';
import { useServices } from '@/hooks/useSpecialties';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Separator } from '@/components/ui/separator';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Receipt, CheckCircle, AlertCircle, Eye, FileText, DollarSign, Printer, Tag, Search, Undo2 } from 'lucide-react';
import { getClinicShare } from '@/types';
import { toast } from 'sonner';
import { calcInvoiceTotals } from '@/lib/invoiceCalc';

const Billing: React.FC = () => {
  const { t, language, isRTL } = useLanguage();
  const { user } = useAuth();
  const { settings } = useClinicSettings();
  const { invoices, invoiceItems, getItemsForInvoice, getPaymentsForInvoice, addPayment, updateInvoiceDiscount, refundInvoice } = useInvoices();
  const { visits } = useVisits();
  const { patients } = usePatients();
  const { services } = useServices();

  const [selectedInvoiceId, setSelectedInvoiceId] = useState<string | null>(null);
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [paymentAmount, setPaymentAmount] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'card' | 'insurance' | 'bank_transfer'>('cash');
  const [discountType, setDiscountType] = useState<'none' | 'percentage' | 'fixed'>('none');
  const [discountValue, setDiscountValue] = useState('');

  const activeInvoices = invoices.filter(i => i.isActive);
  const searchFiltered = activeInvoices.filter(i => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase().trim();
    const patient = patients.find(pt => pt.id === i.patientId);
    return (
      patient?.name.toLowerCase().includes(q) ||
      patient?.nameAr.includes(searchQuery.trim()) ||
      i.id.toLowerCase().includes(q) ||
      i.createdAt.includes(q)
    );
  });
  const filtered = searchFiltered.filter(i => filterStatus === 'all' || i.status === filterStatus);

  const totalRevenue = activeInvoices.reduce((sum, i) => sum + i.totalAmount, 0);
  const paidRevenue = activeInvoices.reduce((sum, i) => sum + i.paidAmount, 0);
  const pendingRevenue = totalRevenue - paidRevenue;

  const getPatientName = (id: string) => {
    const p = patients.find(pt => pt.id === id);
    return language === 'ar' ? p?.nameAr : p?.name;
  };

  const getServiceName = (id: string) => {
    const s = services.find(sv => sv.id === id);
    return language === 'ar' ? s?.nameAr : s?.name;
  };

  const selectedInvoice = selectedInvoiceId ? invoices.find(i => i.id === selectedInvoiceId) : null;
  const selectedItems = selectedInvoiceId ? getItemsForInvoice(selectedInvoiceId) : [];
  const selectedPayments = selectedInvoiceId ? getPaymentsForInvoice(selectedInvoiceId) : [];

  const openInvoiceDialog = (invoiceId: string) => {
    const inv = invoices.find(i => i.id === invoiceId);
    if (inv) {
      setDiscountType(inv.discountType || 'none');
      setDiscountValue(inv.discountValue ? String(inv.discountValue) : '');
    }
    setSelectedInvoiceId(invoiceId);
  };

  const handleAddPayment = () => {
    if (!selectedInvoiceId || !paymentAmount || !user) return;
    addPayment({
      invoiceId: selectedInvoiceId,
      amount: parseFloat(paymentAmount),
      method: paymentMethod,
      receivedBy: user.id,
    });
    setPaymentAmount('');
    toast.success(language === 'ar' ? 'تم تسجيل الدفعة' : 'Payment recorded');
  };

  const handleApplyDiscount = () => {
    if (!selectedInvoiceId) return;
    updateInvoiceDiscount(selectedInvoiceId, discountType, parseFloat(discountValue) || 0);
    toast.success(language === 'ar' ? 'تم تطبيق الخصم' : 'Discount applied');
  };

  const handleRefundInvoice = (invoiceId: string) => {
    refundInvoice(invoiceId);
    toast.success(language === 'ar' ? 'تم استرداد المبلغ' : 'Invoice refunded');
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'paid': return <Badge data-testid="badge-status-paid">{t('billing.paid')}</Badge>;
      case 'partially_paid': return <Badge variant="secondary" data-testid="badge-status-partial">{language === 'ar' ? 'مدفوع جزئياً' : 'Partial'}</Badge>;
      case 'refunded': return <Badge variant="outline" className="border-amber-500 text-amber-600 dark:text-amber-400" data-testid="badge-status-refunded">{language === 'ar' ? 'مسترد' : 'Refunded'}</Badge>;
      default: return <Badge variant="destructive" data-testid="badge-status-unpaid">{t('billing.unpaid')}</Badge>;
    }
  };

  const handlePrintInvoice = (invoiceId: string) => {
    const inv = invoices.find(i => i.id === invoiceId);
    if (!inv) return;
    const items = getItemsForInvoice(invoiceId);
    const payments = getPaymentsForInvoice(invoiceId);
    const patientName = getPatientName(inv.patientId) || '';
    const dir = isRTL ? 'rtl' : 'ltr';
    const totals = calcInvoiceTotals(inv, settings);

    const itemRows = items.map(item =>
      `<tr><td style="padding:8px;border-bottom:1px solid #eee">${getServiceName(item.serviceId)}</td><td style="padding:8px;border-bottom:1px solid #eee;text-align:center">${item.quantity}</td><td style="padding:8px;border-bottom:1px solid #eee;text-align:center">${item.unitPrice} ج.م</td><td style="padding:8px;border-bottom:1px solid #eee;text-align:${isRTL ? 'left' : 'right'}">${item.totalPrice} ج.م</td></tr>`
    ).join('');

    const paymentRows = payments.map(p =>
      `<tr><td style="padding:6px;border-bottom:1px solid #eee">${p.date}</td><td style="padding:6px;border-bottom:1px solid #eee;text-align:center">${p.method}</td><td style="padding:6px;border-bottom:1px solid #eee;text-align:${isRTL ? 'left' : 'right'}">${p.amount} ج.م</td></tr>`
    ).join('');

    const clinicName = isRTL ? settings.nameAr : settings.name;
    const clinicAddress = isRTL ? settings.addressAr : settings.address;
    const clinicPhone = settings.phone;
    const clinicEmail = settings.email;

    const discountLabel = inv.discountType === 'percentage'
      ? `${isRTL ? 'خصم' : 'Discount'} (${inv.discountValue}%)`
      : (isRTL ? 'خصم' : 'Discount');

    const summaryRows = [
      `<div style="display:flex;justify-content:space-between;padding:4px 0"><span class="label">${isRTL ? 'المجموع الفرعي' : 'Subtotal'}</span><span>${totals.subtotal.toFixed(2)} ج.م</span></div>`,
      totals.discountAmount > 0 ? `<div style="display:flex;justify-content:space-between;padding:4px 0;color:#dc2626"><span class="label">${discountLabel}</span><span>-${totals.discountAmount.toFixed(2)} ج.م</span></div>` : '',
      settings.taxEnabled ? `<div style="display:flex;justify-content:space-between;padding:4px 0"><span class="label">${isRTL ? settings.taxLabelAr : settings.taxLabel} (${settings.taxRate}%)</span><span>${totals.taxAmount.toFixed(2)} ج.م</span></div>` : '',
      `<div style="display:flex;justify-content:space-between;padding:4px 0;border-top:1px solid #e5e5e5;margin-top:4px;padding-top:8px"><span class="label" style="font-weight:600">${isRTL ? 'الإجمالي' : 'Grand Total'}</span><span class="total-row">${totals.grandTotal.toFixed(2)} ج.م</span></div>`,
      `<div style="display:flex;justify-content:space-between;padding:4px 0"><span class="label">${isRTL ? 'المدفوع' : 'Paid'}</span><span>${inv.paidAmount.toFixed(2)} ج.م</span></div>`,
      `<div style="display:flex;justify-content:space-between;padding:4px 0"><span class="label">${isRTL ? 'المتبقي' : 'Balance'}</span><span style="font-weight:600">${totals.balance.toFixed(2)} ج.م</span></div>`,
    ].filter(Boolean).join('');

    const html = `<!DOCTYPE html><html dir="${dir}"><head><meta charset="utf-8"><title>${isRTL ? 'فاتورة' : 'Invoice'} - ${inv.id.slice(0, 12)}</title><style>body{font-family:system-ui,sans-serif;margin:0;padding:40px;color:#1a1a1a}h1{font-size:24px;margin:0}table{width:100%;border-collapse:collapse;margin:16px 0}.header{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:32px}.total-row{font-weight:700;font-size:16px}.label{color:#666;font-size:13px}.divider{border:none;border-top:2px solid #e5e5e5;margin:20px 0}.clinic-logo{width:56px;height:56px;border-radius:12px;background:linear-gradient(135deg,#2563eb,#7c3aed);display:flex;align-items:center;justify-content:center;color:#fff;font-size:22px;font-weight:700}@media print{body{padding:20px}}</style></head><body>
    <div style="display:flex;align-items:center;gap:16px;margin-bottom:24px;padding-bottom:20px;border-bottom:3px solid #2563eb">
      ${settings.logo ? `<img src="${settings.logo}" style="width:56px;height:56px;border-radius:12px;object-fit:cover" alt="Logo">` : `<div class="clinic-logo">${(isRTL ? settings.nameAr : settings.name).slice(0,2).toUpperCase()}</div>`}
      <div style="flex:1">
        <h2 style="margin:0;font-size:20px;color:#1a1a1a">${clinicName}</h2>
        <p style="margin:4px 0 0;font-size:12px;color:#666">${clinicAddress}</p>
        <p style="margin:2px 0 0;font-size:12px;color:#666">${clinicPhone} · ${clinicEmail}</p>
      </div>
    </div>
    <div class="header"><div><h1>${isRTL ? 'فاتورة' : 'Invoice'}</h1><p class="label">#${inv.id.slice(0, 12)}</p></div><div style="text-align:${isRTL ? 'left' : 'right'}"><p class="label">${isRTL ? 'التاريخ' : 'Date'}</p><p>${inv.createdAt.split('T')[0]}</p></div></div>
    <div style="margin-bottom:24px"><p class="label">${isRTL ? 'المريض' : 'Patient'}</p><p style="font-size:16px;font-weight:600">${patientName}</p></div>
    <hr class="divider">
    <table><thead><tr style="background:#f9f9f9"><th style="padding:8px;text-align:${isRTL ? 'right' : 'left'}">${isRTL ? 'الخدمة' : 'Service'}</th><th style="padding:8px;text-align:center">${isRTL ? 'الكمية' : 'Qty'}</th><th style="padding:8px;text-align:center">${isRTL ? 'السعر' : 'Price'}</th><th style="padding:8px;text-align:${isRTL ? 'left' : 'right'}">${isRTL ? 'المجموع' : 'Total'}</th></tr></thead><tbody>${itemRows}</tbody></table>
    <hr class="divider">
    <div style="display:flex;justify-content:flex-end"><div style="min-width:220px">${summaryRows}</div></div>
    ${payments.length > 0 ? `<hr class="divider"><p class="label" style="margin-bottom:8px">${isRTL ? 'سجل الدفعات' : 'Payment History'}</p><table><thead><tr style="background:#f9f9f9"><th style="padding:6px;text-align:${isRTL ? 'right' : 'left'}">${isRTL ? 'التاريخ' : 'Date'}</th><th style="padding:6px;text-align:center">${isRTL ? 'الطريقة' : 'Method'}</th><th style="padding:6px;text-align:${isRTL ? 'left' : 'right'}">${isRTL ? 'المبلغ' : 'Amount'}</th></tr></thead><tbody>${paymentRows}</tbody></table>` : ''}
    <div style="text-align:center;margin-top:40px;color:#999;font-size:12px">${isRTL ? 'شكراً لكم' : 'Thank you for your payment'}</div>
    </body></html>`;

    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(html);
      printWindow.document.close();
      printWindow.onload = () => { printWindow.print(); };
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground">{t('billing.title')}</h1>
        <p className="text-muted-foreground">{activeInvoices.length} {language === 'ar' ? 'فاتورة' : 'invoices'}</p>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card className="border-t-4 border-t-primary" data-testid="card-total-revenue">
          <CardContent className="p-5">
            <div className="flex items-center gap-4">
              <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                <Receipt className="h-6 w-6 text-primary" />
              </div>
              <div className="min-w-0">
                <p className="text-2xl font-bold text-foreground leading-tight">{totalRevenue.toLocaleString()} ج.م</p>
                <p className="text-sm text-muted-foreground mt-0.5 truncate">{language === 'ar' ? 'إجمالي الإيرادات' : 'Total Revenue'}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-t-4 border-t-green-500 dark:border-t-green-400" data-testid="card-paid-revenue">
          <CardContent className="p-5">
            <div className="flex items-center gap-4">
              <div className="h-12 w-12 rounded-lg bg-green-500/10 flex items-center justify-center shrink-0">
                <CheckCircle className="h-6 w-6 text-green-600 dark:text-green-400" />
              </div>
              <div className="min-w-0">
                <p className="text-2xl font-bold text-foreground leading-tight">{paidRevenue.toLocaleString()} ج.م</p>
                <p className="text-sm text-muted-foreground mt-0.5 truncate">{t('billing.paid')}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-t-4 border-t-destructive" data-testid="card-unpaid-revenue">
          <CardContent className="p-5">
            <div className="flex items-center gap-4">
              <div className="h-12 w-12 rounded-lg bg-destructive/10 flex items-center justify-center shrink-0">
                <AlertCircle className="h-6 w-6 text-destructive" />
              </div>
              <div className="min-w-0">
                <p className="text-2xl font-bold text-foreground leading-tight">{pendingRevenue.toLocaleString()} ج.م</p>
                <p className="text-sm text-muted-foreground mt-0.5 truncate">{t('billing.unpaid')}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="relative">
        <Search className="absolute left-3 rtl:left-auto rtl:right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder={language === 'ar' ? 'بحث بالاسم أو رقم الفاتورة...' : 'Search by name or invoice number...'}
          value={searchQuery}
          onChange={e => setSearchQuery(e.target.value)}
          className="pl-10 rtl:pl-3 rtl:pr-10"
          data-testid="input-search-billing"
        />
      </div>

      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-wrap gap-2">
            {['all', 'pending', 'partially_paid', 'paid', 'refunded'].map(status => (
              <Button key={status} variant={filterStatus === status ? 'default' : 'outline'} size="sm" onClick={() => setFilterStatus(status)}>
                {status === 'all' ? t('common.all') : status === 'paid' ? t('billing.paid') : status === 'partially_paid' ? (language === 'ar' ? 'جزئي' : 'Partial') : status === 'refunded' ? (language === 'ar' ? 'مسترد' : 'Refunded') : t('billing.unpaid')}
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>{t('billing.invoice')}</TableHead>
                <TableHead>{t('billing.patient')}</TableHead>
                <TableHead>{t('billing.date')}</TableHead>
                <TableHead>{t('billing.total')}</TableHead>
                <TableHead>{t('billing.status')}</TableHead>
                <TableHead className="text-right">{t('common.actions')}</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map(inv => (
                <TableRow key={inv.id}>
                  <TableCell><span className="font-mono font-medium">{inv.id.slice(0, 12)}</span></TableCell>
                  <TableCell>{getPatientName(inv.patientId)}</TableCell>
                  <TableCell className="text-muted-foreground">{inv.createdAt.split('T')[0]}</TableCell>
                  <TableCell>
                    <span className="font-semibold">{inv.totalAmount} ج.م</span>
                    {inv.discountType !== 'none' && inv.discountValue > 0 && (
                      <Badge variant="outline" className="ml-2 text-xs gap-1">
                        <Tag className="h-3 w-3" />
                        {inv.discountType === 'percentage' ? `${inv.discountValue}%` : `${inv.discountValue} ج.م`}
                      </Badge>
                    )}
                  </TableCell>
                  <TableCell>{getStatusBadge(inv.status)}</TableCell>
                  <TableCell className="text-right space-x-1">
                    <Button variant="ghost" size="sm" onClick={() => openInvoiceDialog(inv.id)} data-testid={`button-view-invoice-${inv.id}`}>
                      <Eye className="h-4 w-4" />
                    </Button>
                    {inv.status === 'paid' && (
                      <Button variant="ghost" size="sm" onClick={() => handlePrintInvoice(inv.id)} data-testid={`button-print-invoice-${inv.id}`}>
                        <Printer className="h-4 w-4" />
                      </Button>
                    )}
                    {inv.status === 'paid' && (user?.role === 'admin' || user?.role === 'reception') && (
                      <Button variant="ghost" size="sm" onClick={() => handleRefundInvoice(inv.id)} className="text-amber-600 dark:text-amber-400" data-testid={`button-refund-invoice-${inv.id}`}>
                        <Undo2 className="h-4 w-4" />
                      </Button>
                    )}
                  </TableCell>
                </TableRow>
              ))}
              {filtered.length === 0 && (
                <TableRow>
                  <TableCell colSpan={6} className="py-16">
                    <div className="flex flex-col items-center justify-center gap-3 text-muted-foreground">
                      <Receipt className="h-10 w-10 opacity-40" />
                      <p className="text-sm font-medium">{language === 'ar' ? 'لا توجد فواتير' : 'No invoices found'}</p>
                    </div>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={!!selectedInvoice} onOpenChange={open => !open && setSelectedInvoiceId(null)}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              {t('billing.invoice')}
            </DialogTitle>
          </DialogHeader>
          {selectedInvoice && (() => {
            const totals = calcInvoiceTotals(selectedInvoice, settings);
            return (
              <div className="space-y-5">
                <div className="flex flex-wrap justify-between items-start gap-3 rounded-lg bg-muted/50 p-4">
                  <div>
                    <p className="font-semibold text-base" data-testid="text-invoice-patient">{getPatientName(selectedInvoice.patientId)}</p>
                    <p className="text-sm text-muted-foreground mt-0.5">{selectedInvoice.createdAt.split('T')[0]}</p>
                    <p className="text-xs text-muted-foreground font-mono mt-1">#{selectedInvoice.id.slice(0, 12)}</p>
                  </div>
                  <div className="flex items-center gap-2 flex-wrap">
                    {getStatusBadge(selectedInvoice.status)}
                    {selectedInvoice.status === 'paid' && (
                      <Button variant="outline" size="sm" className="gap-1" onClick={() => handlePrintInvoice(selectedInvoice.id)} data-testid="button-print-invoice">
                        <Printer className="h-4 w-4" />
                        {language === 'ar' ? 'طباعة' : 'Print'}
                      </Button>
                    )}
                    {selectedInvoice.status === 'paid' && (user?.role === 'admin' || user?.role === 'reception') && (
                      <Button variant="outline" size="sm" className="gap-1 text-amber-600 dark:text-amber-400 border-amber-500" onClick={() => handleRefundInvoice(selectedInvoice.id)} data-testid="button-refund-invoice-dialog">
                        <Undo2 className="h-4 w-4" />
                        {language === 'ar' ? 'استرداد' : 'Refund'}
                      </Button>
                    )}
                  </div>
                </div>

                <div>
                  <p className="text-sm font-medium text-muted-foreground mb-3">{t('billing.services')}</p>
                  <div className="space-y-2">
                    {selectedItems.map(item => (
                      <div key={item.id} className="flex justify-between items-center text-sm py-1.5 px-2 rounded-md bg-muted/30">
                        <span>{getServiceName(item.serviceId)} × {item.quantity}</span>
                        <span className="font-medium">{item.totalPrice} ج.م</span>
                      </div>
                    ))}
                  </div>
                </div>

                <Separator />

                <div className="space-y-2 rounded-lg border p-4">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">{language === 'ar' ? 'المجموع الفرعي' : 'Subtotal'}</span>
                    <span>{totals.subtotal.toFixed(2)} ج.م</span>
                  </div>
                  {totals.discountAmount > 0 && (
                    <div className="flex justify-between text-sm text-destructive">
                      <span>
                        {language === 'ar' ? 'خصم' : 'Discount'}
                        {selectedInvoice.discountType === 'percentage' ? ` (${selectedInvoice.discountValue}%)` : ''}
                      </span>
                      <span>-{totals.discountAmount.toFixed(2)} ج.م</span>
                    </div>
                  )}
                  {settings.taxEnabled && (
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">{language === 'ar' ? settings.taxLabelAr : settings.taxLabel} ({settings.taxRate}%)</span>
                      <span>{totals.taxAmount.toFixed(2)} ج.م</span>
                    </div>
                  )}
                  <Separator className="my-1" />
                  <div className="flex justify-between font-semibold">
                    <span>{language === 'ar' ? 'الإجمالي' : 'Grand Total'}</span>
                    <span>{totals.grandTotal.toFixed(2)} ج.م</span>
                  </div>
                  <div className="flex justify-between text-sm text-muted-foreground">
                    <span>{t('billing.paid')}</span>
                    <span>{selectedInvoice.paidAmount.toFixed(2)} ج.م</span>
                  </div>
                  <div className="flex justify-between text-sm font-medium">
                    <span>{language === 'ar' ? 'المتبقي' : 'Balance'}</span>
                    <span>{totals.balance.toFixed(2)} ج.م</span>
                  </div>
                </div>

                {/* Discount controls */}
                {selectedInvoice.status !== 'paid' && selectedInvoice.status !== 'refunded' && (
                  <>
                    <Separator />
                    <div className="space-y-3">
                      <p className="font-medium text-sm flex items-center gap-1">
                        <Tag className="h-4 w-4" />
                        {language === 'ar' ? 'خصم' : 'Discount'}
                      </p>
                      <div className="grid grid-cols-3 gap-2">
                        <div className="space-y-1">
                          <Label className="text-xs">{language === 'ar' ? 'النوع' : 'Type'}</Label>
                          <Select value={discountType} onValueChange={(v: any) => setDiscountType(v)}>
                            <SelectTrigger><SelectValue /></SelectTrigger>
                            <SelectContent className="max-h-60 overflow-y-auto">
                              <SelectItem value="none">{language === 'ar' ? 'بدون' : 'None'}</SelectItem>
                              <SelectItem value="percentage">{language === 'ar' ? 'نسبة %' : 'Percentage'}</SelectItem>
                              <SelectItem value="fixed">{language === 'ar' ? 'مبلغ ثابت' : 'Fixed'}</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs">{language === 'ar' ? 'القيمة' : 'Value'}</Label>
                          <Input
                            type="number"
                            value={discountValue}
                            onChange={e => setDiscountValue(e.target.value)}
                            placeholder={discountType === 'percentage' ? '10' : '50'}
                            disabled={discountType === 'none'}
                          />
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs opacity-0">.</Label>
                          <Button
                            variant="outline"
                            className="w-full"
                            size="default"
                            onClick={handleApplyDiscount}
                            disabled={discountType === 'none'}
                          >
                            {language === 'ar' ? 'تطبيق' : 'Apply'}
                          </Button>
                        </div>
                      </div>
                    </div>
                  </>
                )}

                {/* Payment controls */}
                {selectedInvoice.status !== 'paid' && selectedInvoice.status !== 'refunded' && (
                  <>
                    <Separator />
                    <div className="space-y-3">
                      <p className="font-medium text-sm">{language === 'ar' ? 'تسجيل دفعة' : 'Record Payment'}</p>
                      <div className="grid grid-cols-2 gap-3">
                        <div className="space-y-1">
                          <Label className="text-xs">{language === 'ar' ? 'المبلغ' : 'Amount'}</Label>
                          <Input type="number" value={paymentAmount} onChange={e => setPaymentAmount(e.target.value)} placeholder="0" />
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs">{language === 'ar' ? 'الطريقة' : 'Method'}</Label>
                          <Select value={paymentMethod} onValueChange={(v: any) => setPaymentMethod(v)}>
                            <SelectTrigger><SelectValue /></SelectTrigger>
                            <SelectContent className="max-h-60 overflow-y-auto">
                              <SelectItem value="cash">{language === 'ar' ? 'نقدي' : 'Cash'}</SelectItem>
                              <SelectItem value="card">{language === 'ar' ? 'بطاقة' : 'Card'}</SelectItem>
                              <SelectItem value="insurance">{language === 'ar' ? 'تأمين' : 'Insurance'}</SelectItem>
                              <SelectItem value="bank_transfer">{language === 'ar' ? 'تحويل' : 'Transfer'}</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      <Button className="w-full gap-2" onClick={handleAddPayment}>
                        <DollarSign className="h-4 w-4" />
                        {language === 'ar' ? 'تسجيل الدفعة' : 'Record Payment'}
                      </Button>
                    </div>
                  </>
                )}
              </div>
            );
          })()}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Billing;
