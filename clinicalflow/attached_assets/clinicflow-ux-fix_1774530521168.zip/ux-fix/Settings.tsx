import React, { useState, useRef, useEffect, useCallback } from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useClinicSettings } from '@/hooks/useClinicSettings';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Switch } from '@/components/ui/switch';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  Building2, Save, Upload, X, Percent, ImageIcon, Bell, Banknote,
  ClipboardList, Plus, Trash2, AlertTriangle, GripVertical, ChevronUp, ChevronDown, Clock, Check,
  Layers, RotateCcw, ArrowUpDown, Zap, ListOrdered,
} from 'lucide-react';
import { toast } from 'sonner';
import type { ClinicSettings } from '@/stores/clinicSettingsStore';
import {
  visitTypeStore, getClinicVisitTypes, addVisitType, updateVisitType,
  removeVisitType, moveVisitTypePriority, getEnabledClinicVisitTypes,
} from '@/stores/visitTypeStore';
import { VisitType } from '@/types';
import {
  queueStrategyStore, getClinicQueueStrategy, updateQueueStrategy,
  type QueueStrategy, type QueueStrategyConfig,
} from '@/stores/queueStrategyStore';

// ─── Visit Types Tab ───────────────────────────────────────────────────────────
const VisitTypesTab: React.FC<{ clinicId: string; language: string }> = ({ clinicId, language }) => {
  const isAr = language === 'ar';
  const [types, setTypes] = useState<VisitType[]>(() => getClinicVisitTypes(clinicId));
  const [adding, setAdding] = useState(false);
  const [form, setForm] = useState({ name: '', nameAr: '', price: 150, durationMinutes: 20, isUrgent: false });

  const refresh = useCallback(() => setTypes(getClinicVisitTypes(clinicId)), [clinicId]);

  useEffect(() => {
    refresh();
    return visitTypeStore.subscribe(refresh);
  }, [refresh]);

  const handleAdd = () => {
    if (!form.name.trim() || !form.nameAr.trim()) {
      toast.error(isAr ? 'أدخل الاسم بالعربي والإنجليزي' : 'Enter name in both languages');
      return;
    }
    addVisitType(clinicId, {
      name: form.name.trim(),
      nameAr: form.nameAr.trim(),
      price: form.price,
      durationMinutes: form.durationMinutes,
      isUrgent: form.isUrgent,
      isEnabled: true,
      sortOrder: 99,
    });
    setForm({ name: '', nameAr: '', price: 150, durationMinutes: 20, isUrgent: false });
    setAdding(false);
    toast.success(isAr ? 'تم إضافة نوع الزيارة' : 'Visit type added');
  };

  const handleToggle = (id: string, isEnabled: boolean) => {
    updateVisitType(id, { isEnabled });
    toast.success(isAr ? 'تم التحديث' : 'Updated');
  };

  const handleDelete = (id: string) => {
    removeVisitType(id);
    toast.success(isAr ? 'تم الحذف' : 'Deleted');
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between gap-2">
          <div>
            <CardTitle className="flex items-center gap-2 text-lg">
              <ClipboardList className="h-5 w-5" />
              {isAr ? 'أنواع الزيارات' : 'Visit Types'}
            </CardTitle>
            <CardDescription>
              {isAr
                ? 'تخصيص أنواع الزيارات والأسعار للطابور وفواتير الحجز'
                : 'Customize visit types and prices used in booking and queue'}
            </CardDescription>
          </div>
          <Button size="sm" className="gap-1.5 shrink-0" onClick={() => setAdding(v => !v)} data-testid="button-add-visit-type">
            <Plus className="h-4 w-4" />
            {isAr ? 'إضافة نوع' : 'Add Type'}
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Add form */}
        {adding && (
          <div className="rounded-lg border border-border bg-muted/40 p-4 space-y-3">
            <p className="text-sm font-semibold">{isAr ? 'نوع زيارة جديد' : 'New Visit Type'}</p>
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label className="text-xs">{isAr ? 'الاسم (إنجليزي)' : 'Name (English)'}</Label>
                <Input
                  data-testid="input-vt-name"
                  placeholder="e.g. Follow-up"
                  value={form.name}
                  onChange={e => setForm(p => ({ ...p, name: e.target.value }))}
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">{isAr ? 'الاسم (عربي)' : 'Name (Arabic)'}</Label>
                <Input
                  data-testid="input-vt-name-ar"
                  placeholder="مثال: متابعة"
                  dir="rtl"
                  value={form.nameAr}
                  onChange={e => setForm(p => ({ ...p, nameAr: e.target.value }))}
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">{isAr ? 'السعر (ج.م)' : 'Price (EGP)'}</Label>
                <div className="relative">
                  <Input
                    data-testid="input-vt-price"
                    type="number"
                    min={0}
                    step={10}
                    value={form.price}
                    onChange={e => setForm(p => ({ ...p, price: Number(e.target.value) }))}
                    className="pe-12"
                    dir="ltr"
                  />
                  <span className="absolute inset-y-0 end-0 flex items-center px-3 text-sm text-muted-foreground pointer-events-none select-none">
                    ج.م
                  </span>
                </div>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">{isAr ? 'المدة (دقيقة)' : 'Duration (minutes)'}</Label>
                <div className="relative">
                  <Input
                    data-testid="input-vt-duration"
                    type="number"
                    min={5}
                    step={5}
                    value={form.durationMinutes}
                    onChange={e => setForm(p => ({ ...p, durationMinutes: Number(e.target.value) }))}
                    className="pe-14"
                    dir="ltr"
                  />
                  <span className="absolute inset-y-0 end-0 flex items-center px-3 text-sm text-muted-foreground pointer-events-none select-none">
                    {isAr ? 'دقيقة' : 'min'}
                  </span>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Switch
                id="vt-urgent"
                checked={form.isUrgent}
                onCheckedChange={v => setForm(p => ({ ...p, isUrgent: v }))}
                data-testid="switch-vt-urgent"
              />
              <Label htmlFor="vt-urgent" className="flex items-center gap-1.5 cursor-pointer text-sm">
                <AlertTriangle className="h-4 w-4 text-destructive" />
                {isAr ? 'مستعجل (أولوية عالية)' : 'Urgent (high priority)'}
              </Label>
            </div>
            <div className="flex items-center gap-2 pt-1">
              <Button size="sm" className="gap-1.5" onClick={handleAdd} data-testid="button-save-vt">
                <Check className="h-4 w-4" />
                {isAr ? 'حفظ' : 'Save'}
              </Button>
              <Button size="sm" variant="ghost" onClick={() => setAdding(false)} data-testid="button-cancel-vt">
                {isAr ? 'إلغاء' : 'Cancel'}
              </Button>
            </div>
          </div>
        )}

        {/* Existing types */}
        <div className="space-y-2">
          {types.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">
              <ClipboardList className="h-8 w-8 mx-auto mb-2 opacity-30" />
              <p className="text-sm">{isAr ? 'لا توجد أنواع زيارات بعد' : 'No visit types yet'}</p>
            </div>
          )}
          {types.map((vt, idx) => (
            <div
              key={vt.id}
              className={`flex items-center gap-3 rounded-lg border px-4 py-3 ${vt.isEnabled ? 'bg-card' : 'bg-muted/40 opacity-60'}`}
              data-testid={`row-visit-type-${vt.id}`}
            >
              <GripVertical className="h-4 w-4 text-muted-foreground/40 shrink-0" />
              <div className="flex flex-col min-w-0 flex-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-medium text-sm">{isAr ? vt.nameAr : vt.name}</span>
                  {vt.isUrgent && (
                    <Badge variant="destructive" className="text-xs px-1.5 py-0">
                      <AlertTriangle className="h-3 w-3 me-1" />
                      {isAr ? 'مستعجل' : 'Urgent'}
                    </Badge>
                  )}
                  {!vt.isEnabled && (
                    <Badge variant="outline" className="text-xs px-1.5 py-0 text-muted-foreground">
                      {isAr ? 'معطّل' : 'Disabled'}
                    </Badge>
                  )}
                </div>
                <div className="flex items-center gap-3 mt-0.5 text-xs text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    {vt.durationMinutes} {isAr ? 'دقيقة' : 'min'}
                  </span>
                  <span className="font-semibold text-foreground">{vt.price} ج.م</span>
                </div>
              </div>
              {/* Reorder */}
              {!vt.isUrgent && (
                <div className="flex flex-col gap-0.5 shrink-0">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-5 w-5"
                    onClick={() => moveVisitTypePriority(vt.id, 'up', clinicId)}
                    disabled={idx === 0 || (idx === 1 && types[0].isUrgent)}
                    data-testid={`button-move-up-${vt.id}`}
                  >
                    <ChevronUp className="h-3 w-3" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-5 w-5"
                    onClick={() => moveVisitTypePriority(vt.id, 'down', clinicId)}
                    disabled={idx === types.length - 1}
                    data-testid={`button-move-down-${vt.id}`}
                  >
                    <ChevronDown className="h-3 w-3" />
                  </Button>
                </div>
              )}
              {/* Enable/disable */}
              <Switch
                checked={vt.isEnabled}
                onCheckedChange={v => handleToggle(vt.id, v)}
                data-testid={`switch-vt-enabled-${vt.id}`}
              />
              {/* Delete */}
              <Button
                variant="ghost"
                size="icon"
                className="h-7 w-7 text-destructive/70 hover:text-destructive shrink-0"
                onClick={() => handleDelete(vt.id)}
                data-testid={`button-delete-vt-${vt.id}`}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

// ─── Queue Strategy Tab ────────────────────────────────────────────────────────
const STRATEGY_INFO = {
  A: {
    icon: <Clock className="h-4 w-4 text-blue-500" />,
    label: 'Strategy A — Payment Order',
    labelAr: 'الاستراتيجية أ — ترتيب الدفع',
    desc: 'Patients are called strictly by payment time. First to pay = first to be called.',
    descAr: 'يُستدعى المرضى حسب وقت الدفع فقط. الأول في الدفع = الأول في الاستدعاء.',
  },
  B: {
    icon: <ListOrdered className="h-4 w-4 text-primary" />,
    label: 'Strategy B — Visit Type Priority',
    labelAr: 'الاستراتيجية ب — أولوية نوع الزيارة',
    desc: 'Visit types are served in their configured priority order (set in Visit Types tab), then by payment time.',
    descAr: 'تُخدم أنواع الزيارات بحسب ترتيب الأولوية المضبوط في تبويب "أنواع الزيارات"، ثم حسب وقت الدفع.',
  },
  C: {
    icon: <ArrowUpDown className="h-4 w-4 text-green-500" />,
    label: 'Strategy C — Alternating',
    labelAr: 'الاستراتيجية ج — تناوب',
    desc: 'System alternates between consultation and follow-up. If one type is unavailable, the other is served.',
    descAr: 'يتناوب النظام بين الكشف والمتابعة. إذا لم يكن أحد الأنواع متاحاً، يُخدم النوع الآخر.',
  },
  D: {
    icon: <RotateCcw className="h-4 w-4 text-orange-500" />,
    label: 'Strategy D — Custom Rotation',
    labelAr: 'الاستراتيجية د — تدوير مخصص',
    desc: 'Admin defines a rotation pattern (e.g. Consultation → Consultation → Follow-up, repeat). System follows this pattern.',
    descAr: 'يحدد المدير نمط التدوير (مثلاً كشف → كشف → متابعة، تكرار). يتبع النظام هذا النمط.',
  },
  E: {
    icon: <Zap className="h-4 w-4 text-destructive" />,
    label: 'Strategy E — Urgent First + Payment Order',
    labelAr: 'الاستراتيجية هـ — المستعجل أولاً + ترتيب الدفع',
    desc: 'Urgent visits always come first. All remaining patients are called in payment order.',
    descAr: 'الزيارات المستعجلة دائماً أولاً. يُستدعى باقي المرضى بترتيب الدفع.',
  },
};

const QueueStrategyTab: React.FC<{ clinicId: string; language: string }> = ({ clinicId, language }) => {
  const isAr = language === 'ar';
  const [config, setConfig] = useState<QueueStrategyConfig>(() => getClinicQueueStrategy(clinicId));
  const [saved, setSaved] = useState(false);

  const visitTypes = getEnabledClinicVisitTypes(clinicId).filter(vt => !vt.isUrgent);

  useEffect(() => {
    setConfig(getClinicQueueStrategy(clinicId));
  }, [clinicId]);

  const refresh = useCallback(() => setConfig(getClinicQueueStrategy(clinicId)), [clinicId]);

  useEffect(() => {
    return queueStrategyStore.subscribe(refresh);
  }, [refresh]);

  const handleSave = () => {
    updateQueueStrategy(clinicId, {
      strategy: config.strategy,
      urgentAlwaysFirst: config.urgentAlwaysFirst,
      rotationPattern: config.rotationPattern,
      rotationIndex: 0,
      lastServedCategory: null,
    });
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
    toast.success(isAr ? 'تم حفظ استراتيجية الطابور' : 'Queue strategy saved');
  };

  const addToRotation = (vtId: string) => {
    setConfig(c => ({ ...c, rotationPattern: [...c.rotationPattern, vtId] }));
  };

  const removeFromRotation = (idx: number) => {
    setConfig(c => ({
      ...c,
      rotationPattern: c.rotationPattern.filter((_, i) => i !== idx),
    }));
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Layers className="h-5 w-5" />
            {isAr ? 'استراتيجية الطابور' : 'Queue Strategy'}
          </CardTitle>
          <CardDescription>
            {isAr
              ? 'اختر كيفية ترتيب المرضى في طابور الانتظار لهذه العيادة'
              : 'Choose how patients are ordered in the waiting queue for this clinic'}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-5">
          <RadioGroup
            value={config.strategy}
            onValueChange={v => setConfig(c => ({ ...c, strategy: v as QueueStrategy }))}
            className="space-y-3"
            data-testid="radio-queue-strategy"
          >
            {(Object.keys(STRATEGY_INFO) as QueueStrategy[]).map(key => {
              const info = STRATEGY_INFO[key];
              const isSelected = config.strategy === key;
              return (
                <div
                  key={key}
                  className={`flex items-start gap-3 rounded-lg border p-4 transition-colors cursor-pointer ${isSelected ? 'border-primary bg-primary/5' : 'border-border hover:border-primary/40'}`}
                  onClick={() => setConfig(c => ({ ...c, strategy: key }))}
                  data-testid={`option-strategy-${key}`}
                >
                  <RadioGroupItem value={key} id={`strategy-${key}`} className="mt-0.5 shrink-0" />
                  <label htmlFor={`strategy-${key}`} className="cursor-pointer flex-1">
                    <div className="flex items-center gap-2 font-semibold text-sm">
                      {info.icon}
                      {isAr ? info.labelAr : info.label}
                      {isSelected && <Badge className="text-xs ml-auto">{isAr ? 'نشط' : 'Active'}</Badge>}
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">
                      {isAr ? info.descAr : info.desc}
                    </p>
                  </label>
                </div>
              );
            })}
          </RadioGroup>

          <Separator />

          {/* Urgent toggle — not shown for E since it's inherently urgent-first */}
          {config.strategy !== 'E' && (
            <div className="flex items-center justify-between gap-4">
              <div>
                <Label className="flex items-center gap-1.5 font-medium">
                  <AlertTriangle className="h-4 w-4 text-destructive" />
                  {isAr ? 'المستعجل دائماً أولاً' : 'Urgent Always First'}
                </Label>
                <p className="text-xs text-muted-foreground mt-0.5">
                  {isAr
                    ? 'الزيارات المستعجلة تُستدعى قبل أي نوع آخر'
                    : 'Urgent visits are always called before any other type'}
                </p>
              </div>
              <Switch
                checked={config.urgentAlwaysFirst}
                onCheckedChange={v => setConfig(c => ({ ...c, urgentAlwaysFirst: v }))}
                data-testid="switch-urgent-always-first"
              />
            </div>
          )}

          {/* Strategy D: Rotation pattern builder */}
          {config.strategy === 'D' && (
            <>
              <Separator />
              <div className="space-y-3">
                <div>
                  <Label className="flex items-center gap-1.5 font-medium">
                    <RotateCcw className="h-4 w-4 text-orange-500" />
                    {isAr ? 'نمط التدوير' : 'Rotation Pattern'}
                  </Label>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    {isAr
                      ? 'أضف أنواع الزيارات بالترتيب المطلوب. الأنواع المكررة تعني خدمة أكثر من زيارة بنفس النوع قبل الانتقال للتالي.'
                      : 'Add visit types in the desired order. Repeating a type means serving multiple of that type before moving on.'}
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <Select onValueChange={addToRotation}>
                    <SelectTrigger className="flex-1" data-testid="select-rotation-type">
                      <SelectValue placeholder={isAr ? 'أضف نوع للتدوير' : 'Add type to rotation'} />
                    </SelectTrigger>
                    <SelectContent className="max-h-60 overflow-y-auto">
                      {visitTypes.map(vt => (
                        <SelectItem key={vt.id} value={vt.id}>
                          {isAr ? vt.nameAr : vt.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {config.rotationPattern.length === 0 ? (
                  <div className="rounded-lg border border-dashed border-border p-4 text-center text-sm text-muted-foreground">
                    {isAr ? 'لم يُضف أي نوع بعد — سيتم استخدام ترتيب الدفع كبديل' : 'No types added yet — payment order will be used as fallback'}
                  </div>
                ) : (
                  <div className="space-y-2">
                    {config.rotationPattern.map((vtId, idx) => {
                      const vt = visitTypes.find(v => v.id === vtId);
                      return (
                        <div
                          key={`${vtId}-${idx}`}
                          className="flex items-center gap-3 rounded-md border border-border bg-muted/30 px-3 py-2"
                          data-testid={`rotation-item-${idx}`}
                        >
                          <span className="text-xs font-mono text-muted-foreground w-5 shrink-0">{idx + 1}.</span>
                          <span className="text-sm font-medium flex-1">
                            {vt ? (isAr ? vt.nameAr : vt.name) : vtId}
                          </span>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-6 w-6 text-destructive/70 hover:text-destructive shrink-0"
                            onClick={() => removeFromRotation(idx)}
                            data-testid={`button-remove-rotation-${idx}`}
                          >
                            <X className="h-3.5 w-3.5" />
                          </Button>
                        </div>
                      );
                    })}
                    <p className="text-xs text-muted-foreground">
                      {isAr
                        ? `النمط: ${config.rotationPattern.map(id => visitTypes.find(v => v.id === id)?.nameAr || id).join(' → ')} (تكرار)`
                        : `Pattern: ${config.rotationPattern.map(id => visitTypes.find(v => v.id === id)?.name || id).join(' → ')} (repeat)`}
                    </p>
                  </div>
                )}
              </div>
            </>
          )}

          <div className="pt-1">
            <Button onClick={handleSave} className="gap-2" data-testid="button-save-queue-strategy">
              {saved ? <Check className="h-4 w-4" /> : <Save className="h-4 w-4" />}
              {isAr ? 'حفظ الاستراتيجية' : 'Save Strategy'}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

// ─── Main Settings Page ────────────────────────────────────────────────────────
const Settings: React.FC = () => {
  const { language } = useLanguage();
  const { user } = useAuth();
  const { settings, updateSettings } = useClinicSettings();
  const [form, setForm] = useState<ClinicSettings>({ ...settings });
  const fileInputRef = useRef<HTMLInputElement>(null);

  const clinicId = user?.clinicId || 'clinic-1';

  const handleSave = () => {
    updateSettings(form);
    toast.success(language === 'ar' ? 'تم حفظ الإعدادات' : 'Settings saved');
  };

  const set = (key: keyof ClinicSettings, value: string | boolean | number) =>
    setForm(prev => ({ ...prev, [key]: value }));

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      toast.error(language === 'ar' ? 'يرجى اختيار صورة' : 'Please select an image file');
      return;
    }
    if (file.size > 2 * 1024 * 1024) {
      toast.error(language === 'ar' ? 'الحد الأقصى 2 ميجابايت' : 'Max file size is 2MB');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => { set('logo', reader.result as string); };
    reader.readAsDataURL(file);
  };

  return (
    <div className="space-y-6 max-w-2xl">
      <div>
        <h1 className="text-2xl font-bold text-foreground" data-testid="text-settings-title">
          {language === 'ar' ? 'الإعدادات' : 'Settings'}
        </h1>
        <p className="text-muted-foreground">
          {language === 'ar' ? 'إعدادات العيادة والعلامة التجارية' : 'Clinic branding & configuration'}
        </p>
      </div>

      <Tabs defaultValue="clinic-info" className="w-full">
        <TabsList className="w-full" data-testid="tabs-settings">
          <TabsTrigger value="clinic-info" data-testid="tab-clinic-info">
            <Building2 className="h-4 w-4 mr-1.5" />
            {language === 'ar' ? 'معلومات العيادة' : 'Clinic Info'}
          </TabsTrigger>
          <TabsTrigger value="branding" data-testid="tab-branding">
            <ImageIcon className="h-4 w-4 mr-1.5" />
            {language === 'ar' ? 'العلامة التجارية' : 'Branding'}
          </TabsTrigger>
          <TabsTrigger value="tax" data-testid="tab-tax">
            <Percent className="h-4 w-4 mr-1.5" />
            {language === 'ar' ? 'الضريبة' : 'Tax/VAT'}
          </TabsTrigger>
          <TabsTrigger value="visit-types" data-testid="tab-visit-types">
            <ClipboardList className="h-4 w-4 mr-1.5" />
            {language === 'ar' ? 'أنواع الزيارات' : 'Visit Types'}
          </TabsTrigger>
          <TabsTrigger value="queue-strategy" data-testid="tab-queue-strategy">
            <Layers className="h-4 w-4 mr-1.5" />
            {language === 'ar' ? 'الطابور' : 'Queue'}
          </TabsTrigger>
          <TabsTrigger value="notifications" data-testid="tab-notifications">
            <Bell className="h-4 w-4 mr-1.5" />
            {language === 'ar' ? 'الإشعارات' : 'Notifications'}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="clinic-info">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Building2 className="h-5 w-5" />
                {language === 'ar' ? 'معلومات العيادة' : 'Clinic Information'}
              </CardTitle>
              <CardDescription>
                {language === 'ar'
                  ? 'تظهر هذه المعلومات على الفواتير المطبوعة'
                  : 'This information appears on printed invoices'}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label>{language === 'ar' ? 'اسم العيادة (إنجليزي)' : 'Clinic Name (English)'}</Label>
                  <Input data-testid="input-clinic-name" value={form.name} onChange={e => set('name', e.target.value)} />
                </div>
                <div className="space-y-2">
                  <Label>{language === 'ar' ? 'اسم العيادة (عربي)' : 'Clinic Name (Arabic)'}</Label>
                  <Input data-testid="input-clinic-name-ar" value={form.nameAr} onChange={e => set('nameAr', e.target.value)} dir="rtl" />
                </div>
              </div>

              <Separator />

              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label>{language === 'ar' ? 'العنوان (إنجليزي)' : 'Address (English)'}</Label>
                  <Input data-testid="input-address" value={form.address} onChange={e => set('address', e.target.value)} />
                </div>
                <div className="space-y-2">
                  <Label>{language === 'ar' ? 'العنوان (عربي)' : 'Address (Arabic)'}</Label>
                  <Input data-testid="input-address-ar" value={form.addressAr} onChange={e => set('addressAr', e.target.value)} dir="rtl" />
                </div>
              </div>

              <Separator />

              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label>{language === 'ar' ? 'الهاتف' : 'Phone'}</Label>
                  <Input data-testid="input-phone" value={form.phone} onChange={e => set('phone', e.target.value)} dir="ltr" />
                </div>
                <div className="space-y-2">
                  <Label>{language === 'ar' ? 'البريد الإلكتروني' : 'Email'}</Label>
                  <Input data-testid="input-email" value={form.email} onChange={e => set('email', e.target.value)} dir="ltr" />
                </div>
              </div>

              <Separator />

              <div className="space-y-1">
                <div className="flex items-center gap-2 mb-3">
                  <Banknote className="h-4 w-4 text-muted-foreground" />
                  <p className="text-sm font-medium">
                    {language === 'ar' ? 'أسعار الخدمات الأساسية' : 'Base Service Fees'}
                  </p>
                </div>
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label>{language === 'ar' ? 'مبلغ الكشف' : 'Examination Fee'}</Label>
                    <div className="relative">
                      <Input
                        data-testid="input-examination-fee"
                        type="number"
                        min={0}
                        step={5}
                        value={form.examinationFee}
                        onChange={e => set('examinationFee', Number(e.target.value))}
                        className="pe-12"
                        dir="ltr"
                      />
                      <span className="absolute inset-y-0 end-0 flex items-center px-3 text-sm text-muted-foreground select-none pointer-events-none">
                        ج.م
                      </span>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {language === 'ar' ? 'رسوم الكشف الأولي على المريض' : 'Initial patient examination charge'}
                    </p>
                  </div>
                  <div className="space-y-2">
                    <Label>{language === 'ar' ? 'مبلغ الاستشارة' : 'Consultation Fee'}</Label>
                    <div className="relative">
                      <Input
                        data-testid="input-consultation-fee"
                        type="number"
                        min={0}
                        step={5}
                        value={form.consultationFee}
                        onChange={e => set('consultationFee', Number(e.target.value))}
                        className="pe-12"
                        dir="ltr"
                      />
                      <span className="absolute inset-y-0 end-0 flex items-center px-3 text-sm text-muted-foreground select-none pointer-events-none">
                        ج.م
                      </span>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {language === 'ar' ? 'رسوم الاستشارة الطبية المتخصصة' : 'Specialist medical consultation charge'}
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="branding">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <ImageIcon className="h-5 w-5" />
                {language === 'ar' ? 'شعار العيادة' : 'Clinic Logo'}
              </CardTitle>
              <CardDescription>
                {language === 'ar'
                  ? 'يظهر الشعار على الفواتير المطبوعة (الحد الأقصى 2 ميجابايت)'
                  : 'Logo appears on printed invoices (max 2MB)'}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-4">
                <Avatar className="h-16 w-16 rounded-lg">
                  {form.logo ? (
                    <AvatarImage src={form.logo} alt="Clinic logo" className="object-cover" />
                  ) : (
                    <AvatarFallback className="rounded-lg bg-primary/10 text-primary text-lg font-bold">
                      {form.name.slice(0, 2).toUpperCase()}
                    </AvatarFallback>
                  )}
                </Avatar>
                <div className="flex gap-2">
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={handleLogoUpload}
                  />
                  <Button data-testid="button-upload-logo" variant="outline" size="sm" className="gap-1" onClick={() => fileInputRef.current?.click()}>
                    <Upload className="h-4 w-4" />
                    {language === 'ar' ? 'رفع شعار' : 'Upload'}
                  </Button>
                  {form.logo && (
                    <Button data-testid="button-remove-logo" variant="ghost" size="sm" className="gap-1 text-destructive" onClick={() => set('logo', '')}>
                      <X className="h-4 w-4" />
                      {language === 'ar' ? 'إزالة' : 'Remove'}
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="tax">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Percent className="h-5 w-5" />
                {language === 'ar' ? 'إعدادات الضريبة' : 'Tax / VAT Settings'}
              </CardTitle>
              <CardDescription>
                {language === 'ar'
                  ? 'تطبق الضريبة تلقائياً على إجماليات الفواتير'
                  : 'Tax is automatically applied to invoice totals'}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between gap-2">
                <Label htmlFor="tax-toggle" className="flex flex-col gap-1">
                  <span>{language === 'ar' ? 'تفعيل الضريبة' : 'Enable Tax'}</span>
                  <span className="text-xs font-normal text-muted-foreground">
                    {language === 'ar' ? 'إضافة ضريبة على الفواتير' : 'Add tax line to invoices'}
                  </span>
                </Label>
                <Switch
                  id="tax-toggle"
                  data-testid="switch-tax-toggle"
                  checked={form.taxEnabled}
                  onCheckedChange={v => set('taxEnabled', v)}
                />
              </div>

              {form.taxEnabled && (
                <>
                  <Separator />
                  <div className="grid gap-4 sm:grid-cols-3">
                    <div className="space-y-2">
                      <Label>{language === 'ar' ? 'النسبة (%)' : 'Rate (%)'}</Label>
                      <Input
                        data-testid="input-tax-rate"
                        type="number"
                        min={0}
                        max={100}
                        value={form.taxRate}
                        onChange={e => set('taxRate', parseFloat(e.target.value) || 0)}
                        dir="ltr"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>{language === 'ar' ? 'التسمية (إنجليزي)' : 'Label (English)'}</Label>
                      <Input data-testid="input-tax-label" value={form.taxLabel} onChange={e => set('taxLabel', e.target.value)} />
                    </div>
                    <div className="space-y-2">
                      <Label>{language === 'ar' ? 'التسمية (عربي)' : 'Label (Arabic)'}</Label>
                      <Input data-testid="input-tax-label-ar" value={form.taxLabelAr} onChange={e => set('taxLabelAr', e.target.value)} dir="rtl" />
                    </div>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="visit-types">
          <VisitTypesTab clinicId={clinicId} language={language} />
        </TabsContent>

        <TabsContent value="queue-strategy">
          <QueueStrategyTab clinicId={clinicId} language={language} />
        </TabsContent>

        <TabsContent value="notifications">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Bell className="h-5 w-5" />
                {language === 'ar' ? 'إعدادات الإشعارات' : 'Notification Settings'}
              </CardTitle>
              <CardDescription>
                {language === 'ar'
                  ? 'إدارة تفضيلات الإشعارات والتنبيهات'
                  : 'Manage notification preferences and alerts'}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col items-center justify-center py-8 text-center" data-testid="text-notifications-placeholder">
                <Bell className="h-10 w-10 text-muted-foreground/50 mb-3" />
                <p className="text-muted-foreground text-sm">
                  {language === 'ar'
                    ? 'إعدادات الإشعارات ستكون متاحة قريباً'
                    : 'Notification settings coming soon'}
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

      </Tabs>

      <div>
        <Button data-testid="button-save-settings" onClick={handleSave} className="gap-2">
          <Save className="h-4 w-4" />
          {language === 'ar' ? 'حفظ الإعدادات' : 'Save Settings'}
        </Button>
      </div>
    </div>
  );
};

export default Settings;
