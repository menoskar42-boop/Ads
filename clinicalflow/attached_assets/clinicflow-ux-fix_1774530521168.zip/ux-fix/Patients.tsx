import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '@/contexts/LanguageContext';
import { usePatients } from '@/hooks/usePatients';
import { usePermissions } from '@/hooks/usePermissions';
import { formatDate } from '@/lib/dateFormat';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Search, Plus, User, Phone, Calendar, Eye, CalendarPlus, FileText } from 'lucide-react';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';

const Patients: React.FC = () => {
  const { t, language } = useLanguage();
  const navigate = useNavigate();
  const { patients, addPatient } = usePatients();
  const permissions = usePermissions();
  const [searchQuery, setSearchQuery] = useState('');
  const [genderFilter, setGenderFilter] = useState<'all' | 'male' | 'female'>('all');
  const [sortBy, setSortBy] = useState<'name' | 'recent'>('name');
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [newPatient, setNewPatient] = useState({
    name: '', nameAr: '', phone: '', dateOfBirth: '', gender: 'male' as 'male' | 'female',
  });

  const filtered = patients
    .filter(p => {
      const q = searchQuery.toLowerCase().trim();
      const matchesSearch = !q ||
        p.name.toLowerCase().includes(q) ||
        p.nameAr.includes(searchQuery.trim()) ||
        p.phone.replace(/[\s\-()]/g, '').includes(q.replace(/[\s\-()]/g, ''));
      const matchesGender = genderFilter === 'all' || p.gender === genderFilter;
      return matchesSearch && matchesGender;
    })
    .sort((a, b) => {
      if (sortBy === 'recent') return b.createdAt.localeCompare(a.createdAt);
      return (language === 'ar' ? a.nameAr : a.name).localeCompare(language === 'ar' ? b.nameAr : b.name);
    });

  const handleAdd = () => {
    addPatient(newPatient);
    setIsAddDialogOpen(false);
    setNewPatient({ name: '', nameAr: '', phone: '', dateOfBirth: '', gender: 'male' });
  };

  const getAge = (dob: string) => {
    const diff = Date.now() - new Date(dob).getTime();
    return Math.floor(diff / (365.25 * 24 * 60 * 60 * 1000));
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">{t('patients.title')}</h1>
          <p className="text-muted-foreground">{filtered.length} {language === 'ar' ? 'مريض' : 'patients'}</p>
        </div>
        {permissions.canAddPatient && (
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2"><Plus className="h-4 w-4" />{t('patients.add')}</Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle>{t('patients.add')}</DialogTitle>
                <DialogDescription>{language === 'ar' ? 'أضف معلومات المريض الجديد' : 'Add new patient information'}</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>{t('patients.name')} (EN)</Label>
                    <Input value={newPatient.name} onChange={e => setNewPatient({ ...newPatient, name: e.target.value })} placeholder="John Doe" />
                  </div>
                  <div className="space-y-2">
                    <Label>{t('patients.name')} (AR)</Label>
                    <Input value={newPatient.nameAr} onChange={e => setNewPatient({ ...newPatient, nameAr: e.target.value })} placeholder="جون دو" dir="rtl" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>{t('patients.phone')}</Label>
                    <Input value={newPatient.phone} onChange={e => setNewPatient({ ...newPatient, phone: e.target.value })} placeholder="+1 555-0100" />
                  </div>
                  <div className="space-y-2">
                    <Label>{language === 'ar' ? 'تاريخ الميلاد' : 'Date of Birth'}</Label>
                    <Input type="date" value={newPatient.dateOfBirth} onChange={e => setNewPatient({ ...newPatient, dateOfBirth: e.target.value })} />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>{t('patients.gender')}</Label>
                  <Select value={newPatient.gender} onValueChange={(v: 'male' | 'female') => setNewPatient({ ...newPatient, gender: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent className="max-h-60 overflow-y-auto">
                      <SelectItem value="male">{t('patients.male')}</SelectItem>
                      <SelectItem value="female">{t('patients.female')}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>{t('common.cancel')}</Button>
                <Button onClick={handleAdd}>{t('common.save')}</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        )}
      </div>

      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder={language === 'ar' ? 'بحث بالاسم أو رقم الهاتف...' : 'Search by name or phone number...'}
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={genderFilter} onValueChange={(v: 'all' | 'male' | 'female') => setGenderFilter(v)}>
              <SelectTrigger className="w-full sm:w-36">
                <SelectValue placeholder={t('patients.gender')} />
              </SelectTrigger>
              <SelectContent className="max-h-60 overflow-y-auto">
                <SelectItem value="all">{language === 'ar' ? 'الكل' : 'All'}</SelectItem>
                <SelectItem value="male">{t('patients.male')}</SelectItem>
                <SelectItem value="female">{t('patients.female')}</SelectItem>
              </SelectContent>
            </Select>
            <Select value={sortBy} onValueChange={(v: 'name' | 'recent') => setSortBy(v)}>
              <SelectTrigger className="w-full sm:w-36">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="max-h-60 overflow-y-auto">
                <SelectItem value="name">{language === 'ar' ? 'الاسم' : 'Name'}</SelectItem>
                <SelectItem value="recent">{language === 'ar' ? 'الأحدث' : 'Recent'}</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>{t('patients.name')}</TableHead>
                <TableHead>{t('patients.phone')}</TableHead>
                <TableHead>{t('patients.age')}</TableHead>
                <TableHead>{t('patients.gender')}</TableHead>
                <TableHead className="w-32 text-right">{language === 'ar' ? 'إجراءات' : 'Actions'}</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map(patient => (
                <TableRow key={patient.id} className="cursor-pointer hover:bg-accent/50" onClick={() => navigate(`/patients/${patient.id}`)}>
                  <TableCell>
                    <div className="flex items-center gap-3">
                      <div className="h-9 w-9 rounded-full bg-primary/10 flex items-center justify-center">
                        <User className="h-4 w-4 text-primary" />
                      </div>
                      <span className="font-medium">{language === 'ar' ? patient.nameAr : patient.name}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Phone className="h-3 w-3" />{patient.phone}
                    </div>
                  </TableCell>
                  <TableCell>{getAge(patient.dateOfBirth)}</TableCell>
                  <TableCell>
                    <Badge variant="outline">
                      {patient.gender === 'male' ? t('patients.male') : t('patients.female')}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center justify-end gap-1">
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button
                            size="icon"
                            variant="ghost"
                            data-testid={`button-view-profile-${patient.id}`}
                            onClick={(e) => { e.stopPropagation(); navigate(`/patients/${patient.id}`); }}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent>{language === 'ar' ? 'عرض الملف' : 'View Profile'}</TooltipContent>
                      </Tooltip>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button
                            size="icon"
                            variant="ghost"
                            data-testid={`button-book-appointment-${patient.id}`}
                            onClick={(e) => { e.stopPropagation(); navigate(`/appointments?patientId=${patient.id}`); }}
                          >
                            <CalendarPlus className="h-4 w-4" />
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent>{language === 'ar' ? 'حجز موعد' : 'Book Appointment'}</TooltipContent>
                      </Tooltip>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button
                            size="icon"
                            variant="ghost"
                            data-testid={`button-medical-file-${patient.id}`}
                            onClick={(e) => { e.stopPropagation(); navigate(`/patients/${patient.id}?tab=medical`); }}
                          >
                            <FileText className="h-4 w-4" />
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent>{language === 'ar' ? 'الملف الطبي' : 'Medical File'}</TooltipContent>
                      </Tooltip>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
              {filtered.length === 0 && (
                <TableRow>
                  <TableCell colSpan={5} className="py-16">
                    <div className="flex flex-col items-center justify-center gap-3 text-muted-foreground">
                      <User className="h-10 w-10 opacity-40" />
                      <p className="text-sm font-medium">{language === 'ar' ? 'لا يوجد مرضى' : 'No patients found'}</p>
                    </div>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};

export default Patients;
