import React from 'react';
import { useLocation, Link, useNavigate } from 'react-router-dom';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { usePermissions } from '@/hooks/usePermissions';
import { cn } from '@/lib/utils';
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  useSidebar,
} from '@/components/ui/sidebar';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import {
  LayoutDashboard, Users, Calendar, Stethoscope, HeartPulse,
  Receipt, BarChart3, LogOut, ChevronLeft, ChevronRight,
  UserCog, Clock, Settings, FolderKanban, Shield,
  ListOrdered, Building2, User, Tag, Home,
} from 'lucide-react';
import logoImg from '@assets/Untitled_design_1772868317886.png';

const AppSidebar: React.FC = () => {
  const { t, language, isRTL } = useLanguage();
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const { state, toggleSidebar } = useSidebar();
  const permissions = usePermissions();
  const collapsed = state === 'collapsed';

  const menuItems = [
    { icon: LayoutDashboard, label: 'nav.dashboard',       path: '/dashboard',      show: permissions.canViewDashboard },
    { icon: Users,           label: 'nav.patients',        path: '/patients',       show: permissions.canViewPatients },
    { icon: Calendar,        label: 'nav.appointments',    path: '/appointments',   show: permissions.canViewAppointments },
    { icon: ListOrdered,     label: 'nav.queueManagement', path: '/queue',          show: permissions.canViewQueueManagement },
    { icon: Clock,           label: 'doctors.schedule',    path: '/schedule',       show: permissions.canViewSchedule },
    { icon: Stethoscope,     label: 'nav.doctors',         path: '/doctors',        show: permissions.canViewDoctors },
    { icon: FolderKanban,    label: 'nav.specialties',     path: '/specialties',    show: permissions.canViewSpecialties },
    { icon: HeartPulse,      label: 'nav.services',        path: '/services',       show: permissions.canViewServices },
    { icon: Tag,             label: 'nav.offers',          path: '/offers',         show: permissions.canViewOffers },
    { icon: Home,            label: 'nav.homeVisits',      path: '/home-visits',    show: permissions.canViewHomeVisitDashboard },
    { icon: Receipt,         label: 'nav.billing',         path: '/billing',        show: permissions.canViewBilling },
    { icon: BarChart3,       label: 'nav.reports',         path: '/reports',        show: permissions.canViewReports },
    { icon: UserCog,         label: 'nav.staffManagement', path: '/staff',          show: permissions.canViewStaffManagement },
    { icon: Shield,          label: 'nav.documentAudit',   path: '/document-audit', show: permissions.canViewDocumentAudit },
    { icon: Settings,        label: 'nav.settings',        path: '/settings',       show: permissions.canViewSettings },
  ].filter(item => item.show);

  const userName = language === 'ar' ? user?.nameAr : user?.name;
  const initials  = user?.name?.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase() || '?';

  const getRoleBadgeVariant = (role: string) => {
    switch (role) {
      case 'admin':     return 'default';
      case 'doctor':    return 'secondary';
      default:          return 'outline';
    }
  };

  return (
    <Sidebar
      collapsible="icon"
      side={isRTL ? 'right' : 'left'}
      className="border-sidebar-border"
    >
      {/* ── Logo / Title ────────────────────────────────────────────────── */}
      <SidebarHeader className="p-4">
        <div className="flex items-center gap-3">
          <img src={logoImg} alt="ClinicFlow" className="h-10 w-10 rounded-lg object-cover shrink-0" />
          {!collapsed && (
            <div className="overflow-hidden">
              <h1 className="font-semibold text-sm text-sidebar-foreground truncate">
                {t('app.title')}
              </h1>
            </div>
          )}
        </div>
      </SidebarHeader>

      {/* ── Navigation items ────────────────────────────────────────────── */}
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupContent>
            <SidebarMenu>
              {menuItems.map((item) => {
                const isActive = location.pathname === item.path ||
                  (item.path !== '/dashboard' && location.pathname.startsWith(item.path));
                return (
                  <SidebarMenuItem key={item.path} className="relative">
                    {isActive && (
                      <div
                        className={cn(
                          'absolute top-1 bottom-1 w-[3px] rounded-full bg-primary',
                          isRTL ? 'right-0' : 'left-0',
                        )}
                      />
                    )}
                    <SidebarMenuButton
                      asChild
                      isActive={isActive}
                      tooltip={collapsed ? t(item.label) : undefined}
                    >
                      <Link to={item.path} className={cn('gap-3', isRTL ? 'mr-1' : 'ml-1')}>
                        <item.icon className="h-5 w-5" />
                        <span>{t(item.label)}</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                );
              })}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      {/* ── Footer ──────────────────────────────────────────────────────── */}
      <SidebarFooter className="p-4 space-y-3">
        {/* User info */}
        {!collapsed && (
          <div className="flex items-center gap-3 p-2 rounded-lg bg-sidebar-accent">
            <Avatar className="h-9 w-9">
              <AvatarFallback className="bg-primary text-primary-foreground text-sm">
                {initials}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 overflow-hidden">
              <p className="text-sm font-medium text-sidebar-foreground truncate">{userName}</p>
              <Badge variant={getRoleBadgeVariant(user?.role || '')} className="text-xs capitalize">
                {user?.role === 'reception' ? t('auth.receptionist') : t(`auth.${user?.role}`)}
              </Badge>
            </div>
          </div>
        )}

        {/* Doctor quick links */}
        {user?.role === 'doctor' && !collapsed && (
          <>
            <Button
              variant="ghost" size="sm"
              onClick={() => navigate(`/doctor/${user.id}`)}
              className="w-full gap-2 text-sidebar-foreground justify-start"
              data-testid="button-my-profile"
            >
              <User className="h-4 w-4" />
              {language === 'ar' ? 'ملفي الشخصي' : 'My Profile'}
            </Button>
            {user.clinicId && (
              <Button
                variant="ghost" size="sm"
                onClick={() => navigate(`/clinic/${user.clinicId}`)}
                className="w-full gap-2 text-sidebar-foreground justify-start"
                data-testid="button-clinic-profile"
              >
                <Building2 className="h-4 w-4" />
                {language === 'ar' ? 'صفحة العيادة' : 'Clinic Page'}
              </Button>
            )}
          </>
        )}
        {/* Admin quick link to clinic page */}
        {user?.role === 'admin' && user.clinicId && !collapsed && (
          <Button
            variant="ghost" size="sm"
            onClick={() => navigate(`/clinic/${user.clinicId}`)}
            className="w-full gap-2 text-sidebar-foreground justify-start"
            data-testid="button-clinic-profile-admin"
          >
            <Building2 className="h-4 w-4" />
            {language === 'ar' ? 'صفحة العيادة' : 'Clinic Page'}
          </Button>
        )}

        {/* Collapse toggle + logout */}
        <div className={cn('flex gap-2', collapsed ? 'flex-col items-center' : '')}>
          <Button
            variant="ghost" size="icon"
            onClick={toggleSidebar}
            className="text-sidebar-foreground"
            data-testid="button-sidebar-toggle"
          >
            {collapsed
              ? (isRTL ? <ChevronLeft className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />)
              : (isRTL ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />)
            }
          </Button>

          {collapsed ? (
            <Button
              variant="ghost" size="icon"
              onClick={logout}
              className="text-sidebar-foreground"
              data-testid="button-logout"
            >
              <LogOut className="h-4 w-4" />
            </Button>
          ) : (
            <Button
              variant="ghost" size="sm"
              onClick={logout}
              className="flex-1 gap-2 text-sidebar-foreground"
              data-testid="button-logout"
            >
              <LogOut className="h-4 w-4" />
              {t('auth.logout')}
            </Button>
          )}
        </div>
      </SidebarFooter>
    </Sidebar>
  );
};

export default AppSidebar;
