import { User } from '@/types';
import { createStore } from './createStore';
import { CLINIC_IDS } from './clinicStore';

// ── localStorage keys ─────────────────────────────────────────────────────────
const LS_USERS_KEY = 'cf_staff_users';

function loadPersistedUsers(): User[] {
  try {
    const raw = localStorage.getItem(LS_USERS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch { return []; }
}

export function persistUser(user: User): void {
  try {
    const existing = loadPersistedUsers();
    if (existing.some(u => u.id === user.id)) return;
    localStorage.setItem(LS_USERS_KEY, JSON.stringify([...existing, user]));
  } catch { /* graceful */ }
}

// ── Seed (demo) users ─────────────────────────────────────────────────────────
const mockUsers: User[] = [
  // ─── Nile Medical Center (clinic-1) ───
  { id: 'u-1',   name: 'Dr. Sarah Admin',    nameAr: 'د. سارة المدير',   email: 'admin@clinic.demo',      role: 'admin',     clinicId: CLINIC_IDS.NILE_MEDICAL, isActive: true, createdAt: '2024-01-01' },
  { id: 'u-2',   name: 'Dr. Ahmed Hassan',   nameAr: 'د. أحمد حسن',      email: 'ahmed@clinic.demo',      role: 'doctor',    specialtyId: 'sp-1', clinicId: CLINIC_IDS.NILE_MEDICAL, isActive: true, createdAt: '2024-01-15', homeVisitEnabled: true, homeVisitPrice: 400, homeVisitDurationMinutes: 45, homeVisitDailyLimit: 4,  homeVisitRadiusKm: 15, homeVisitAreas: ['Nasr City', 'Heliopolis', 'Maadi', 'Zamalek'] },
  { id: 'u-3',   name: 'Dr. Sarah Mitchell', nameAr: 'د. سارة ميتشل',    email: 'sarah@clinic.demo',      role: 'doctor',    specialtyId: 'sp-2', clinicId: CLINIC_IDS.NILE_MEDICAL, isActive: true, createdAt: '2024-01-20', homeVisitEnabled: true, homeVisitPrice: 500, homeVisitDurationMinutes: 60, homeVisitDailyLimit: 3,  homeVisitRadiusKm: 20, homeVisitAreas: ['New Cairo', 'Fifth Settlement', 'Rehab City', 'Katameya'] },
  { id: 'u-4',   name: 'Dr. Omar Farouk',    nameAr: 'د. عمر فاروق',      email: 'omar@clinic.demo',       role: 'doctor',    specialtyId: 'sp-3', clinicId: CLINIC_IDS.NILE_MEDICAL, isActive: true, createdAt: '2024-02-01' },
  { id: 'u-5',   name: 'Dr. Lisa Chen',      nameAr: 'د. ليزا تشين',      email: 'lisa@clinic.demo',       role: 'doctor',    specialtyId: 'sp-4', clinicId: CLINIC_IDS.NILE_MEDICAL, isActive: true, createdAt: '2024-02-10' },
  { id: 'u-6',   name: 'Maria Santos',       nameAr: 'ماريا سانتوس',      email: 'reception@clinic.demo',  role: 'reception', clinicId: CLINIC_IDS.NILE_MEDICAL, isActive: true, createdAt: '2024-02-01' },
  // ─── Cairo Health Clinic (clinic-2) ───
  { id: 'u-10',  name: 'Dr. Hana Mansour',   nameAr: 'د. هنا منصور',      email: 'admin@cairo.demo',       role: 'admin',     clinicId: CLINIC_IDS.CAIRO_HEALTH, isActive: true, createdAt: '2024-03-15' },
  { id: 'u-11',  name: 'Dr. Karim Nabil',    nameAr: 'د. كريم نبيل',      email: 'doctor@cairo.demo',      role: 'doctor',    specialtyId: 'sp-1', clinicId: CLINIC_IDS.CAIRO_HEALTH, isActive: true, createdAt: '2024-03-20' },
  { id: 'u-12',  name: 'Nour Khaled',        nameAr: 'نور خالد',           email: 'reception@cairo.demo',   role: 'reception', clinicId: CLINIC_IDS.CAIRO_HEALTH, isActive: true, createdAt: '2024-04-01' },
  // ─── Alexandria Care Center (clinic-3) ───
  { id: 'u-20',  name: 'Dr. Tarek Samy',     nameAr: 'د. طارق سامي',      email: 'admin@alex.demo',        role: 'admin',     clinicId: CLINIC_IDS.ALEX_CARE,    isActive: true, createdAt: '2024-06-01' },
  { id: 'u-21',  name: 'Dr. Mona Fawzy',     nameAr: 'د. منى فوزي',       email: 'doctor@alex.demo',       role: 'doctor',    specialtyId: 'sp-2', clinicId: CLINIC_IDS.ALEX_CARE,    isActive: true, createdAt: '2024-06-05' },
  { id: 'u-22',  name: 'Reem Hassan',        nameAr: 'ريم حسن',            email: 'reception@alex.demo',    role: 'reception', clinicId: CLINIC_IDS.ALEX_CARE,    isActive: true, createdAt: '2024-06-10' },
  // ─── Standalone Home-Visit Doctor ───
  { id: 'u-hv1', name: 'Dr. Khaled Mostafa', nameAr: 'د. خالد مصطفى',     email: 'khaled.homevisit@demo.com', role: 'doctor', specialtyId: 'sp-1', clinicId: '', isActive: true, createdAt: '2025-01-10', homeVisitEnabled: true, homeVisitPrice: 600, homeVisitDurationMinutes: 45, homeVisitDailyLimit: 5, homeVisitRadiusKm: 25, homeVisitAreas: ['Nasr City', 'Heliopolis', 'Ain Shams', 'Shubra', 'Matariya'] },
];

// ── Merge seed + approved staff from localStorage ─────────────────────────────
const persistedUsers = loadPersistedUsers();
const allInitialUsers = [
  ...mockUsers,
  ...persistedUsers.filter(p => !mockUsers.some(m => m.id === p.id)),
];

export const userStore = createStore<User>(allInitialUsers);

export const getDoctors            = () => userStore.filter(u => u.role === 'doctor');
export const getActiveDoctors      = () => userStore.filter(u => u.role === 'doctor' && u.isActive);
export const getDoctorsBySpecialty = (specialtyId: string) => userStore.filter(u => u.role === 'doctor' && u.specialtyId === specialtyId && u.isActive);
export const getDoctorsByClinic    = (clinicId: string)    => userStore.filter(u => u.role === 'doctor' && u.clinicId === clinicId && u.isActive);
export const getUsersByClinic      = (clinicId: string)    => userStore.filter(u => u.clinicId === clinicId);
