import React, { createContext, useContext, useState, ReactNode } from 'react';
import { UserRole, Patient } from '@/types';
import { userStore } from '@/stores/userStore';
import { patientStore, persistPatient } from '@/stores/patientStore';
import { getClinicsForDoctor } from '@/stores/doctorClinicStore';
import { registrationStore } from '@/stores/registrationStore';

// ── localStorage keys ─────────────────────────────────────────────────────────
const LS_PASS_KEY = 'cf_patient_passwords';

function loadPasswords(): Record<string, string> {
  try {
    const raw = localStorage.getItem(LS_PASS_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch { return {}; }
}

function savePassword(id: string, hash: string) {
  try {
    const all = loadPasswords();
    all[id] = hash;
    localStorage.setItem(LS_PASS_KEY, JSON.stringify(all));
  } catch { /* graceful */ }
}

export interface AuthUser {
  id: string;
  name: string;
  nameAr: string;
  email: string;
  role: UserRole | 'patient' | 'super_admin';
  specialtyId?: string;
  patientId?: string;
  clinicId: string;
}

interface AuthContextType {
  user: AuthUser | null;
  pendingDoctorClinics: string[] | null;
  pendingDoctorUser: AuthUser | null;
  login: (clinicId: string, role: UserRole) => void;
  loginStaff: (email: string, password: string) => { ok: boolean; error?: string };
  loginAsSuperAdmin: (password: string) => boolean;
  loginAsPatient: (phone: string, password: string) => { ok: boolean; error?: string };
  registerPatient: (data: { name: string; phone: string; email: string; password: string }) => boolean;
  selectClinicForDoctor: (clinicId: string) => void;
  switchClinic: () => void;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const SUPER_ADMIN_PASSWORD = 'superadmin2024';

// ── Seed patient passwords (patientId → password) ────────────────────────────
const PATIENT_PASSWORDS: Record<string, string> = {
  'pt-demo': 'patient2024',
  'pt-1':  'patient123',
  'pt-2':  'patient123',
  'pt-3':  'patient123',
  'pt-4':  'patient123',
  'pt-5':  'patient123',
  'pt-6':  'patient123',
  'pt-7':  'patient123',
  'pt-8':  'patient123',
  'pt-20': 'patient123',
  'pt-21': 'patient123',
  'pt-22': 'patient123',
  'pt-30': 'patient123',
  'pt-31': 'patient123',
};

// ── Staff passwords by userId ─────────────────────────────────────────────────
const STAFF_PASSWORDS: Record<string, string> = {
  'u-1':  'admin123',     // Nile admin
  'u-2':  'doctor123',    // Nile doctor
  'u-3':  'doctor123',    // Nile doctor
  'u-4':  'doctor123',    // Nile doctor
  'u-5':  'doctor123',    // Nile doctor
  'u-6':  'reception123', // Nile reception
  'u-10': 'admin123',     // Cairo admin
  'u-11': 'doctor123',    // Cairo doctor
  'u-12': 'reception123', // Cairo reception
  'u-20': 'admin123',     // Alex admin
  'u-21': 'doctor123',    // Alex doctor
  'u-22': 'reception123', // Alex reception
};

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [pendingDoctorClinics, setPendingDoctorClinics] = useState<string[] | null>(null);
  const [pendingDoctorUser, setPendingDoctorUser] = useState<AuthUser | null>(null);

  // ── Legacy role-picker login (still used by SuperAdmin flow) ─────────────
  const login = (clinicId: string, role: UserRole) => {
    const storeUser = userStore.get(u => u.clinicId === clinicId && u.role === role && u.isActive);
    if (storeUser) {
      const authUser: AuthUser = {
        id: storeUser.id,
        name: storeUser.name,
        nameAr: storeUser.nameAr,
        email: storeUser.email,
        role: storeUser.role,
        specialtyId: storeUser.specialtyId,
        clinicId: storeUser.clinicId,
      };
      if (role === 'doctor') {
        const clinicLinks = getClinicsForDoctor(storeUser.id);
        if (clinicLinks.length > 1) {
          setPendingDoctorUser(authUser);
          setPendingDoctorClinics(clinicLinks);
          return;
        }
      }
      setUser(authUser);
    }
  };

  // ── Staff login by email + password ──────────────────────────────────────
  const loginStaff = (email: string, password: string): { ok: boolean; error?: string } => {
    const e = email.trim().toLowerCase();
    const staffUser = userStore.get(u => u.email.toLowerCase() === e && u.isActive);
    if (!staffUser) {
      return { ok: false, error: 'لم يتم العثور على حساب بهذا البريد الإلكتروني.' };
    }
    // Check hardcoded seed passwords first, then dynamic approved-staff passwords
    let dynamicPasswords: Record<string, string> = {};
    try { dynamicPasswords = JSON.parse(localStorage.getItem('cf_staff_passwords') || '{}'); } catch {}
    const expected = STAFF_PASSWORDS[staffUser.id] ?? dynamicPasswords[staffUser.id];
    if (expected && expected !== password) {
      return { ok: false, error: 'كلمة المرور غير صحيحة.' };
    }
    const authUser: AuthUser = {
      id: staffUser.id, name: staffUser.name, nameAr: staffUser.nameAr,
      email: staffUser.email, role: staffUser.role,
      specialtyId: staffUser.specialtyId, clinicId: staffUser.clinicId,
    };
    if (staffUser.role === 'doctor') {
      const clinicLinks = getClinicsForDoctor(staffUser.id);
      if (clinicLinks.length > 1) {
        setPendingDoctorUser(authUser);
        setPendingDoctorClinics(clinicLinks);
        return { ok: true };
      }
    }
    setUser(authUser);
    return { ok: true };
  };

  const selectClinicForDoctor = (clinicId: string) => {
    if (!pendingDoctorUser) return;
    const doctorInClinic = userStore.get(u => u.clinicId === clinicId && u.role === 'doctor' && u.isActive);
    const finalUser: AuthUser = {
      ...pendingDoctorUser,
      clinicId,
      specialtyId: doctorInClinic?.specialtyId ?? pendingDoctorUser.specialtyId,
    };
    setUser(finalUser);
    setPendingDoctorClinics(null);
    setPendingDoctorUser(null);
  };

  const switchClinic = () => {
    if (!user || user.role !== 'doctor') return;
    const clinicLinks = getClinicsForDoctor(user.id);
    if (clinicLinks.length > 1) {
      setPendingDoctorUser(user);
      setPendingDoctorClinics(clinicLinks);
      setUser(null);
    }
  };

  const loginAsSuperAdmin = (password: string): boolean => {
    if (password !== SUPER_ADMIN_PASSWORD) return false;
    setUser({
      id: 'super-admin',
      name: 'Super Admin',
      nameAr: 'المدير العام',
      email: 'superadmin@clinicflow.io',
      role: 'super_admin',
      clinicId: 'super',
    });
    return true;
  };

  // ── Patient login — phone + password ─────────────────────────────────────
  const loginAsPatient = (phone: string, password: string): { ok: boolean; error?: string } => {
    const trimmed = phone.trim();
    if (!trimmed) return { ok: false, error: 'أدخل رقم الهاتف.' };
    if (!password) return { ok: false, error: 'أدخل كلمة المرور.' };

    // 1. Find patient by phone in patientStore
    let patient = patientStore.get(p => p.phone === trimmed);

    // 2. Fallback: find in registrationStore by phone
    if (!patient) {
      const reg = registrationStore.get(
        r => r.type === 'patient' && r.phone === trimmed
      );
      if (reg) {
        const newPt: Patient = {
          id: `pt-reg-${reg.id}`, name: reg.name, nameAr: reg.name,
          phone: reg.phone, email: reg.email,
          dateOfBirth: '', gender: 'male', createdAt: reg.createdAt,
        };
        const already = patientStore.get(p => p.phone === newPt.phone);
        if (!already) {
          patientStore.add(newPt);
          persistPatient(newPt);
          if (reg.password) savePassword(newPt.id, reg.password);
        }
        patient = already ?? newPt;
      }
    }

    if (!patient) {
      return { ok: false, error: 'لم يتم العثور على حساب بهذا الرقم.' };
    }

    // 3. Validate password
    // a. Check localStorage-stored passwords (registered patients)
    const storedPasswords = loadPasswords();
    const storedPass = storedPasswords[patient.id];
    // b. Check static seed passwords
    const seedPass = PATIENT_PASSWORDS[patient.id];

    const expectedPass = storedPass ?? seedPass;
    if (expectedPass && expectedPass !== password) {
      return { ok: false, error: 'كلمة المرور غير صحيحة.' };
    }

    setUser({
      id: patient.id, name: patient.name, nameAr: patient.nameAr,
      email: patient.email || '', role: 'patient',
      patientId: patient.id, clinicId: patient.clinicId ?? '',
    });
    return { ok: true };
  };

  const registerPatient = (data: { name: string; phone: string; email: string; password: string }): boolean => {
    const existing = patientStore.get(p => p.phone === data.phone || (data.email && p.email === data.email));
    if (existing) return false;

    const patient: Patient = {
      id: `pt-${Date.now()}`,
      name: data.name,
      nameAr: data.name,
      phone: data.phone,
      email: data.email,
      dateOfBirth: '',
      gender: 'male',
      createdAt: new Date().toISOString(),
    };
    patientStore.add(patient);
    persistPatient(patient);
    if (data.password) savePassword(patient.id, data.password);

    setUser({
      id: patient.id,
      name: patient.name,
      nameAr: patient.nameAr,
      email: patient.email || '',
      role: 'patient',
      patientId: patient.id,
      clinicId: '',
    });
    return true;
  };

  const logout = () => {
    setUser(null);
    setPendingDoctorClinics(null);
    setPendingDoctorUser(null);
  };

  return (
    <AuthContext.Provider value={{
      user, pendingDoctorClinics, pendingDoctorUser,
      login, loginStaff, loginAsSuperAdmin, loginAsPatient, registerPatient,
      selectClinicForDoctor, switchClinic, logout,
      isAuthenticated: !!user,
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

// ── Required by useVisits, usePatients, useUsers hooks ────────────────────────
export function getToken(): string | null {
  return localStorage.getItem('cf_token');
}
