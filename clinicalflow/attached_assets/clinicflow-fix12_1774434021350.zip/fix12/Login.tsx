import React, { useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { clinicStore } from '@/stores/clinicStore';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import {
  User, ArrowLeft, Building2, ChevronRight,
  Smartphone, Mail, Lock, Eye, EyeOff, UserPlus, Loader2,
} from 'lucide-react';
import logoImg from '@assets/Untitled_design_1772868317886.png';

type Tab = 'patient' | 'staff';

const T = {
  en: {
    backHome: 'Back to Home', registerNow: 'Sign Up',
    welcomeBack: 'Welcome back', subtitle: 'Sign in to your ClinicFlow account',
    tabPatient: 'Patient', tabStaff: 'Clinic Staff',
    // Patient
    patientTitle: 'Patient Login', patientDesc: 'Enter your registered phone or email',
    phoneLabel: 'Phone Number or Email', phonePh: '01xxxxxxxxx or email@example.com',
    signInPatient: 'Sign In as Patient',
    noAccount: "Don't have an account?", createAccount: 'Create a Patient Account',
    errPatientEmpty: 'Please enter your phone or email.',
    errPatientNotFound: 'No account found. Check your details or register first.',
    // Staff
    staffTitle: 'Clinic Staff Login', staffDesc: 'Sign in with your work email and password',
    emailLabel: 'Work Email', emailPh: 'you@yourclinic.com',
    passLabel: 'Password', passPh: '••••••••',
    signInStaff: 'Sign In',
    forgotPass: 'Contact your clinic admin to reset your password.',
    registerClinic: 'Want to register your clinic?', registerClinicLink: 'Register here',
    // Multi-clinic
    multiTitle: 'Select Your Clinic', multiDesc: 'You are registered in multiple clinics.',
    terms: 'By signing in you agree to our', termsLink: 'Terms of Service',
    and: 'and', privacyLink: 'Privacy Policy',
  },
  ar: {
    backHome: 'العودة للرئيسية', registerNow: 'سجل الآن',
    welcomeBack: 'مرحباً بعودتك', subtitle: 'سجّل دخولك إلى حسابك في ClinicFlow',
    tabPatient: 'مريض', tabStaff: 'موظفو العيادة',
    // Patient
    patientTitle: 'دخول المرضى', patientDesc: 'أدخل رقم هاتفك أو بريدك الإلكتروني المسجّل',
    phoneLabel: 'رقم الهاتف أو البريد الإلكتروني', phonePh: '01xxxxxxxxx أو email@example.com',
    signInPatient: 'تسجيل الدخول كمريض',
    noAccount: 'ليس لديك حساب؟', createAccount: 'إنشاء حساب مريض',
    errPatientEmpty: 'من فضلك أدخل رقم الهاتف أو البريد الإلكتروني.',
    errPatientNotFound: 'لم يتم العثور على حساب. تحقق من البيانات أو سجّل أولاً.',
    // Staff
    staffTitle: 'دخول موظفي العيادة', staffDesc: 'سجّل دخولك ببريدك الإلكتروني وكلمة المرور',
    emailLabel: 'البريد الإلكتروني للعمل', emailPh: 'you@yourclinic.com',
    passLabel: 'كلمة المرور', passPh: '••••••••',
    signInStaff: 'تسجيل الدخول',
    forgotPass: 'تواصل مع مدير العيادة لإعادة تعيين كلمة المرور.',
    registerClinic: 'تريد تسجيل عيادتك؟', registerClinicLink: 'سجّل هنا',
    // Multi-clinic
    multiTitle: 'اختر عيادتك', multiDesc: 'أنت مسجّل في أكثر من عيادة.',
    terms: 'بتسجيل دخولك فأنت توافق على', termsLink: 'شروط الخدمة',
    and: 'و', privacyLink: 'سياسة الخصوصية',
  },
} as const;

const Login: React.FC = () => {
  const { loginAsPatient, loginWithCredentials, pendingDoctorClinics, selectClinicForDoctor } = useAuth();
  const { language, setLanguage, isRTL } = useLanguage();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const returnDoctor = searchParams.get('returnDoctor');

  const t    = T[language as 'en' | 'ar'];
  const isAr = language === 'ar';

  const [tab, setTab] = useState<Tab>('patient');

  // Patient state
  const [patientId, setPatientId]         = useState('');
  const [patientError, setPatientError]   = useState('');

  // Staff state
  const [staffEmail, setStaffEmail]       = useState('');
  const [staffPass, setStaffPass]         = useState('');
  const [showPass, setShowPass]           = useState(false);
  const [staffError, setStaffError]       = useState('');
  const [staffLoading, setStaffLoading]   = useState(false);

  const clinics = clinicStore.getAll().filter(c => c.isActive);

  // ── Doctor multi-clinic selection ─────────────────────────────────────────
  if (pendingDoctorClinics) {
    const doctorClinics = pendingDoctorClinics
      .map(cid => clinicStore.filter(c => c.id === cid)[0])
      .filter(Boolean);
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4" dir={isRTL ? 'rtl' : 'ltr'}>
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <Building2 className="h-10 w-10 text-primary mx-auto mb-2" />
            <CardTitle>{t.multiTitle}</CardTitle>
            <CardDescription>{t.multiDesc}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {doctorClinics.map(clinic => (
              <button
                key={clinic.id}
                onClick={() => { selectClinicForDoctor(clinic.id); navigate('/dashboard'); }}
                className="w-full flex items-center gap-3 p-4 rounded-lg border border-border hover:border-primary hover:bg-primary/5 transition-all text-start"
                data-testid={`clinic-select-${clinic.id}`}
              >
                <Building2 className="h-5 w-5 text-primary shrink-0" />
                <div className="min-w-0 flex-1">
                  <div className="font-medium text-foreground truncate">{isAr ? clinic.nameAr : clinic.name}</div>
                  <div className="text-sm text-muted-foreground truncate">{isAr ? clinic.cityAr : clinic.city}</div>
                </div>
                <ChevronRight className={`h-4 w-4 text-muted-foreground shrink-0 ${isRTL ? 'rotate-180' : ''}`} />
              </button>
            ))}
          </CardContent>
        </Card>
      </div>
    );
  }

  // ── Handlers ──────────────────────────────────────────────────────────────
  const handlePatientLogin = () => {
    setPatientError('');
    if (!patientId.trim()) { setPatientError(t.errPatientEmpty); return; }
    const ok = loginAsPatient(patientId);
    if (ok) {
      if (returnDoctor) navigate(`/patient/book?doctor=${returnDoctor}`);
      else navigate('/patient/appointments');
    } else {
      setPatientError(t.errPatientNotFound);
    }
  };

  const handleStaffLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setStaffError('');
    if (!staffEmail.trim() || !staffPass) { setStaffError(isAr ? 'أدخل البريد الإلكتروني وكلمة المرور.' : 'Enter email and password.'); return; }
    setStaffLoading(true);
    // Tiny delay for UX feel
    await new Promise(r => setTimeout(r, 300));
    const { ok, error } = loginWithCredentials(staffEmail, staffPass);
    setStaffLoading(false);
    if (ok) {
      navigate('/dashboard');
    } else {
      setStaffError(error || (isAr ? 'بيانات غير صحيحة.' : 'Invalid credentials.'));
    }
  };

  const TABS = [
    { key: 'patient' as Tab, label: t.tabPatient, icon: <User className="h-4 w-4" /> },
    { key: 'staff'   as Tab, label: t.tabStaff,   icon: <Building2 className="h-4 w-4" /> },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-background to-blue-50/30 flex flex-col" dir={isRTL ? 'rtl' : 'ltr'}>
      {/* Header */}
      <header className="border-b border-border bg-card/80 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-3 hover:opacity-80 transition-opacity">
            <img src={logoImg} alt="ClinicFlow" className="h-9 w-9 rounded-lg object-cover" />
            <span className="font-semibold text-foreground hidden sm:inline">ClinicFlow</span>
          </Link>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={() => setLanguage(isAr ? 'en' : 'ar')}>
              {isAr ? 'EN' : 'AR'}
            </Button>
            <Button variant="outline" size="sm" asChild>
              <Link to="/register" className="gap-1.5 flex items-center" data-testid="button-header-register">
                <UserPlus className="h-4 w-4" />
                {t.registerNow}
              </Link>
            </Button>
            <Button variant="ghost" size="sm" asChild>
              <Link to="/" className="gap-2 flex items-center">
                <ArrowLeft className={`h-4 w-4 ${isRTL ? 'rotate-180' : ''}`} />
                {t.backHome}
              </Link>
            </Button>
          </div>
        </div>
      </header>

      <main className="flex-1 flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          <div className="text-center mb-6">
            <h1 className="text-2xl font-bold text-foreground">{t.welcomeBack}</h1>
            <p className="text-muted-foreground mt-1">{t.subtitle}</p>
          </div>

          {/* Tabs */}
          <div className="flex rounded-lg bg-muted p-1 mb-6 gap-1">
            {TABS.map(tb => (
              <button
                key={tb.key}
                onClick={() => setTab(tb.key)}
                className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-md text-sm font-medium transition-all ${
                  tab === tb.key
                    ? 'bg-background text-foreground shadow-sm'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
                data-testid={`tab-${tb.key}`}
              >
                {tb.icon}
                <span>{tb.label}</span>
              </button>
            ))}
          </div>

          {/* ── PATIENT TAB ── */}
          {tab === 'patient' && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="h-5 w-5 text-blue-600" />
                  {t.patientTitle}
                </CardTitle>
                <CardDescription>{t.patientDesc}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="patient-id">{t.phoneLabel}</Label>
                  <div className="relative">
                    <Smartphone className={`absolute ${isRTL ? 'right-3' : 'left-3'} top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground`} />
                    <Input
                      id="patient-id"
                      className={isRTL ? 'pr-9' : 'pl-9'}
                      placeholder={t.phonePh}
                      value={patientId}
                      onChange={e => { setPatientId(e.target.value); setPatientError(''); }}
                      onKeyDown={e => e.key === 'Enter' && handlePatientLogin()}
                      data-testid="input-patient-identifier"
                    />
                  </div>
                  {patientError && <p className="text-sm text-destructive">{patientError}</p>}
                </div>
                <Button className="w-full" onClick={handlePatientLogin} data-testid="button-patient-login">
                  {t.signInPatient}
                </Button>
                <Separator />
                <div className="space-y-2 text-center">
                  <p className="text-sm text-muted-foreground">{t.noAccount}</p>
                  <Button variant="outline" className="w-full gap-2" asChild>
                    <Link to="/register?type=patient" data-testid="button-create-account">
                      <UserPlus className="h-4 w-4" />
                      {t.createAccount}
                    </Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* ── CLINIC STAFF TAB — email + password ── */}
          {tab === 'staff' && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Building2 className="h-5 w-5 text-emerald-600" />
                  {t.staffTitle}
                </CardTitle>
                <CardDescription>{t.staffDesc}</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleStaffLogin} className="space-y-4" noValidate>
                  {/* Email */}
                  <div className="space-y-1.5">
                    <Label htmlFor="staff-email">{t.emailLabel}</Label>
                    <div className="relative">
                      <Mail className={`absolute ${isRTL ? 'right-3' : 'left-3'} top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground`} />
                      <Input
                        id="staff-email"
                        type="email"
                        className={isRTL ? 'pr-9' : 'pl-9'}
                        placeholder={t.emailPh}
                        autoComplete="email"
                        value={staffEmail}
                        onChange={e => { setStaffEmail(e.target.value); setStaffError(''); }}
                        data-testid="input-staff-email"
                      />
                    </div>
                  </div>
                  {/* Password */}
                  <div className="space-y-1.5">
                    <Label htmlFor="staff-pass">{t.passLabel}</Label>
                    <div className="relative">
                      <Lock className={`absolute ${isRTL ? 'right-3' : 'left-3'} top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground`} />
                      <Input
                        id="staff-pass"
                        type={showPass ? 'text' : 'password'}
                        className={isRTL ? 'pr-9 ps-9' : 'pl-9 pr-9'}
                        placeholder={t.passPh}
                        autoComplete="current-password"
                        value={staffPass}
                        onChange={e => { setStaffPass(e.target.value); setStaffError(''); }}
                        data-testid="input-staff-password"
                      />
                      <button
                        type="button"
                        tabIndex={-1}
                        onMouseDown={e => e.preventDefault()}
                        onClick={() => setShowPass(v => !v)}
                        className={`absolute ${isRTL ? 'left-3' : 'right-3'} top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground`}
                      >
                        {showPass ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </button>
                    </div>
                  </div>

                  {/* Error */}
                  {staffError && (
                    <p className="text-sm text-destructive bg-destructive/5 border border-destructive/20 rounded px-3 py-2">
                      {staffError}
                    </p>
                  )}

                  <Button type="submit" className="w-full bg-emerald-600 hover:bg-emerald-700" disabled={staffLoading} data-testid="button-staff-login">
                    {staffLoading
                      ? <><Loader2 className="h-4 w-4 animate-spin me-2" />{isAr ? 'جاري الدخول...' : 'Signing in...'}</>
                      : t.signInStaff
                    }
                  </Button>

                  <p className="text-center text-xs text-muted-foreground">{t.forgotPass}</p>

                  <Separator />
                  <p className="text-center text-xs text-muted-foreground">
                    {t.registerClinic}{' '}
                    <Link to="/register?type=clinic" className="text-primary hover:underline font-medium" data-testid="link-register-clinic">
                      {t.registerClinicLink}
                    </Link>
                  </p>
                </form>
              </CardContent>
            </Card>
          )}

          <p className="text-center text-xs text-muted-foreground mt-6">
            {t.terms}{' '}
            <span className="text-primary cursor-pointer hover:underline">{t.termsLink}</span>
            {' '}{t.and}{' '}
            <span className="text-primary cursor-pointer hover:underline">{t.privacyLink}</span>
          </p>
        </div>
      </main>
    </div>
  );
};

export default Login;
