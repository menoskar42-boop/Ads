import React, { createContext, useContext, useState, ReactNode } from 'react';
import { UserRole, Patient } from '@/types';
import { userStore } from '@/stores/userStore';
import { patientStore } from '@/stores/patientStore';
import { getClinicsForDoctor } from '@/stores/doctorClinicStore';
import { registrationStore } from '@/stores/registrationStore';

export interface AuthUser {
  id: string;
  name: string;
  nameAr: string;
  email: string;
  role: UserRole | 'patient' | 'super_admin';
  specialtyId?: string;
  patientId?: string;
  clinicId: string;
}

interface AuthContextType {
  user: AuthUser | null;
  pendingDoctorClinics: string[] | null;
  pendingDoctorUser: AuthUser | null;
  // Clinic staff: email + password login
  loginWithCredentials: (email: string, password: string) => { ok: boolean; error?: string };
  // Patient: phone or email (no password — keeps working as before)
  loginAsPatient: (identifier: string) => boolean;
  // Legacy tab-based (kept for internal use)
  login: (clinicId: string, role: UserRole) => void;
  loginAsSuperAdmin: (password: string) => boolean;
  registerPatient: (data: { name: string; phone: string; email: string; password: string }) => boolean;
  selectClinicForDoctor: (clinicId: string) => void;
  switchClinic: () => void;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const SUPER_ADMIN_PASSWORD = 'superadmin2024';

// ── Password registry for clinic staff ───────────────────────────────────────
// Format: { [email]: password }
// These are the real passwords for each demo user.
// When you add a real clinic via SuperAdmin, add their credentials here too.
const STAFF_PASSWORDS: Record<string, string> = {
  // ── Nile Medical Center (clinic-1) ──
  'admin@clinic.demo':     'admin123',
  'ahmed@clinic.demo':     'doctor123',
  'sarah@clinic.demo':     'doctor123',
  'omar@clinic.demo':      'doctor123',
  'lisa@clinic.demo':      'doctor123',
  'reception@clinic.demo': 'reception123',
  // ── Cairo Health Clinic (clinic-2) ──
  'admin@cairo.demo':      'admin123',
  'doctor@cairo.demo':     'doctor123',
  'reception@cairo.demo':  'reception123',
  // ── Alexandria Care Center (clinic-3) ──
  'admin@alex.demo':       'admin123',
  'doctor@alex.demo':      'doctor123',
  'reception@alex.demo':   'reception123',
};

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser]                         = useState<AuthUser | null>(null);
  const [pendingDoctorClinics, setPendingDoctorClinics] = useState<string[] | null>(null);
  const [pendingDoctorUser, setPendingDoctorUser]       = useState<AuthUser | null>(null);

  // ── loginWithCredentials (email + password) ───────────────────────────────
  // Used by the Staff tab in Login.tsx
  const loginWithCredentials = (email: string, password: string): { ok: boolean; error?: string } => {
    const trimmedEmail = email.trim().toLowerCase();

    const staffUser = userStore.get(u => u.email.toLowerCase() === trimmedEmail && u.isActive);
    if (!staffUser) {
      return { ok: false, error: 'لم يتم العثور على حساب بهذا البريد الإلكتروني.' };
    }

    // Check password: use registry first, fallback to any password if not set
    const expected = STAFF_PASSWORDS[staffUser.email.toLowerCase()];
    if (expected && expected !== password) {
      return { ok: false, error: 'كلمة المرور غير صحيحة.' };
    }
    // If no password set yet in registry, accept any password (first login)
    if (!expected) {
      STAFF_PASSWORDS[staffUser.email.toLowerCase()] = password;
    }

    const authUser: AuthUser = {
      id:          staffUser.id,
      name:        staffUser.name,
      nameAr:      staffUser.nameAr,
      email:       staffUser.email,
      role:        staffUser.role,
      specialtyId: staffUser.specialtyId,
      clinicId:    staffUser.clinicId,
    };

    if (staffUser.role === 'doctor') {
      const clinicLinks = getClinicsForDoctor(staffUser.id);
      if (clinicLinks.length > 1) {
        setPendingDoctorUser(authUser);
        setPendingDoctorClinics(clinicLinks);
        return { ok: true };
      }
    }

    setUser(authUser);
    return { ok: true };
  };

  // ── loginAsPatient (phone or email, no password) ──────────────────────────
  const loginAsPatient = (identifier: string): boolean => {
    const trimmed = identifier.trim();

    // 1. patientStore
    const patient = patientStore.get(
      p => p.phone === trimmed || (p.email && p.email === trimmed)
    );
    if (patient) {
      setUser({
        id: patient.id, name: patient.name, nameAr: patient.nameAr,
        email: patient.email || '', role: 'patient',
        patientId: patient.id, clinicId: patient.clinicId ?? '',
      });
      return true;
    }

    // 2. registrationStore (newly registered patients)
    const reg = registrationStore.get(
      r => r.type === 'patient' && (r.phone === trimmed || r.email === trimmed)
    );
    if (reg) {
      const newPatient: Patient = {
        id: `pt-reg-${reg.id}`, name: reg.name, nameAr: reg.name,
        phone: reg.phone, email: reg.email,
        dateOfBirth: '', gender: 'male', createdAt: reg.createdAt,
      };
      const already = patientStore.get(p => p.phone === newPatient.phone);
      if (!already) patientStore.add(newPatient);
      const final = already ?? newPatient;
      setUser({
        id: final.id, name: final.name, nameAr: final.nameAr,
        email: final.email || '', role: 'patient',
        patientId: final.id, clinicId: '',
      });
      return true;
    }

    return false;
  };

  // ── Legacy methods (kept) ─────────────────────────────────────────────────
  const login = (clinicId: string, role: UserRole) => {
    const storeUser = userStore.get(u => u.clinicId === clinicId && u.role === role && u.isActive);
    if (!storeUser) return;
    const authUser: AuthUser = {
      id: storeUser.id, name: storeUser.name, nameAr: storeUser.nameAr,
      email: storeUser.email, role: storeUser.role,
      specialtyId: storeUser.specialtyId, clinicId: storeUser.clinicId,
    };
    if (role === 'doctor') {
      const links = getClinicsForDoctor(storeUser.id);
      if (links.length > 1) { setPendingDoctorUser(authUser); setPendingDoctorClinics(links); return; }
    }
    setUser(authUser);
  };

  const selectClinicForDoctor = (clinicId: string) => {
    if (!pendingDoctorUser) return;
    const d = userStore.get(u => u.clinicId === clinicId && u.role === 'doctor' && u.isActive);
    setUser({ ...pendingDoctorUser, clinicId, specialtyId: d?.specialtyId ?? pendingDoctorUser.specialtyId });
    setPendingDoctorClinics(null);
    setPendingDoctorUser(null);
  };

  const switchClinic = () => {
    if (!user || user.role !== 'doctor') return;
    const links = getClinicsForDoctor(user.id);
    if (links.length > 1) { setPendingDoctorUser(user); setPendingDoctorClinics(links); setUser(null); }
  };

  const loginAsSuperAdmin = (password: string): boolean => {
    if (password !== SUPER_ADMIN_PASSWORD) return false;
    setUser({ id: 'super-admin', name: 'Super Admin', nameAr: 'المدير العام', email: 'superadmin@clinicflow.io', role: 'super_admin', clinicId: 'super' });
    return true;
  };

  const registerPatient = (data: { name: string; phone: string; email: string; password: string }): boolean => {
    const existing = patientStore.get(p => p.phone === data.phone || (data.email && p.email === data.email));
    if (existing) return false;
    const patient: Patient = {
      id: `pt-${Date.now()}`, name: data.name, nameAr: data.name,
      phone: data.phone, email: data.email,
      dateOfBirth: '', gender: 'male', createdAt: new Date().toISOString(),
    };
    patientStore.add(patient);
    setUser({ id: patient.id, name: patient.name, nameAr: patient.nameAr, email: patient.email || '', role: 'patient', patientId: patient.id, clinicId: '' });
    return true;
  };

  const logout = () => { setUser(null); setPendingDoctorClinics(null); setPendingDoctorUser(null); };

  return (
    <AuthContext.Provider value={{
      user, pendingDoctorClinics, pendingDoctorUser,
      loginWithCredentials, loginAsPatient, login,
      loginAsSuperAdmin, registerPatient,
      selectClinicForDoctor, switchClinic, logout,
      isAuthenticated: !!user,
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within an AuthProvider');
  return ctx;
};
