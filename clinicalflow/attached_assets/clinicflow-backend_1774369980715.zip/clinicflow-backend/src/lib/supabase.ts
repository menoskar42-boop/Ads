import { createClient } from '@supabase/supabase-js';

const url = process.env.SUPABASE_URL!;
const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY!;
const anonKey   = process.env.SUPABASE_ANON_KEY!;

if (!url || !serviceKey || !anonKey) {
  throw new Error('Missing Supabase env vars. Copy .env.example → .env and fill in values.');
}

/** Service-role client — bypasses RLS. Use ONLY in trusted server code. */
export const supabaseAdmin = createClient(url, serviceKey, {
  auth: { autoRefreshToken: false, persistSession: false },
});

/** Anon client — respects RLS. Use for user-context operations. */
export const supabaseAnon = createClient(url, anonKey);

/**
 * Build a Supabase client that acts as the authenticated user.
 * Pass the JWT from the Authorization header.
 */
export function supabaseAs(jwt: string) {
  return createClient(url, anonKey, {
    global: { headers: { Authorization: `Bearer ${jwt}` } },
    auth:   { autoRefreshToken: false, persistSession: false },
  });
}
