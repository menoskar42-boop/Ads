import 'dotenv/config';
import express        from 'express';
import cors           from 'cors';
import helmet         from 'helmet';
import rateLimit      from 'express-rate-limit';

import authRouter                                       from './routes/auth.js';
import queueRouter                                      from './routes/queue.js';
import visitsRouter                                     from './routes/visits.js';
import billingRouter                                    from './routes/billing.js';
import { patientsRouter, appointmentsRouter, reportsRouter }
  from './routes/patients-appointments-reports.js';

const app  = express();
const PORT = process.env.PORT || 3001;

// ── Security ─────────────────────────────────────────────────
app.use(helmet());
app.use(cors({
  origin: (process.env.ALLOWED_ORIGINS || 'http://localhost:5000').split(','),
  credentials: true,
}));
app.use(express.json({ limit: '2mb' }));

// ── Rate limiting ────────────────────────────────────────────
app.use('/api/auth/login', rateLimit({
  windowMs: 15 * 60 * 1000,  // 15 min
  max: 20,
  message: { error: 'Too many login attempts. Try again in 15 minutes.' },
}));
app.use('/api', rateLimit({
  windowMs: 60 * 1000,
  max: 300,
  message: { error: 'Too many requests.' },
}));

// ── Routes ───────────────────────────────────────────────────
app.use('/api/auth',         authRouter);
app.use('/api/queue',        queueRouter);
app.use('/api/visits',       visitsRouter);
app.use('/api/billing',      billingRouter);
app.use('/api/patients',     patientsRouter);
app.use('/api/appointments', appointmentsRouter);
app.use('/api/reports',      reportsRouter);

// ── Health check ─────────────────────────────────────────────
app.get('/health', (_req, res) => res.json({ status: 'ok', ts: new Date().toISOString() }));

// ── 404 ──────────────────────────────────────────────────────
app.use((_req, res) => res.status(404).json({ error: 'Route not found' }));

// ── Global error handler ─────────────────────────────────────
app.use((err: Error, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
  console.error('[ERROR]', err.message);
  res.status(500).json({ error: 'Internal server error' });
});

app.listen(PORT, () => {
  console.log(`\n✅ ClinicFlow API running on http://localhost:${PORT}`);
  console.log(`   ENV: ${process.env.NODE_ENV || 'development'}`);
  console.log(`   Supabase: ${process.env.SUPABASE_URL}\n`);
});
