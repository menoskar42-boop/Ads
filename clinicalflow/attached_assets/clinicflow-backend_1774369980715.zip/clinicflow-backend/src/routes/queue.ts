import { Router } from 'express';
import { z }       from 'zod';
import { supabaseAs, supabaseAdmin } from '../lib/supabase.js';
import { authenticate, requireActiveSubscription, requireRole } from '../middleware/auth.js';
import { validate } from '../middleware/validate.js';

const router = Router();
const guard  = [authenticate, requireActiveSubscription];

// ── GET /queue/today  ─────────────────────────────────────────
// Returns today's queue for the caller's clinic, sorted by:
//   1. urgent first
//   2. arrival_time (= payment time) ascending
router.get('/today', ...guard, async (req, res) => {
  const db = supabaseAs(req.auth.jwt);

  const { data, error } = await db
    .from('queue_today')           // view with queue_position pre-computed
    .select('*')
    .eq('clinic_id', req.auth.clinicId)
    .order('queue_position', { ascending: true });

  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

// ── PATCH /queue/:visitId/status  ────────────────────────────
// Reception & doctor can advance visit status
const StatusSchema = z.object({
  status: z.enum(['checked_in','waiting','in_consultation','completed','no_show','cancelled']),
});

router.patch(
  '/:visitId/status',
  ...guard,
  requireRole('admin', 'reception', 'doctor'),
  validate(StatusSchema),
  async (req, res) => {
    const { visitId } = req.params;
    const { status }  = req.body;
    const db = supabaseAs(req.auth.jwt);

    // Doctors can only update their OWN patients
    if (req.auth.role === 'doctor') {
      const { data: visit } = await supabaseAdmin
        .from('visits').select('doctor_id').eq('id', visitId).single();
      if (visit?.doctor_id !== req.auth.userId) {
        return res.status(403).json({ error: 'You can only update your own patients' });
      }
    }

    const { data, error } = await db
      .from('visits')
      .update({ status, updated_at: new Date().toISOString() })
      .eq('id', visitId)
      .eq('clinic_id', req.auth.clinicId)
      .select()
      .single();

    if (error) return res.status(500).json({ error: error.message });
    if (!data)  return res.status(404).json({ error: 'Visit not found' });
    res.json(data);
  }
);

// ── PATCH /queue/:visitId/urgent  ────────────────────────────
// Toggle urgent — bumps patient to front of queue
router.patch(
  '/:visitId/urgent',
  ...guard,
  requireRole('admin', 'reception'),
  async (req, res) => {
    const { visitId } = req.params;
    const db = supabaseAs(req.auth.jwt);

    const { data, error } = await db
      .from('visits')
      .update({ is_urgent: true, updated_at: new Date().toISOString() })
      .eq('id', visitId)
      .eq('clinic_id', req.auth.clinicId)
      .select()
      .single();

    if (error) return res.status(500).json({ error: error.message });
    res.json(data);
  }
);

export default router;
