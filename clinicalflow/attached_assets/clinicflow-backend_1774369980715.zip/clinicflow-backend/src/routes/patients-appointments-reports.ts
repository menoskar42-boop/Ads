import { Router } from 'express';
import { z }       from 'zod';
import { supabaseAs, supabaseAdmin } from '../lib/supabase.js';
import { authenticate, requireActiveSubscription, requireRole } from '../middleware/auth.js';
import { validate } from '../middleware/validate.js';

export const patientsRouter = Router();
export const appointmentsRouter = Router();
export const reportsRouter = Router();

const guard = [authenticate, requireActiveSubscription];

// ═══════════════════════════════════════════════════════════
// PATIENTS
// ═══════════════════════════════════════════════════════════

const PatientSchema = z.object({
  name:        z.string().min(2),
  nameAr:      z.string().default(''),
  phone:       z.string().min(7),
  email:       z.string().email().optional(),
  dateOfBirth: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
  gender:      z.enum(['male', 'female']).optional(),
  nationalId:  z.string().optional(),
});

patientsRouter.get('/', ...guard, async (req, res) => {
  const db = supabaseAs(req.auth.jwt);
  const { search, page = '1', limit = '50' } = req.query;
  const offset = (Number(page) - 1) * Number(limit);

  let query = db
    .from('patients')
    .select('*', { count: 'exact' })
    .eq('clinic_id', req.auth.clinicId)
    .order('created_at', { ascending: false })
    .range(offset, offset + Number(limit) - 1);

  if (search) {
    query = query.or(
      `name.ilike.%${search}%,name_ar.ilike.%${search}%,phone.ilike.%${search}%,national_id.ilike.%${search}%`
    );
  }

  const { data, error, count } = await query;
  if (error) return res.status(500).json({ error: error.message });
  res.json({ data, total: count, page: Number(page), limit: Number(limit) });
});

patientsRouter.get('/:id', ...guard, async (req, res) => {
  const db = supabaseAs(req.auth.jwt);
  const { data, error } = await db
    .from('patients')
    .select(`
      *,
      visits(id, date, status, doctor_id, visit_type_id),
      vital_signs(id, systolic, diastolic, heart_rate, temperature, weight, recorded_at),
      medical_notes(id, category, title, created_at),
      prescriptions(id, status, prescribed_at)
    `)
    .eq('id', req.params.id)
    .eq('clinic_id', req.auth.clinicId)
    .single();

  if (error) return res.status(404).json({ error: 'Patient not found' });
  res.json(data);
});

patientsRouter.post('/', ...guard, requireRole('admin', 'reception'), validate(PatientSchema), async (req, res) => {
  const { data, error } = await supabaseAdmin
    .from('patients')
    .insert({
      clinic_id:    req.auth.clinicId,
      name:         req.body.name,
      name_ar:      req.body.nameAr,
      phone:        req.body.phone,
      email:        req.body.email,
      date_of_birth: req.body.dateOfBirth,
      gender:       req.body.gender,
      national_id:  req.body.nationalId,
    })
    .select()
    .single();

  if (error) return res.status(500).json({ error: error.message });
  res.status(201).json(data);
});

patientsRouter.patch('/:id', ...guard, requireRole('admin', 'reception'), validate(PatientSchema.partial()), async (req, res) => {
  const db = supabaseAs(req.auth.jwt);
  const updates: Record<string, any> = {};
  if (req.body.name)        updates.name = req.body.name;
  if (req.body.nameAr)      updates.name_ar = req.body.nameAr;
  if (req.body.phone)       updates.phone = req.body.phone;
  if (req.body.email)       updates.email = req.body.email;
  if (req.body.dateOfBirth) updates.date_of_birth = req.body.dateOfBirth;
  if (req.body.gender)      updates.gender = req.body.gender;
  if (req.body.nationalId)  updates.national_id = req.body.nationalId;

  const { data, error } = await db.from('patients').update(updates)
    .eq('id', req.params.id).eq('clinic_id', req.auth.clinicId).select().single();
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

// ═══════════════════════════════════════════════════════════
// APPOINTMENTS
// ═══════════════════════════════════════════════════════════

const AppointmentSchema = z.object({
  patientId:    z.string().uuid(),
  doctorId:     z.string().uuid(),
  specialtyId:  z.string().uuid().optional(),
  visitTypeId:  z.string().uuid().optional(),
  date:         z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  time:         z.string().regex(/^\d{2}:\d{2}$/),
  isUrgent:     z.boolean().default(false),
  notes:        z.string().optional(),
  isHomeVisit:  z.boolean().default(false),
  homeAddress:  z.string().optional(),
  homeArea:     z.string().optional(),
  homeCity:     z.string().optional(),
});

appointmentsRouter.get('/', ...guard, async (req, res) => {
  const db = supabaseAs(req.auth.jwt);
  const { date, doctorId, status } = req.query;

  let query = db
    .from('appointments')
    .select(`
      *,
      patient:patients(id, name, name_ar, phone),
      doctor:users!appointments_doctor_id_fkey(id, name, name_ar),
      visit_type:visit_types(id, name, name_ar, is_urgent, price)
    `)
    .eq('clinic_id', req.auth.clinicId)
    .order('date', { ascending: true })
    .order('time', { ascending: true });

  if (date)     query = query.eq('date', date as string);
  if (doctorId) query = query.eq('doctor_id', doctorId as string);
  if (status)   query = query.eq('status', status as string);
  if (req.auth.role === 'doctor') query = query.eq('doctor_id', req.auth.userId);

  const { data, error } = await query;
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

appointmentsRouter.post('/', ...guard, requireRole('admin', 'reception'), validate(AppointmentSchema), async (req, res) => {
  const { data, error } = await supabaseAdmin
    .from('appointments')
    .insert({
      clinic_id:     req.auth.clinicId,
      patient_id:    req.body.patientId,
      doctor_id:     req.body.doctorId,
      specialty_id:  req.body.specialtyId,
      visit_type_id: req.body.visitTypeId,
      date:          req.body.date,
      time:          req.body.time,
      is_urgent:     req.body.isUrgent,
      notes:         req.body.notes,
      status:        'scheduled',
      is_home_visit: req.body.isHomeVisit,
      home_address:  req.body.homeAddress,
      home_area:     req.body.homeArea,
      home_city:     req.body.homeCity,
    })
    .select()
    .single();

  if (error) return res.status(500).json({ error: error.message });
  res.status(201).json(data);
});

appointmentsRouter.patch('/:id/status', ...guard, requireRole('admin', 'reception'), async (req, res) => {
  const schema = z.object({ status: z.enum(['scheduled','confirmed','cancelled','no_show']) });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Invalid status' });

  const db = supabaseAs(req.auth.jwt);
  const { data, error } = await db
    .from('appointments')
    .update({ status: parsed.data.status })
    .eq('id', req.params.id)
    .eq('clinic_id', req.auth.clinicId)
    .select()
    .single();

  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

// ── GET /appointments/slots — available time slots ──────────
appointmentsRouter.get('/slots', ...guard, async (req, res) => {
  const { doctorId, date } = req.query;
  if (!doctorId || !date) return res.status(400).json({ error: 'doctorId and date required' });

  const dayOfWeek = new Date(date as string).getDay();

  // Get schedule
  const { data: schedule } = await supabaseAdmin
    .from('doctor_schedules')
    .select('start_time, end_time')
    .eq('doctor_id', doctorId)
    .eq('day_of_week', dayOfWeek)
    .eq('is_active', true)
    .single();

  if (!schedule) return res.json([]);

  // Check blocked dates
  const { data: blocked } = await supabaseAdmin
    .from('blocked_dates')
    .select('id')
    .eq('doctor_id', doctorId)
    .eq('date', date)
    .single();

  if (blocked) return res.json([]);

  // Generate 30-min slots
  const slots: string[] = [];
  const [sh, sm] = schedule.start_time.split(':').map(Number);
  const [eh, em] = schedule.end_time.split(':').map(Number);
  for (let m = sh * 60 + sm; m + 30 <= eh * 60 + em; m += 30) {
    slots.push(`${String(Math.floor(m/60)).padStart(2,'0')}:${String(m%60).padStart(2,'0')}`);
  }

  // Remove booked slots
  const { data: booked } = await supabaseAdmin
    .from('appointments')
    .select('time')
    .eq('doctor_id', doctorId)
    .eq('date', date)
    .not('status', 'in', '(cancelled,no_show)');

  const bookedSet = new Set((booked || []).map((a: any) => a.time.slice(0,5)));
  res.json(slots.filter(s => !bookedSet.has(s)));
});

// ═══════════════════════════════════════════════════════════
// REPORTS  (MVP: patients/day, revenue, completed visits)
// ═══════════════════════════════════════════════════════════

reportsRouter.get('/summary', ...guard, requireRole('admin'), async (req, res) => {
  const { from, to } = req.query;
  const clinicId = req.auth.clinicId!;

  if (!from || !to) return res.status(400).json({ error: 'from and to dates required' });

  // Completed visits count + revenue
  const { data: visitStats } = await supabaseAdmin
    .from('visits')
    .select('date, status')
    .eq('clinic_id', clinicId)
    .eq('status', 'completed')
    .gte('date', from)
    .lte('date', to);

  const { data: revenueStats } = await supabaseAdmin
    .from('invoices')
    .select('paid_at, total_amount, paid_amount')
    .eq('clinic_id', clinicId)
    .in('status', ['paid', 'partially_paid'])
    .gte('paid_at', `${from}T00:00:00Z`)
    .lte('paid_at', `${to}T23:59:59Z`);

  const totalRevenue       = (revenueStats || []).reduce((s, i) => s + Number(i.paid_amount), 0);
  const completedVisits    = (visitStats || []).length;

  // Patients per day
  const perDay: Record<string, number> = {};
  (visitStats || []).forEach((v: any) => {
    perDay[v.date] = (perDay[v.date] || 0) + 1;
  });

  res.json({
    period:          { from, to },
    completedVisits,
    totalRevenue:    +totalRevenue.toFixed(2),
    patientsPerDay:  Object.entries(perDay).map(([date, count]) => ({ date, count })),
  });
});
