import { Router } from 'express';
import { z }       from 'zod';
import { supabaseAdmin } from '../lib/supabase.js';
import { authenticate, requireRole } from '../middleware/auth.js';
import { validate } from '../middleware/validate.js';

const router = Router();

// ── POST /auth/login  ─────────────────────────────────────────
const LoginSchema = z.object({
  email:    z.string().email(),
  password: z.string().min(6),
});

router.post('/login', validate(LoginSchema), async (req, res) => {
  const { data, error } = await supabaseAdmin.auth.signInWithPassword({
    email:    req.body.email,
    password: req.body.password,
  });

  if (error) return res.status(401).json({ error: error.message });

  // Load user profile
  const { data: profile } = await supabaseAdmin
    .from('users')
    .select('id, name, name_ar, role, clinic_id, specialty_id, is_active')
    .eq('id', data.user!.id)
    .single();

  if (!profile?.is_active) {
    return res.status(403).json({ error: 'Account is deactivated' });
  }

  res.json({
    token:   data.session!.access_token,
    refresh: data.session!.refresh_token,
    user:    profile,
  });
});

// ── POST /auth/refresh  ───────────────────────────────────────
router.post('/refresh', async (req, res) => {
  const { refreshToken } = req.body;
  if (!refreshToken) return res.status(400).json({ error: 'refreshToken required' });

  const { data, error } = await supabaseAdmin.auth.refreshSession({ refresh_token: refreshToken });
  if (error) return res.status(401).json({ error: error.message });

  res.json({
    token:   data.session!.access_token,
    refresh: data.session!.refresh_token,
  });
});

// ── POST /auth/logout  ────────────────────────────────────────
router.post('/logout', authenticate, async (req, res) => {
  await supabaseAdmin.auth.admin.signOut(req.auth.userId);
  res.json({ message: 'Logged out' });
});

// ═══════════════════════════════════════════════════════════
// SUPER ADMIN: clinic management + user creation
// ═══════════════════════════════════════════════════════════

const ClinicSchema = z.object({
  name:             z.string().min(2),
  nameAr:           z.string().default(''),
  address:          z.string().default(''),
  phone:            z.string().default(''),
  city:             z.string().default(''),
  subscriptionPlan: z.enum(['basic', 'pro', 'ai']).default('basic'),
  maxDoctors:       z.number().int().positive().default(3),
  planExpiresAt:    z.string().datetime().optional(),
  aiEnabled:        z.boolean().default(false),
  advancedReports:  z.boolean().default(false),
});

// GET /auth/clinics  — list all clinics (super admin)
router.get('/clinics', authenticate, requireRole('super_admin'), async (_req, res) => {
  const { data, error } = await supabaseAdmin
    .from('clinics')
    .select('*, users(count)')
    .order('created_at', { ascending: false });
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

// POST /auth/clinics  — create clinic + admin user
router.post('/clinics', authenticate, requireRole('super_admin'), validate(ClinicSchema), async (req, res) => {
  const body = req.body;

  const { data: clinic, error: clinicErr } = await supabaseAdmin
    .from('clinics')
    .insert({
      name:              body.name,
      name_ar:           body.nameAr,
      address:           body.address,
      phone:             body.phone,
      city:              body.city,
      subscription_plan: body.subscriptionPlan,
      max_doctors:       body.maxDoctors,
      plan_expires_at:   body.planExpiresAt,
      ai_enabled:        body.aiEnabled,
      advanced_reports:  body.advancedReports,
    })
    .select()
    .single();

  if (clinicErr) return res.status(500).json({ error: clinicErr.message });
  res.status(201).json(clinic);
});

// PATCH /auth/clinics/:id/subscription  — extend/change plan
const SubSchema = z.object({
  plan:          z.enum(['basic', 'pro', 'ai']),
  expiresAt:     z.string().datetime(),
  aiEnabled:     z.boolean().optional(),
  advancedReports: z.boolean().optional(),
  maxDoctors:    z.number().int().positive().optional(),
});

router.patch('/clinics/:id/subscription', authenticate, requireRole('super_admin'), validate(SubSchema), async (req, res) => {
  const updates: Record<string, any> = {
    subscription_plan: req.body.plan,
    plan_expires_at:   req.body.expiresAt,
    is_active:         true,
  };
  if (req.body.aiEnabled        !== undefined) updates.ai_enabled = req.body.aiEnabled;
  if (req.body.advancedReports  !== undefined) updates.advanced_reports = req.body.advancedReports;
  if (req.body.maxDoctors       !== undefined) updates.max_doctors = req.body.maxDoctors;

  const { data, error } = await supabaseAdmin
    .from('clinics').update(updates).eq('id', req.params.id).select().single();
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

// POST /auth/users  — create a user in a clinic (admin or super_admin)
const CreateUserSchema = z.object({
  name:        z.string().min(2),
  nameAr:      z.string().default(''),
  email:       z.string().email(),
  password:    z.string().min(8),
  role:        z.enum(['admin', 'doctor', 'reception']),
  clinicId:    z.string().uuid(),
  specialtyId: z.string().uuid().optional(),
  homeVisitEnabled: z.boolean().default(false),
});

router.post('/users', authenticate, requireRole('super_admin', 'admin'), validate(CreateUserSchema), async (req, res) => {
  // Admin can only create users in their own clinic
  if (req.auth.role === 'admin' && req.body.clinicId !== req.auth.clinicId) {
    return res.status(403).json({ error: 'Cannot create users in another clinic' });
  }

  // Create auth user
  const { data: authUser, error: authErr } = await supabaseAdmin.auth.admin.createUser({
    email:             req.body.email,
    password:          req.body.password,
    email_confirm:     true,
  });
  if (authErr) return res.status(500).json({ error: authErr.message });

  // Create profile
  const { data: profile, error: profileErr } = await supabaseAdmin
    .from('users')
    .insert({
      id:           authUser.user!.id,
      name:         req.body.name,
      name_ar:      req.body.nameAr,
      email:        req.body.email,
      role:         req.body.role,
      clinic_id:    req.body.clinicId,
      specialty_id: req.body.specialtyId,
      home_visit_enabled: req.body.homeVisitEnabled,
    })
    .select()
    .single();

  if (profileErr) {
    await supabaseAdmin.auth.admin.deleteUser(authUser.user!.id);
    return res.status(500).json({ error: profileErr.message });
  }

  res.status(201).json(profile);
});

export default router;
