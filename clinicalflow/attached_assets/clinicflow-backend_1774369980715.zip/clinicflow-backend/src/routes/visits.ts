import { Router } from 'express';
import { z }       from 'zod';
import { supabaseAs, supabaseAdmin } from '../lib/supabase.js';
import { authenticate, requireActiveSubscription, requireRole } from '../middleware/auth.js';
import { validate } from '../middleware/validate.js';

const router = Router();
const guard  = [authenticate, requireActiveSubscription];

// ── POST /visits  ─────────────────────────────────────────────
// Creates a visit + invoice atomically.
// Patient enters queue ONLY after invoice is paid (see billing routes).
const CreateVisitSchema = z.object({
  patientId:       z.string().uuid(),
  doctorId:        z.string().uuid(),
  specialtyId:     z.string().uuid().optional(),
  visitTypeId:     z.string().uuid().optional(),
  appointmentId:   z.string().uuid().optional(),
  date:            z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  time:            z.string().regex(/^\d{2}:\d{2}$/),
  isUrgent:        z.boolean().default(false),
  notes:           z.string().optional(),
  isHomeVisit:     z.boolean().default(false),
  homeAddress:     z.string().optional(),
  homeArea:        z.string().optional(),
  homeCity:        z.string().optional(),
});

router.post(
  '/',
  ...guard,
  requireRole('admin', 'reception'),
  validate(CreateVisitSchema),
  async (req, res) => {
    const clinicId = req.auth.clinicId!;
    const body = req.body;

    // 1. Create the invoice first (status: pending)
    const { data: invoice, error: invErr } = await supabaseAdmin
      .from('invoices')
      .insert({
        clinic_id:  clinicId,
        patient_id: body.patientId,
        status:     'pending',
      })
      .select()
      .single();

    if (invErr) return res.status(500).json({ error: invErr.message });

    // 2. Create the visit (status: booked — not in queue yet)
    const { data: visit, error: visitErr } = await supabaseAdmin
      .from('visits')
      .insert({
        clinic_id:      clinicId,
        patient_id:     body.patientId,
        doctor_id:      body.doctorId,
        specialty_id:   body.specialtyId,
        visit_type_id:  body.visitTypeId,
        appointment_id: body.appointmentId,
        invoice_id:     invoice.id,
        date:           body.date,
        time:           body.time,
        is_urgent:      body.isUrgent,
        notes:          body.notes,
        status:         'booked',
        is_home_visit:  body.isHomeVisit,
        home_address:   body.homeAddress,
        home_area:      body.homeArea,
        home_city:      body.homeCity,
      })
      .select()
      .single();

    if (visitErr) return res.status(500).json({ error: visitErr.message });

    // 3. Link invoice ↔ visit
    await supabaseAdmin
      .from('invoices')
      .update({ visit_id: visit.id })
      .eq('id', invoice.id);

    // 4. If appointment exists, mark it as converted
    if (body.appointmentId) {
      await supabaseAdmin
        .from('appointments')
        .update({ status: 'converted' })
        .eq('id', body.appointmentId);
    }

    res.status(201).json({ visit, invoice });
  }
);

// ── GET /visits  ──────────────────────────────────────────────
router.get('/', ...guard, async (req, res) => {
  const db = supabaseAs(req.auth.jwt);
  const { date, patientId, doctorId, status } = req.query;

  let query = db
    .from('visits')
    .select(`
      *,
      patient:patients(id, name, name_ar, phone),
      doctor:users!visits_doctor_id_fkey(id, name, name_ar),
      visit_type:visit_types(id, name, name_ar, is_urgent),
      invoice:invoices(id, status, total_amount, paid_amount)
    `)
    .eq('clinic_id', req.auth.clinicId)
    .order('created_at', { ascending: false });

  if (date)      query = query.eq('date', date as string);
  if (patientId) query = query.eq('patient_id', patientId as string);
  if (doctorId)  query = query.eq('doctor_id', doctorId as string);
  if (status)    query = query.eq('status', status as string);

  // Doctors only see their own visits
  if (req.auth.role === 'doctor') {
    query = query.eq('doctor_id', req.auth.userId);
  }

  const { data, error } = await query;
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

// ── GET /visits/:id  ─────────────────────────────────────────
router.get('/:id', ...guard, async (req, res) => {
  const db = supabaseAs(req.auth.jwt);

  const { data, error } = await db
    .from('visits')
    .select(`
      *,
      patient:patients(*),
      doctor:users!visits_doctor_id_fkey(id, name, name_ar, specialty_id),
      visit_type:visit_types(*),
      invoice:invoices(*, invoice_items(*, service:services(*)), payments(*)),
      specialty_records(*),
      vital_signs(*),
      medical_notes(*),
      prescriptions(*),
      orders(*)
    `)
    .eq('id', req.params.id)
    .eq('clinic_id', req.auth.clinicId)
    .single();

  if (error) return res.status(404).json({ error: 'Visit not found' });

  // Doctors: strip uploader identity from lab/radiology documents (privacy rule)
  if (req.auth.role === 'doctor' && data.orders) {
    data.orders = data.orders.map((o: any) => ({
      ...o,
      requested_by: undefined,  // hide who requested (cross-doctor privacy)
    }));
  }

  res.json(data);
});

export default router;
