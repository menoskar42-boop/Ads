import { Router } from 'express';
import { z }       from 'zod';
import { supabaseAs, supabaseAdmin } from '../lib/supabase.js';
import { authenticate, requireActiveSubscription, requireRole } from '../middleware/auth.js';
import { validate } from '../middleware/validate.js';

const router = Router();
const guard  = [authenticate, requireActiveSubscription];

// ── GET /billing/invoices  ────────────────────────────────────
router.get('/invoices', ...guard, requireRole('admin', 'reception'), async (req, res) => {
  const db = supabaseAs(req.auth.jwt);
  const { status, patientId, date } = req.query;

  let query = db
    .from('invoices')
    .select(`
      *,
      patient:patients(id, name, name_ar, phone),
      visit:visits(id, status, doctor_id, date),
      invoice_items(*, service:services(id, name, name_ar, doctor_percentage)),
      payments(*)
    `)
    .eq('clinic_id', req.auth.clinicId)
    .order('created_at', { ascending: false });

  if (status)    query = query.eq('status', status as string);
  if (patientId) query = query.eq('patient_id', patientId as string);
  if (date)      query = query.eq('visit.date', date as string);

  const { data, error } = await query;
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

// ── POST /billing/invoices/:id/items  ─────────────────────────
const AddItemSchema = z.object({
  serviceId: z.string().uuid(),
  quantity:  z.number().int().positive().default(1),
  unitPrice: z.number().positive().optional(), // override service price
});

router.post(
  '/invoices/:id/items',
  ...guard,
  requireRole('admin', 'reception'),
  validate(AddItemSchema),
  async (req, res) => {
    const { id: invoiceId } = req.params;

    // Fetch service for price + doctor %
    const { data: svc } = await supabaseAdmin
      .from('services')
      .select('price, doctor_percentage')
      .eq('id', req.body.serviceId)
      .single();
    if (!svc) return res.status(404).json({ error: 'Service not found' });

    const unitPrice  = req.body.unitPrice ?? svc.price;
    const totalPrice = unitPrice * req.body.quantity;
    const doctorShare = +(totalPrice * (svc.doctor_percentage / 100)).toFixed(2);

    const { data, error } = await supabaseAdmin
      .from('invoice_items')
      .insert({
        invoice_id:   invoiceId,
        service_id:   req.body.serviceId,
        quantity:     req.body.quantity,
        unit_price:   unitPrice,
        total_price:  totalPrice,
        doctor_share: doctorShare,
      })
      .select()
      .single();

    if (error) return res.status(500).json({ error: error.message });
    // Trigger recalculation fires automatically via DB trigger
    res.status(201).json(data);
  }
);

// ── PATCH /billing/invoices/:id/discount  ─────────────────────
const DiscountSchema = z.object({
  discountType:  z.enum(['none', 'percentage', 'fixed']),
  discountValue: z.number().min(0),
});

router.patch(
  '/invoices/:id/discount',
  ...guard,
  requireRole('admin', 'reception'),
  validate(DiscountSchema),
  async (req, res) => {
    const db = supabaseAs(req.auth.jwt);

    const { data, error } = await db
      .from('invoices')
      .update({
        discount_type:  req.body.discountType,
        discount_value: req.body.discountValue,
      })
      .eq('id', req.params.id)
      .eq('clinic_id', req.auth.clinicId)
      .select()
      .single();

    if (error) return res.status(500).json({ error: error.message });
    res.json(data);
  }
);

// ── POST /billing/invoices/:id/pay  ──────────────────────────
// THE CRITICAL ACTION: recording payment sets arrival_time on the visit,
// which places the patient in the queue (DB trigger handles this).
const PaySchema = z.object({
  amount: z.number().positive(),
  method: z.enum(['cash', 'card', 'insurance', 'bank_transfer']),
});

router.post(
  '/invoices/:id/pay',
  ...guard,
  requireRole('admin', 'reception'),
  validate(PaySchema),
  async (req, res) => {
    const { id: invoiceId } = req.params;
    const clinicId = req.auth.clinicId!;

    // Verify invoice belongs to this clinic
    const { data: inv } = await supabaseAdmin
      .from('invoices')
      .select('id, status, visit_id, total_amount, paid_amount')
      .eq('id', invoiceId)
      .eq('clinic_id', clinicId)
      .single();

    if (!inv)             return res.status(404).json({ error: 'Invoice not found' });
    if (inv.status === 'refunded') return res.status(400).json({ error: 'Invoice already refunded' });

    // Insert payment — DB trigger recalcs totals + sets paid_at if fully paid
    const { data: payment, error: payErr } = await supabaseAdmin
      .from('payments')
      .insert({
        invoice_id:  invoiceId,
        clinic_id:   clinicId,
        amount:      req.body.amount,
        method:      req.body.method,
        date:        new Date().toISOString().split('T')[0],
        received_by: req.auth.userId,
      })
      .select()
      .single();

    if (payErr) return res.status(500).json({ error: payErr.message });

    // Fetch updated invoice (trigger has recalculated)
    const { data: updated } = await supabaseAdmin
      .from('invoices')
      .select('*, payments(*)')
      .eq('id', invoiceId)
      .single();

    res.status(201).json({
      payment,
      invoice:     updated,
      queueNote:   updated?.paid_at
        ? 'Patient has been added to the queue (arrival time set to payment time).'
        : 'Partial payment recorded. Patient will join queue when fully paid.',
    });
  }
);

// ── POST /billing/invoices/:id/refund  ───────────────────────
router.post(
  '/invoices/:id/refund',
  ...guard,
  requireRole('admin'),
  async (req, res) => {
    const db = supabaseAs(req.auth.jwt);

    // Deactivate all payments
    await supabaseAdmin
      .from('payments')
      .update({ is_active: false })
      .eq('invoice_id', req.params.id);

    const { data, error } = await db
      .from('invoices')
      .update({ status: 'refunded', paid_amount: 0 })
      .eq('id', req.params.id)
      .eq('clinic_id', req.auth.clinicId)
      .select()
      .single();

    if (error) return res.status(500).json({ error: error.message });
    res.json(data);
  }
);

export default router;
