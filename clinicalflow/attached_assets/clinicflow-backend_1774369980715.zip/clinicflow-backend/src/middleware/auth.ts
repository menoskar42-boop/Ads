import { Request, Response, NextFunction } from 'express';
import { supabaseAdmin, supabaseAs } from '../lib/supabase.js';

// Extend Express request with our auth context
declare global {
  namespace Express {
    interface Request {
      auth: {
        userId:   string;
        clinicId: string | null;
        role:     string;
        jwt:      string;
      };
    }
  }
}

/** Validates Bearer JWT, loads user row, attaches to req.auth */
export async function authenticate(req: Request, res: Response, next: NextFunction) {
  const header = req.headers.authorization;
  if (!header?.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Missing Authorization header' });
  }

  const jwt = header.slice(7);

  // Verify token with Supabase
  const { data: { user }, error } = await supabaseAdmin.auth.getUser(jwt);
  if (error || !user) {
    return res.status(401).json({ error: 'Invalid or expired token' });
  }

  // Load our users row for role + clinic
  const { data: profile, error: profileErr } = await supabaseAdmin
    .from('users')
    .select('role, clinic_id, is_active')
    .eq('id', user.id)
    .single();

  if (profileErr || !profile) {
    return res.status(401).json({ error: 'User profile not found' });
  }

  if (!profile.is_active) {
    return res.status(403).json({ error: 'Account is deactivated' });
  }

  req.auth = {
    userId:   user.id,
    clinicId: profile.clinic_id,
    role:     profile.role,
    jwt,
  };

  next();
}

/** Checks that the clinic's subscription is active */
export async function requireActiveSubscription(req: Request, res: Response, next: NextFunction) {
  const { clinicId, role } = req.auth;

  // Super admin is never blocked
  if (role === 'super_admin') return next();
  if (!clinicId)              return next(); // standalone doctor (home visits)

  const { data, error } = await supabaseAdmin
    .rpc('clinic_subscription_active', { p_clinic_id: clinicId });

  if (error || !data) {
    return res.status(403).json({
      error: 'Clinic subscription has expired. Please contact your administrator.',
    });
  }

  next();
}

/** Role guard factory — usage: requireRole('admin', 'reception') */
export function requireRole(...roles: string[]) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (req.auth?.role === 'super_admin') return next();
    if (!roles.includes(req.auth?.role)) {
      return res.status(403).json({ error: `Requires role: ${roles.join(' or ')}` });
    }
    next();
  };
}
