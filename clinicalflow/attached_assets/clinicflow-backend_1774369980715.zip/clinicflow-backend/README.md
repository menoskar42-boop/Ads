# ClinicFlow — Production Backend

Express + Supabase backend implementing the full ClinicFlow spec.

## File Structure

```
clinicflow-backend/
├── supabase/
│   └── migrations/
│       ├── 001_schema.sql      ← All tables, views, triggers, indexes
│       └── 002_rls.sql         ← Row Level Security + helper functions
├── src/
│   ├── index.ts                ← Express app + route registration
│   ├── lib/
│   │   └── supabase.ts         ← Supabase client (admin + user-context)
│   ├── middleware/
│   │   ├── auth.ts             ← JWT auth + subscription guard + role guard
│   │   └── validate.ts         ← Zod body validation
│   └── routes/
│       ├── auth.ts             ← Login, refresh, super-admin clinic/user mgmt
│       ├── queue.ts            ← Queue view + status updates + urgent override
│       ├── visits.ts           ← Visit creation + detail fetch
│       ├── billing.ts          ← Invoices, items, payments, refunds
│       └── patients-appointments-reports.ts
├── .env.example
├── package.json
└── tsconfig.json
```

## Setup (5 steps)

### 1. Create Supabase project
Go to https://supabase.com → New project → note your URL + keys.

### 2. Run migrations
In Supabase Dashboard → SQL Editor, run in order:
```sql
-- paste content of: supabase/migrations/001_schema.sql
-- paste content of: supabase/migrations/002_rls.sql
```

### 3. Install & configure
```bash
cd clinicflow-backend
npm install
cp .env.example .env
# Fill in SUPABASE_URL, SUPABASE_ANON_KEY, SUPABASE_SERVICE_ROLE_KEY
```

### 4. Create the first super admin
In Supabase Dashboard → Authentication → Users → Add user, then in SQL Editor:
```sql
insert into users (id, name, name_ar, email, role, is_active)
values (
  '<paste auth user id here>',
  'Super Admin', 'سوبر أدمن',
  'superadmin@yourapp.com',
  'super_admin',
  true
);
```

### 5. Run
```bash
npm run dev      # development (hot reload)
npm run build && npm start   # production
```

---

## API Reference

### Auth
| Method | Path | Role | Description |
|--------|------|------|-------------|
| POST | `/api/auth/login` | public | Returns JWT token |
| POST | `/api/auth/refresh` | public | Refresh token |
| POST | `/api/auth/logout` | any | Invalidate session |
| GET  | `/api/auth/clinics` | super_admin | List all clinics |
| POST | `/api/auth/clinics` | super_admin | Create clinic |
| PATCH | `/api/auth/clinics/:id/subscription` | super_admin | Update plan |
| POST | `/api/auth/users` | admin, super_admin | Create user |

### Queue  *(core feature)*
| Method | Path | Role | Description |
|--------|------|------|-------------|
| GET  | `/api/queue/today` | all | Today's queue sorted by payment time |
| PATCH | `/api/queue/:visitId/status` | admin, reception, doctor | Advance status |
| PATCH | `/api/queue/:visitId/urgent` | admin, reception | Move to front |

### Visits
| Method | Path | Role | Description |
|--------|------|------|-------------|
| POST | `/api/visits` | admin, reception | Create visit + invoice |
| GET  | `/api/visits` | all | List visits (doctors see own) |
| GET  | `/api/visits/:id` | all | Full visit detail |

### Billing
| Method | Path | Role | Description |
|--------|------|------|-------------|
| GET  | `/api/billing/invoices` | admin, reception | List invoices |
| POST | `/api/billing/invoices/:id/items` | admin, reception | Add service item |
| PATCH | `/api/billing/invoices/:id/discount` | admin, reception | Apply discount |
| POST | `/api/billing/invoices/:id/pay` | admin, reception | **Record payment → triggers queue** |
| POST | `/api/billing/invoices/:id/refund` | admin | Full refund |

### Patients
| Method | Path | Role | Description |
|--------|------|------|-------------|
| GET  | `/api/patients` | all | Search/list patients |
| GET  | `/api/patients/:id` | all | Patient + history |
| POST | `/api/patients` | admin, reception | Create patient |
| PATCH | `/api/patients/:id` | admin, reception | Update patient |

### Appointments
| Method | Path | Role | Description |
|--------|------|------|-------------|
| GET  | `/api/appointments` | all | List appointments |
| GET  | `/api/appointments/slots` | all | Available time slots |
| POST | `/api/appointments` | admin, reception | Book appointment |
| PATCH | `/api/appointments/:id/status` | admin, reception | Update status |

### Reports
| Method | Path | Role | Description |
|--------|------|------|-------------|
| GET  | `/api/reports/summary?from=&to=` | admin | Patients/day, revenue, completed |

---

## Key Architecture Decisions

### Queue = Payment Time (spec rule enforced at DB level)
The `queue_today` view sorts by `arrival_time` (set when invoice is fully paid).
The DB trigger `trg_set_arrival_on_payment` sets `visits.arrival_time = invoices.paid_at`
automatically — no application code can bypass this.

### Multi-tenant Isolation
Every table has `clinic_id`. RLS policies use `auth_clinic_id()` to filter.
A user from clinic A **cannot** see clinic B's data even if they guess the ID.

### Doctor Privacy Rule (spec §5)
- RLS on `medical_documents`: doctors only see documents where `specialty_id = auth_specialty_id()`
- In `GET /visits/:id`: `requested_by` is stripped from orders returned to doctors

### Subscription Guard
`requireActiveSubscription` middleware calls `clinic_subscription_active()` DB function.
Expired clinics get 403 on every protected route.

### Invoice Totals
Calculated by DB triggers on `invoice_items` and `payments` — always consistent,
never depends on client-side math.

---

## Connecting the Frontend

Replace Zustand store calls with API calls:

```typescript
// Before (demo):
const visits = visitStore.filter(v => v.clinicId === clinicId);

// After (production):
const { data } = await fetch('/api/visits?date=2025-01-15', {
  headers: { Authorization: `Bearer ${token}` }
}).then(r => r.json());
```

Use the existing `src/contexts/AuthContext.tsx` to store the JWT,
then pass it in every request header.
