import express from 'express';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import { readFileSync } from 'fs';
import OpenAI from 'openai';
import { createClient } from '@supabase/supabase-js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(cors());
app.use(express.json({ limit: '2mb' }));

// ── Supabase clients ─────────────────────────────────────────
const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;
const SUPABASE_ANON_KEY = process.env.SUPABASE_ANON_KEY;

let supabaseAdmin = null;
let supabaseReady = false;

if (SUPABASE_URL && SUPABASE_SERVICE_ROLE_KEY && SUPABASE_ANON_KEY) {
  supabaseAdmin = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, {
    auth: { autoRefreshToken: false, persistSession: false },
  });
  supabaseReady = true;
  console.log('Supabase connected:', SUPABASE_URL);
} else {
  console.warn('Supabase env vars missing — DB routes will return 503');
}

function supabaseAs(jwt) {
  return createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
    global: { headers: { Authorization: `Bearer ${jwt}` } },
    auth: { autoRefreshToken: false, persistSession: false },
  });
}

function requireSupabase(req, res, next) {
  if (!supabaseReady) {
    return res.status(503).json({ error: 'Database not configured' });
  }
  next();
}

// ── Auth middleware ───────────────────────────────────────────
async function authenticate(req, res, next) {
  const header = req.headers.authorization;
  if (!header?.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Missing Authorization header' });
  }
  const jwt = header.slice(7);
  const { data: { user }, error } = await supabaseAdmin.auth.getUser(jwt);
  if (error || !user) {
    return res.status(401).json({ error: 'Invalid or expired token' });
  }
  const { data: profile, error: profileErr } = await supabaseAdmin
    .from('users')
    .select('role, clinic_id, is_active')
    .eq('id', user.id)
    .single();
  if (profileErr || !profile) {
    return res.status(401).json({ error: 'User profile not found' });
  }
  if (!profile.is_active) {
    return res.status(403).json({ error: 'Account is deactivated' });
  }
  req.auth = { userId: user.id, clinicId: profile.clinic_id, role: profile.role, jwt };
  next();
}

function requireRole(...roles) {
  return (req, res, next) => {
    if (req.auth?.role === 'super_admin') return next();
    if (!roles.includes(req.auth?.role)) {
      return res.status(403).json({ error: `Requires role: ${roles.join(' or ')}` });
    }
    next();
  };
}

async function requireActiveSubscription(req, res, next) {
  const { clinicId, role } = req.auth;
  if (role === 'super_admin') return next();
  if (!clinicId) return next();
  const { data, error } = await supabaseAdmin
    .rpc('clinic_subscription_active', { p_clinic_id: clinicId });
  if (error || !data) {
    return res.status(403).json({ error: 'Clinic subscription has expired.' });
  }
  next();
}

const guard = [requireSupabase, authenticate, requireActiveSubscription];


// ═══════════════════════════════════════════════════════════
// OpenAI routes
// ═══════════════════════════════════════════════════════════
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const TRIAGE_PROMPT = `You are a medical triage assistant.
Given a patient complaint, return ONLY the most relevant medical specialty name in English.
Do not explain. Do not add any other text.
If multiple specialties could match, return the most likely one.
Valid specialties: General Medicine, Dentistry, Dermatology, Cardiology, Orthopedics, Ophthalmology, ENT, Neurology, Gastroenterology, Pediatrics, Urology, Gynecology, Psychiatry, Pulmonology, Endocrinology, Nephrology, Rheumatology, Oncology, Hematology, Allergy`;

app.post('/api/detect-specialty', async (req, res) => {
  try {
    const { complaint } = req.body;
    if (!complaint || typeof complaint !== 'string') {
      return res.status(400).json({ error: 'complaint is required' });
    }
    if (!process.env.OPENAI_API_KEY) {
      return res.status(500).json({ error: 'OpenAI API key not configured' });
    }
    const response = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [
        { role: 'system', content: TRIAGE_PROMPT },
        { role: 'user', content: complaint }
      ],
      max_tokens: 20,
      temperature: 0,
    });
    const specialty = response.choices[0]?.message?.content?.trim() || '';
    const usage = response.usage;
    res.json({
      specialty,
      tokens: {
        prompt: usage?.prompt_tokens || 0,
        completion: usage?.completion_tokens || 0,
        total: usage?.total_tokens || 0,
      }
    });
  } catch (error) {
    console.error('OpenAI API error:', error.message);
    res.status(500).json({ error: 'Failed to detect specialty' });
  }
});

app.post('/api/doctor-suitability', async (req, res) => {
  try {
    const { symptoms, doctorName, doctorSpecialty } = req.body;
    if (!symptoms || !doctorSpecialty) {
      return res.status(400).json({ error: 'symptoms and doctorSpecialty are required' });
    }
    if (!process.env.OPENAI_API_KEY) {
      return res.status(500).json({ error: 'OpenAI API key not configured' });
    }
    const systemPrompt = `You are a helpful medical guidance assistant on a clinic platform.
A patient is asking whether Dr. ${doctorName} (${doctorSpecialty} specialist) is suitable for their condition.
Your job:
- Analyze the symptoms against the doctor's specialty.
- If they match: confirm the doctor can help, be encouraging.
- If they do NOT match: gently suggest a more appropriate specialty.
- NEVER diagnose or prescribe. Only guide.
- Keep your response to 2-3 short sentences.
- End with either "suitability: match" or "suitability: mismatch" on the last line.`;
    const response = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: `My symptoms: ${symptoms}` }
      ],
      max_tokens: 120,
      temperature: 0.3,
    });
    const raw = response.choices[0]?.message?.content?.trim() || '';
    const lines = raw.split('\n');
    const suitabilityLine = lines.find(l => l.toLowerCase().includes('suitability:')) || '';
    const isMatch = suitabilityLine.toLowerCase().includes('match') && !suitabilityLine.toLowerCase().includes('mismatch');
    const message = lines.filter(l => !l.toLowerCase().startsWith('suitability:')).join(' ').trim();
    res.json({ message, isMatch });
  } catch (error) {
    console.error('OpenAI API error:', error.message);
    res.status(500).json({ error: 'Failed to evaluate suitability' });
  }
});

// ═══════════════════════════════════════════════════════════
// AUTH routes
// ═══════════════════════════════════════════════════════════

// POST /api/auth/login
app.post('/api/auth/login', requireSupabase, async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: 'email and password are required' });
  }
  const { data, error } = await supabaseAdmin.auth.signInWithPassword({ email, password });
  if (error) return res.status(401).json({ error: error.message });

  const { data: profile } = await supabaseAdmin
    .from('users')
    .select('id, name, name_ar, role, clinic_id, specialty_id, is_active')
    .eq('id', data.user.id)
    .single();

  if (!profile?.is_active) {
    return res.status(403).json({ error: 'Account is deactivated' });
  }

  res.json({
    token: data.session.access_token,
    refresh: data.session.refresh_token,
    user: profile,
  });
});

// POST /api/auth/refresh
app.post('/api/auth/refresh', requireSupabase, async (req, res) => {
  const { refreshToken } = req.body;
  if (!refreshToken) return res.status(400).json({ error: 'refreshToken required' });
  const { data, error } = await supabaseAdmin.auth.refreshSession({ refresh_token: refreshToken });
  if (error) return res.status(401).json({ error: error.message });
  res.json({
    token: data.session.access_token,
    refresh: data.session.refresh_token,
  });
});

// POST /api/auth/logout
app.post('/api/auth/logout', requireSupabase, authenticate, async (req, res) => {
  await supabaseAdmin.auth.admin.signOut(req.auth.userId);
  res.json({ message: 'Logged out' });
});

// GET /api/auth/clinics — super admin
app.get('/api/auth/clinics', requireSupabase, authenticate, requireRole('super_admin'), async (_req, res) => {
  const { data, error } = await supabaseAdmin
    .from('clinics')
    .select('*')
    .order('created_at', { ascending: false });
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

// POST /api/auth/clinics — super admin
app.post('/api/auth/clinics', requireSupabase, authenticate, requireRole('super_admin'), async (req, res) => {
  const { name, nameAr, address, phone, city, subscriptionPlan, maxDoctors, planExpiresAt, aiEnabled, advancedReports } = req.body;
  if (!name) return res.status(400).json({ error: 'name is required' });

  const { data, error } = await supabaseAdmin
    .from('clinics')
    .insert({
      name,
      name_ar: nameAr || '',
      address: address || '',
      phone: phone || '',
      city: city || '',
      subscription_plan: subscriptionPlan || 'basic',
      max_doctors: maxDoctors || 3,
      plan_expires_at: planExpiresAt || null,
      ai_enabled: aiEnabled || false,
      advanced_reports: advancedReports || false,
    })
    .select()
    .single();

  if (error) return res.status(500).json({ error: error.message });
  res.status(201).json(data);
});

// GET /api/auth/clinics/:id — get clinic info (any authenticated staff)
app.get('/api/auth/clinics/:id', requireSupabase, authenticate, async (req, res) => {
  const { data, error } = await supabaseAdmin
    .from('clinics')
    .select('id, name, name_ar, subscription_plan, is_active, city, city_ar')
    .eq('id', req.params.id)
    .single();
  if (error) return res.status(404).json({ error: 'Clinic not found' });
  res.json(data);
});

// PATCH /api/auth/clinics/:id/subscription
app.patch('/api/auth/clinics/:id/subscription', requireSupabase, authenticate, requireRole('super_admin'), async (req, res) => {
  const { id } = req.params;
  const { subscriptionPlan, planExpiresAt, maxDoctors, aiEnabled, advancedReports, isActive } = req.body;

  const updates = {};
  if (subscriptionPlan !== undefined) updates.subscription_plan = subscriptionPlan;
  if (planExpiresAt !== undefined) updates.plan_expires_at = planExpiresAt;
  if (maxDoctors !== undefined) updates.max_doctors = maxDoctors;
  if (aiEnabled !== undefined) updates.ai_enabled = aiEnabled;
  if (advancedReports !== undefined) updates.advanced_reports = advancedReports;
  if (isActive !== undefined) updates.is_active = isActive;
  updates.updated_at = new Date().toISOString();

  const { data, error } = await supabaseAdmin
    .from('clinics')
    .update(updates)
    .eq('id', id)
    .select()
    .single();

  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

// POST /api/auth/users — create user (admin or super_admin)
app.post('/api/auth/users', requireSupabase, authenticate, requireRole('admin', 'super_admin'), async (req, res) => {
  const { email, password, name, nameAr, role, clinicId, specialtyId } = req.body;
  if (!email || !password || !name || !role) {
    return res.status(400).json({ error: 'email, password, name, role required' });
  }

  const targetClinicId = clinicId || req.auth.clinicId;

  const { data: authData, error: authErr } = await supabaseAdmin.auth.admin.createUser({
    email,
    password,
    email_confirm: true,
  });
  if (authErr) return res.status(400).json({ error: authErr.message });

  const { data: profile, error: profileErr } = await supabaseAdmin
    .from('users')
    .insert({
      id: authData.user.id,
      name,
      name_ar: nameAr || '',
      email,
      role,
      clinic_id: targetClinicId || null,
      specialty_id: specialtyId || null,
      is_active: true,
    })
    .select()
    .single();

  if (profileErr) {
    await supabaseAdmin.auth.admin.deleteUser(authData.user.id);
    return res.status(500).json({ error: profileErr.message });
  }

  res.status(201).json(profile);
});

// GET /api/auth/me
app.get('/api/auth/me', requireSupabase, authenticate, async (req, res) => {
  const { data, error } = await supabaseAdmin
    .from('users')
    .select('*, clinic:clinics(*)')
    .eq('id', req.auth.userId)
    .single();
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

// ═══════════════════════════════════════════════════════════
// PATIENTS routes
// ═══════════════════════════════════════════════════════════

// GET /api/patients
app.get('/api/patients', ...guard, async (req, res) => {
  const db = supabaseAs(req.auth.jwt);
  const { search, page = 1, limit = 50 } = req.query;
  const offset = (Number(page) - 1) * Number(limit);

  let query = db
    .from('patients')
    .select('*', { count: 'exact' })
    .eq('clinic_id', req.auth.clinicId)
    .order('created_at', { ascending: false })
    .range(offset, offset + Number(limit) - 1);

  if (search) {
    query = query.or(`name.ilike.%${search}%,phone.ilike.%${search}%,national_id.ilike.%${search}%`);
  }

  const { data, error, count } = await query;
  if (error) return res.status(500).json({ error: error.message });
  res.json({ data, total: count, page: Number(page), limit: Number(limit) });
});

// GET /api/patients/:id
app.get('/api/patients/:id', ...guard, async (req, res) => {
  const db = supabaseAs(req.auth.jwt);
  const { data, error } = await db
    .from('patients')
    .select(`
      *,
      visits(id, status, date, doctor:users(name, name_ar), visit_type:visit_types(name, name_ar)),
      appointments(id, status, date, time, doctor:users(name, name_ar))
    `)
    .eq('id', req.params.id)
    .eq('clinic_id', req.auth.clinicId)
    .single();
  if (error) return res.status(404).json({ error: 'Patient not found' });
  res.json(data);
});

// POST /api/patients
app.post('/api/patients', ...guard, requireRole('admin', 'reception'), async (req, res) => {
  const { name, nameAr, phone, email, dateOfBirth, gender, nationalId } = req.body;
  if (!name || !phone) return res.status(400).json({ error: 'name and phone required' });

  const { data, error } = await supabaseAdmin
    .from('patients')
    .insert({
      clinic_id: req.auth.clinicId,
      name,
      name_ar: nameAr || '',
      phone,
      email: email || null,
      date_of_birth: dateOfBirth || null,
      gender: gender || null,
      national_id: nationalId || null,
    })
    .select()
    .single();

  if (error) return res.status(500).json({ error: error.message });
  res.status(201).json(data);
});

// PATCH /api/patients/:id
app.patch('/api/patients/:id', ...guard, requireRole('admin', 'reception'), async (req, res) => {
  const { name, nameAr, phone, email, dateOfBirth, gender, nationalId } = req.body;
  const updates = { updated_at: new Date().toISOString() };
  if (name !== undefined) updates.name = name;
  if (nameAr !== undefined) updates.name_ar = nameAr;
  if (phone !== undefined) updates.phone = phone;
  if (email !== undefined) updates.email = email;
  if (dateOfBirth !== undefined) updates.date_of_birth = dateOfBirth;
  if (gender !== undefined) updates.gender = gender;
  if (nationalId !== undefined) updates.national_id = nationalId;

  const { data, error } = await supabaseAdmin
    .from('patients')
    .update(updates)
    .eq('id', req.params.id)
    .eq('clinic_id', req.auth.clinicId)
    .select()
    .single();

  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

// ═══════════════════════════════════════════════════════════
// APPOINTMENTS routes
// ═══════════════════════════════════════════════════════════

// GET /api/appointments
app.get('/api/appointments', ...guard, async (req, res) => {
  const db = supabaseAs(req.auth.jwt);
  const { date, doctorId, status, patientId } = req.query;

  let query = db
    .from('appointments')
    .select(`
      *,
      patient:patients(id, name, name_ar, phone),
      doctor:users(id, name, name_ar),
      visit_type:visit_types(id, name, name_ar, price)
    `)
    .eq('clinic_id', req.auth.clinicId)
    .order('date', { ascending: true })
    .order('time', { ascending: true });

  if (date) query = query.eq('date', date);
  if (doctorId) query = query.eq('doctor_id', doctorId);
  if (status) query = query.eq('status', status);
  if (patientId) query = query.eq('patient_id', patientId);

  if (req.auth.role === 'doctor') {
    query = query.eq('doctor_id', req.auth.userId);
  }

  const { data, error } = await query;
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

// GET /api/appointments/slots
app.get('/api/appointments/slots', requireSupabase, async (req, res) => {
  const { doctorId, date } = req.query;
  if (!doctorId || !date) {
    return res.status(400).json({ error: 'doctorId and date required' });
  }

  const dayOfWeek = new Date(date).getDay();

  const [scheduleResult, blockedResult, appointmentsResult] = await Promise.all([
    supabaseAdmin
      .from('doctor_schedules')
      .select('start_time, end_time')
      .eq('doctor_id', doctorId)
      .eq('day_of_week', dayOfWeek)
      .eq('is_active', true)
      .single(),
    supabaseAdmin
      .from('blocked_dates')
      .select('id')
      .eq('doctor_id', doctorId)
      .eq('date', date)
      .single(),
    supabaseAdmin
      .from('appointments')
      .select('time')
      .eq('doctor_id', doctorId)
      .eq('date', date)
      .in('status', ['scheduled', 'confirmed']),
  ]);

  if (blockedResult.data) {
    return res.json({ slots: [], blocked: true });
  }

  if (!scheduleResult.data) {
    return res.json({ slots: [], blocked: false, noSchedule: true });
  }

  const { start_time, end_time } = scheduleResult.data;
  const bookedTimes = new Set((appointmentsResult.data || []).map(a => a.time));

  const slots = [];
  const [startH, startM] = start_time.split(':').map(Number);
  const [endH, endM] = end_time.split(':').map(Number);
  let current = startH * 60 + startM;
  const endMinutes = endH * 60 + endM;

  while (current < endMinutes) {
    const h = String(Math.floor(current / 60)).padStart(2, '0');
    const m = String(current % 60).padStart(2, '0');
    const time = `${h}:${m}`;
    slots.push({ time, available: !bookedTimes.has(time) });
    current += 20;
  }

  res.json({ slots, blocked: false });
});

// POST /api/appointments
app.post('/api/appointments', ...guard, requireRole('admin', 'reception', 'patient'), async (req, res) => {
  const { patientId, doctorId, visitTypeId, date, time, notes } = req.body;
  if (!patientId || !doctorId || !date || !time) {
    return res.status(400).json({ error: 'patientId, doctorId, date, time required' });
  }

  const { data, error } = await supabaseAdmin
    .from('appointments')
    .insert({
      clinic_id: req.auth.clinicId,
      patient_id: patientId,
      doctor_id: doctorId,
      visit_type_id: visitTypeId || null,
      date,
      time,
      notes: notes || null,
      status: 'scheduled',
    })
    .select(`
      *,
      patient:patients(id, name, name_ar, phone),
      doctor:users(id, name, name_ar),
      visit_type:visit_types(id, name, name_ar, price)
    `)
    .single();

  if (error) return res.status(500).json({ error: error.message });
  res.status(201).json(data);
});

// PATCH /api/appointments/:id/status
app.patch('/api/appointments/:id/status', ...guard, requireRole('admin', 'reception'), async (req, res) => {
  const { status } = req.body;
  if (!status) return res.status(400).json({ error: 'status required' });

  const { data, error } = await supabaseAdmin
    .from('appointments')
    .update({ status, updated_at: new Date().toISOString() })
    .eq('id', req.params.id)
    .eq('clinic_id', req.auth.clinicId)
    .select()
    .single();

  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

// ═══════════════════════════════════════════════════════════
// VISITS routes
// ═══════════════════════════════════════════════════════════

// GET /api/visits
app.get('/api/visits', ...guard, async (req, res) => {
  const db = supabaseAs(req.auth.jwt);
  const { date, doctorId, status, patientId } = req.query;

  let query = db
    .from('visits')
    .select(`
      *,
      patient:patients(id, name, name_ar, phone),
      doctor:users(id, name, name_ar),
      visit_type:visit_types(id, name, name_ar),
      invoices(id, status, total_amount, paid_amount)
    `)
    .eq('clinic_id', req.auth.clinicId)
    .order('created_at', { ascending: false });

  if (date) query = query.eq('date', date);
  if (status) query = query.eq('status', status);
  if (patientId) query = query.eq('patient_id', patientId);

  if (doctorId) {
    query = query.eq('doctor_id', doctorId);
  } else if (req.auth.role === 'doctor') {
    query = query.eq('doctor_id', req.auth.userId);
  }

  const { data, error } = await query;
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

// GET /api/visits/:id
app.get('/api/visits/:id', ...guard, async (req, res) => {
  const db = supabaseAs(req.auth.jwt);
  const { data, error } = await db
    .from('visits')
    .select(`
      *,
      patient:patients(*),
      doctor:users(id, name, name_ar, specialty_id),
      visit_type:visit_types(*),
      invoices(*, invoice_items(*, service:services(*)), payments(*)),
      medical_notes(*),
      medical_orders(*)
    `)
    .eq('id', req.params.id)
    .eq('clinic_id', req.auth.clinicId)
    .single();
  if (error) return res.status(404).json({ error: 'Visit not found' });
  res.json(data);
});

// POST /api/visits
app.post('/api/visits', ...guard, requireRole('admin', 'reception'), async (req, res) => {
  const { patientId, doctorId, visitTypeId, date, appointmentId } = req.body;
  if (!patientId || !doctorId || !date) {
    return res.status(400).json({ error: 'patientId, doctorId, date required' });
  }

  const { data: visitType } = await supabaseAdmin
    .from('visit_types')
    .select('price')
    .eq('id', visitTypeId)
    .single();

  const { data: visit, error: visitErr } = await supabaseAdmin
    .from('visits')
    .insert({
      clinic_id: req.auth.clinicId,
      patient_id: patientId,
      doctor_id: doctorId,
      visit_type_id: visitTypeId || null,
      date,
      status: 'booked',
      appointment_id: appointmentId || null,
    })
    .select()
    .single();

  if (visitErr) return res.status(500).json({ error: visitErr.message });

  const { data: invoice, error: invoiceErr } = await supabaseAdmin
    .from('invoices')
    .insert({
      clinic_id: req.auth.clinicId,
      visit_id: visit.id,
      patient_id: patientId,
      status: 'pending',
      total_amount: visitType?.price || 0,
      paid_amount: 0,
    })
    .select()
    .single();

  if (invoiceErr) return res.status(500).json({ error: invoiceErr.message });

  if (appointmentId) {
    await supabaseAdmin
      .from('appointments')
      .update({ status: 'converted' })
      .eq('id', appointmentId);
  }

  res.status(201).json({ ...visit, invoice });
});

// PATCH /api/visits/:id/status
app.patch('/api/visits/:id/status', ...guard, requireRole('admin', 'reception', 'doctor'), async (req, res) => {
  const { status } = req.body;
  if (!status) return res.status(400).json({ error: 'status required' });

  const { data, error } = await supabaseAdmin
    .from('visits')
    .update({ status, updated_at: new Date().toISOString() })
    .eq('id', req.params.id)
    .eq('clinic_id', req.auth.clinicId)
    .select()
    .single();

  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

// ═══════════════════════════════════════════════════════════
// QUEUE routes
// ═══════════════════════════════════════════════════════════

// GET /api/queue/today
app.get('/api/queue/today', ...guard, async (req, res) => {
  const db = supabaseAs(req.auth.jwt);
  const today = new Date().toISOString().split('T')[0];

  let query = db
    .from('visits')
    .select(`
      *,
      patient:patients(id, name, name_ar, phone),
      doctor:users(id, name, name_ar),
      visit_type:visit_types(id, name, name_ar, is_urgent),
      invoices(id, status, total_amount, paid_amount, paid_at)
    `)
    .eq('clinic_id', req.auth.clinicId)
    .eq('date', today)
    .not('status', 'in', '("completed","cancelled","no_show")')
    .order('arrival_time', { ascending: true, nullsFirst: false });

  if (req.auth.role === 'doctor') {
    query = query.eq('doctor_id', req.auth.userId);
  }

  const { data, error } = await query;
  if (error) return res.status(500).json({ error: error.message });
  res.json(data || []);
});

// PATCH /api/queue/:visitId/status
app.patch('/api/queue/:visitId/status', ...guard, requireRole('admin', 'reception', 'doctor'), async (req, res) => {
  const { status } = req.body;
  if (!status) return res.status(400).json({ error: 'status required' });

  const validStatuses = ['booked', 'checked_in', 'waiting', 'in_consultation', 'completed', 'no_show', 'cancelled'];
  if (!validStatuses.includes(status)) {
    return res.status(400).json({ error: 'Invalid status' });
  }

  const { data, error } = await supabaseAdmin
    .from('visits')
    .update({ status, updated_at: new Date().toISOString() })
    .eq('id', req.params.visitId)
    .eq('clinic_id', req.auth.clinicId)
    .select()
    .single();

  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

// PATCH /api/queue/:visitId/urgent
app.patch('/api/queue/:visitId/urgent', ...guard, requireRole('admin', 'reception'), async (req, res) => {
  const { data, error } = await supabaseAdmin
    .from('visits')
    .update({ arrival_time: new Date().toISOString(), updated_at: new Date().toISOString() })
    .eq('id', req.params.visitId)
    .eq('clinic_id', req.auth.clinicId)
    .select()
    .single();

  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

// ═══════════════════════════════════════════════════════════
// BILLING routes
// ═══════════════════════════════════════════════════════════

// GET /api/billing/invoices
app.get('/api/billing/invoices', ...guard, requireRole('admin', 'reception'), async (req, res) => {
  const db = supabaseAs(req.auth.jwt);
  const { status, patientId, date } = req.query;

  let query = db
    .from('invoices')
    .select(`
      *,
      patient:patients(id, name, name_ar, phone),
      visit:visits(id, status, doctor_id, date),
      invoice_items(*, service:services(id, name, name_ar, doctor_percentage)),
      payments(*)
    `)
    .eq('clinic_id', req.auth.clinicId)
    .order('created_at', { ascending: false });

  if (status) query = query.eq('status', status);
  if (patientId) query = query.eq('patient_id', patientId);

  const { data, error } = await query;
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

// POST /api/billing/invoices/:id/items
app.post('/api/billing/invoices/:id/items', ...guard, requireRole('admin', 'reception'), async (req, res) => {
  const { serviceId, quantity = 1, unitPrice } = req.body;
  if (!serviceId) return res.status(400).json({ error: 'serviceId required' });

  const { data: svc } = await supabaseAdmin
    .from('services')
    .select('price, doctor_percentage')
    .eq('id', serviceId)
    .single();
  if (!svc) return res.status(404).json({ error: 'Service not found' });

  const finalUnitPrice = unitPrice ?? svc.price;
  const totalPrice = finalUnitPrice * quantity;
  const doctorShare = +(totalPrice * (svc.doctor_percentage / 100)).toFixed(2);

  const { data, error } = await supabaseAdmin
    .from('invoice_items')
    .insert({
      invoice_id: req.params.id,
      service_id: serviceId,
      quantity,
      unit_price: finalUnitPrice,
      total_price: totalPrice,
      doctor_share: doctorShare,
    })
    .select()
    .single();

  if (error) return res.status(500).json({ error: error.message });
  res.status(201).json(data);
});

// PATCH /api/billing/invoices/:id/discount
app.patch('/api/billing/invoices/:id/discount', ...guard, requireRole('admin', 'reception'), async (req, res) => {
  const { discountType, discountValue } = req.body;

  const { data, error } = await supabaseAdmin
    .from('invoices')
    .update({
      discount_type: discountType,
      discount_value: discountValue,
      updated_at: new Date().toISOString(),
    })
    .eq('id', req.params.id)
    .eq('clinic_id', req.auth.clinicId)
    .select()
    .single();

  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

// POST /api/billing/invoices/:id/pay
app.post('/api/billing/invoices/:id/pay', ...guard, requireRole('admin', 'reception'), async (req, res) => {
  const { amount, method = 'cash', reference } = req.body;
  if (!amount || amount <= 0) return res.status(400).json({ error: 'Valid amount required' });

  const { data: payment, error: payErr } = await supabaseAdmin
    .from('payments')
    .insert({
      invoice_id: req.params.id,
      amount,
      method,
      reference: reference || null,
      paid_at: new Date().toISOString(),
    })
    .select()
    .single();

  if (payErr) return res.status(500).json({ error: payErr.message });

  const { data: invoice } = await supabaseAdmin
    .from('invoices')
    .select('total_amount, paid_amount')
    .eq('id', req.params.id)
    .single();

  if (invoice) {
    const newPaid = (invoice.paid_amount || 0) + amount;
    const newStatus = newPaid >= invoice.total_amount ? 'paid' : 'partially_paid';
    const paidAt = newStatus === 'paid' ? new Date().toISOString() : null;

    await supabaseAdmin
      .from('invoices')
      .update({
        paid_amount: newPaid,
        status: newStatus,
        paid_at: paidAt,
        updated_at: new Date().toISOString(),
      })
      .eq('id', req.params.id);

    if (newStatus === 'paid') {
      const { data: inv } = await supabaseAdmin
        .from('invoices')
        .select('visit_id')
        .eq('id', req.params.id)
        .single();
      if (inv?.visit_id) {
        await supabaseAdmin
          .from('visits')
          .update({ arrival_time: paidAt, status: 'checked_in', updated_at: new Date().toISOString() })
          .eq('id', inv.visit_id);
      }
    }
  }

  res.status(201).json(payment);
});

// POST /api/billing/invoices/:id/refund
app.post('/api/billing/invoices/:id/refund', ...guard, requireRole('admin'), async (req, res) => {
  const { data, error } = await supabaseAdmin
    .from('invoices')
    .update({ status: 'refunded', updated_at: new Date().toISOString() })
    .eq('id', req.params.id)
    .eq('clinic_id', req.auth.clinicId)
    .select()
    .single();

  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

// ═══════════════════════════════════════════════════════════
// REPORTS routes
// ═══════════════════════════════════════════════════════════

// GET /api/reports/summary
app.get('/api/reports/summary', ...guard, requireRole('admin', 'super_admin'), async (req, res) => {
  const { from, to } = req.query;
  if (!from || !to) return res.status(400).json({ error: 'from and to dates required' });

  const db = supabaseAs(req.auth.jwt);

  const [visitsRes, invoicesRes, patientsRes] = await Promise.all([
    db.from('visits')
      .select('id, status, date, doctor_id')
      .eq('clinic_id', req.auth.clinicId)
      .gte('date', from)
      .lte('date', to),
    db.from('invoices')
      .select('total_amount, paid_amount, status, created_at')
      .eq('clinic_id', req.auth.clinicId)
      .gte('created_at', `${from}T00:00:00`)
      .lte('created_at', `${to}T23:59:59`),
    db.from('patients')
      .select('id, created_at')
      .eq('clinic_id', req.auth.clinicId)
      .gte('created_at', `${from}T00:00:00`)
      .lte('created_at', `${to}T23:59:59`),
  ]);

  const visits = visitsRes.data || [];
  const invoices = invoicesRes.data || [];
  const newPatients = patientsRes.data || [];

  const totalRevenue = invoices
    .filter(i => i.status === 'paid')
    .reduce((sum, i) => sum + (i.paid_amount || 0), 0);

  const completedVisits = visits.filter(v => v.status === 'completed').length;
  const cancelledVisits = visits.filter(v => v.status === 'cancelled').length;
  const noShowVisits = visits.filter(v => v.status === 'no_show').length;

  res.json({
    totalVisits: visits.length,
    completedVisits,
    cancelledVisits,
    noShowVisits,
    totalRevenue,
    newPatients: newPatients.length,
    pendingInvoices: invoices.filter(i => i.status === 'pending').length,
  });
});

// ═══════════════════════════════════════════════════════════
// SERVICES + SPECIALTIES routes
// ═══════════════════════════════════════════════════════════

// GET /api/specialties
app.get('/api/specialties', requireSupabase, async (_req, res) => {
  const { data, error } = await supabaseAdmin
    .from('specialties')
    .select('*')
    .eq('is_active', true)
    .order('name');
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

// GET /api/services
app.get('/api/services', requireSupabase, async (req, res) => {
  const { specialtyId } = req.query;
  let query = supabaseAdmin.from('services').select('*').eq('is_active', true);
  if (specialtyId) query = query.eq('specialty_id', specialtyId);
  const { data, error } = await query;
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

// ═══════════════════════════════════════════════════════════
// DOCTOR SCHEDULE routes
// ═══════════════════════════════════════════════════════════

// GET /api/schedule/:doctorId
app.get('/api/schedule/:doctorId', requireSupabase, async (req, res) => {
  const { data, error } = await supabaseAdmin
    .from('doctor_schedules')
    .select('*')
    .eq('doctor_id', req.params.doctorId)
    .eq('is_active', true)
    .order('day_of_week');
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

// PUT /api/schedule/:doctorId
app.put('/api/schedule/:doctorId', ...guard, requireRole('admin', 'doctor'), async (req, res) => {
  const { schedule } = req.body;
  if (!Array.isArray(schedule)) return res.status(400).json({ error: 'schedule array required' });

  await supabaseAdmin
    .from('doctor_schedules')
    .delete()
    .eq('doctor_id', req.params.doctorId);

  if (schedule.length === 0) return res.json([]);

  const { data, error } = await supabaseAdmin
    .from('doctor_schedules')
    .insert(schedule.map(s => ({
      doctor_id: req.params.doctorId,
      day_of_week: s.dayOfWeek,
      start_time: s.startTime,
      end_time: s.endTime,
      is_active: true,
    })))
    .select();

  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

// ═══════════════════════════════════════════════════════════
// CLINIC PROFILE routes
// ═══════════════════════════════════════════════════════════

// GET /api/clinics/:id/public  — public profile
app.get('/api/clinics/:id/public', requireSupabase, async (req, res) => {
  const { data, error } = await supabaseAdmin
    .from('clinics')
    .select(`
      id, name, name_ar, address, address_ar, phone, city, city_ar,
      description, description_ar, cover_image_url, working_hours, working_hours_ar,
      latitude, longitude, website, social_links,
      users!users_clinic_id_fkey(
        id, name, name_ar, specialty_id,
        specialties(name, name_ar)
      )
    `)
    .eq('id', req.params.id)
    .eq('is_active', true)
    .single();
  if (error) return res.status(404).json({ error: 'Clinic not found' });
  res.json(data);
});

// PATCH /api/clinics/:id/profile — admin update clinic profile
app.patch('/api/clinics/:id/profile', ...guard, requireRole('admin', 'super_admin'), async (req, res) => {
  const allowed = ['name', 'name_ar', 'address', 'address_ar', 'phone', 'city', 'city_ar',
    'description', 'description_ar', 'cover_image_url', 'working_hours', 'working_hours_ar',
    'latitude', 'longitude', 'website', 'social_links'];
  const updates = { updated_at: new Date().toISOString() };
  for (const key of allowed) {
    if (req.body[key] !== undefined) updates[key] = req.body[key];
  }

  const { data, error } = await supabaseAdmin
    .from('clinics')
    .update(updates)
    .eq('id', req.params.id)
    .select()
    .single();

  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

// ═══════════════════════════════════════════════════════════
// HEALTH CHECK
// ═══════════════════════════════════════════════════════════
app.get('/health', (_req, res) => res.json({ status: 'ok', supabase: supabaseReady, ts: new Date().toISOString() }));

// ═══════════════════════════════════════════════════════════
// Static + SPA fallback
// ═══════════════════════════════════════════════════════════
app.use(express.static(path.join(__dirname, 'dist')));

app.get('/{*path}', (req, res) => {
  res.sendFile(path.join(__dirname, 'dist', 'index.html'));
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, '0.0.0.0', () => {
  console.log(`API server running on port ${PORT}`);
});
