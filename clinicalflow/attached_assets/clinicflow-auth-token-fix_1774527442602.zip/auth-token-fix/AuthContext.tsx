import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { UserRole, Patient } from '@/types';
import { userStore } from '@/stores/userStore';
import { patientStore, persistPatient } from '@/stores/patientStore';
import { getClinicsForDoctor } from '@/stores/doctorClinicStore';
import { registrationStore } from '@/stores/registrationStore';

// ── localStorage keys ─────────────────────────────────────────────────────────
const LS_PASS_KEY    = 'cf_patient_passwords';
const LS_TOKEN_KEY   = 'cf_token';
const LS_REFRESH_KEY = 'cf_refresh';
const LS_USER_KEY    = 'cf_user';

const API = '/api';

// ── Token helpers ─────────────────────────────────────────────────────────────
export function getToken(): string | null {
  return localStorage.getItem(LS_TOKEN_KEY);
}

function saveSession(token: string, refresh: string, user: AuthUser) {
  localStorage.setItem(LS_TOKEN_KEY,   token);
  localStorage.setItem(LS_REFRESH_KEY, refresh);
  localStorage.setItem(LS_USER_KEY,    JSON.stringify(user));
}

function clearSession() {
  localStorage.removeItem(LS_TOKEN_KEY);
  localStorage.removeItem(LS_REFRESH_KEY);
  localStorage.removeItem(LS_USER_KEY);
}

function loadSavedUser(): AuthUser | null {
  try {
    const raw = localStorage.getItem(LS_USER_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch { return null; }
}

// ── Patient password helpers ───────────────────────────────────────────────────
function loadPasswords(): Record<string, string> {
  try { return JSON.parse(localStorage.getItem(LS_PASS_KEY) || '{}'); } catch { return {}; }
}

function savePassword(id: string, pw: string) {
  try {
    const all = loadPasswords();
    all[id] = pw;
    localStorage.setItem(LS_PASS_KEY, JSON.stringify(all));
  } catch { /* graceful */ }
}

// ── Types ─────────────────────────────────────────────────────────────────────
export interface AuthUser {
  id: string;
  name: string;
  nameAr: string;
  email: string;
  role: UserRole | 'patient' | 'super_admin';
  specialtyId?: string;
  patientId?: string;
  clinicId: string;
}

interface AuthContextType {
  user: AuthUser | null;
  pendingDoctorClinics: string[] | null;
  pendingDoctorUser: AuthUser | null;
  login: (clinicId: string, role: UserRole) => void;
  loginStaff: (email: string, password: string) => Promise<{ ok: boolean; error?: string }>;
  loginAsSuperAdmin: (password: string) => boolean;
  loginAsPatient: (phone: string, password: string) => { ok: boolean; error?: string };
  registerPatient: (data: { name: string; phone: string; email: string; password: string }) => boolean;
  selectClinicForDoctor: (clinicId: string) => void;
  switchClinic: () => void;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const SUPER_ADMIN_PASSWORD = 'superadmin2024';

// ── Seed patient passwords ─────────────────────────────────────────────────────
const PATIENT_PASSWORDS: Record<string, string> = {
  'pt-demo': 'patient2024',
  'pt-1': 'patient123', 'pt-2': 'patient123', 'pt-3': 'patient123',
  'pt-4': 'patient123', 'pt-5': 'patient123', 'pt-6': 'patient123',
  'pt-7': 'patient123', 'pt-8': 'patient123',
  'pt-20': 'patient123', 'pt-21': 'patient123', 'pt-22': 'patient123',
  'pt-30': 'patient123', 'pt-31': 'patient123',
};

// ── Seed staff passwords (fallback when Supabase not connected) ───────────────
const STAFF_PASSWORDS: Record<string, string> = {
  'u-1':  'admin123',     'u-2':  'doctor123',    'u-3':  'doctor123',
  'u-4':  'doctor123',    'u-5':  'doctor123',    'u-6':  'reception123',
  'u-10': 'admin123',     'u-11': 'doctor123',    'u-12': 'reception123',
  'u-20': 'admin123',     'u-21': 'doctor123',    'u-22': 'reception123',
};

// ── Map Supabase user profile → AuthUser ─────────────────────────────────────
function mapProfile(p: any): AuthUser {
  return {
    id:          p.id,
    name:        p.name,
    nameAr:      p.name_ar ?? p.name,
    email:       p.email ?? '',
    role:        p.role,
    specialtyId: p.specialty_id ?? undefined,
    clinicId:    p.clinic_id ?? '',
  };
}

// ── Provider ──────────────────────────────────────────────────────────────────
export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Restore session from localStorage on first load
  const [user, setUser]                       = useState<AuthUser | null>(loadSavedUser);
  const [pendingDoctorClinics, setPendingDoctorClinics] = useState<string[] | null>(null);
  const [pendingDoctorUser, setPendingDoctorUser]       = useState<AuthUser | null>(null);

  // ── On mount: verify saved token is still valid ────────────────────────────
  useEffect(() => {
    const token = getToken();
    if (!token || !user) return;
    // Only verify staff/admin tokens — patients are local-only
    if (user.role === 'patient' || user.role === 'super_admin') return;
    fetch(`${API}/auth/me`, {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then(r => r.ok ? r.json() : null)
      .then(data => {
        if (data) {
          const refreshed = mapProfile(data);
          setUser(refreshed);
          localStorage.setItem(LS_USER_KEY, JSON.stringify(refreshed));
        } else {
          // Token expired or invalid — clear session
          clearSession();
          setUser(null);
        }
      })
      .catch(() => {
        // Network error — keep cached user, they'll get 401 on next API call
      });
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Legacy role-picker (still used internally) ────────────────────────────
  const login = (clinicId: string, role: UserRole) => {
    const storeUser = userStore.get(u => u.clinicId === clinicId && u.role === role && u.isActive);
    if (!storeUser) return;
    const authUser: AuthUser = {
      id: storeUser.id, name: storeUser.name, nameAr: storeUser.nameAr,
      email: storeUser.email, role: storeUser.role,
      specialtyId: storeUser.specialtyId, clinicId: storeUser.clinicId,
    };
    if (role === 'doctor') {
      const links = getClinicsForDoctor(storeUser.id);
      if (links.length > 1) { setPendingDoctorUser(authUser); setPendingDoctorClinics(links); return; }
    }
    setUser(authUser);
  };

  // ── Staff login — tries real API first, falls back to in-memory ───────────
  const loginStaff = async (email: string, password: string): Promise<{ ok: boolean; error?: string }> => {
    // ── Attempt 1: real Supabase login via /api/auth/login ────────────────
    try {
      const res = await fetch(`${API}/auth/login`, {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ email: email.trim(), password }),
      });

      if (res.ok) {
        const data = await res.json();
        const authUser = mapProfile(data.user);

        // Save token + user to localStorage
        saveSession(data.token, data.refresh, authUser);

        // Handle multi-clinic doctor
        if (authUser.role === 'doctor') {
          const links = getClinicsForDoctor(authUser.id);
          if (links.length > 1) {
            setPendingDoctorUser(authUser);
            setPendingDoctorClinics(links);
            return { ok: true };
          }
        }
        setUser(authUser);
        return { ok: true };
      }

      // 401/403 from Supabase — wrong credentials
      if (res.status === 401 || res.status === 403) {
        const err = await res.json().catch(() => ({}));
        return { ok: false, error: err.error || 'بيانات الدخول غير صحيحة.' };
      }

      // 503 = Supabase not configured → fall through to in-memory
      if (res.status !== 503) {
        const err = await res.json().catch(() => ({}));
        return { ok: false, error: err.error || 'حدث خطأ، حاول مرة أخرى.' };
      }
    } catch {
      // Network error or Supabase offline → fall through to in-memory
    }

    // ── Fallback: in-memory store (demo / Supabase not configured) ────────
    const e = email.trim().toLowerCase();
    const staffUser = userStore.get(u => u.email.toLowerCase() === e && u.isActive);
    if (!staffUser) {
      return { ok: false, error: 'لم يتم العثور على حساب بهذا البريد الإلكتروني.' };
    }
    let dynamicPw: Record<string, string> = {};
    try { dynamicPw = JSON.parse(localStorage.getItem('cf_staff_passwords') || '{}'); } catch {}
    const expected = STAFF_PASSWORDS[staffUser.id] ?? dynamicPw[staffUser.id];
    if (expected && expected !== password) {
      return { ok: false, error: 'كلمة المرور غير صحيحة.' };
    }
    const authUser: AuthUser = {
      id: staffUser.id, name: staffUser.name, nameAr: staffUser.nameAr,
      email: staffUser.email, role: staffUser.role,
      specialtyId: staffUser.specialtyId, clinicId: staffUser.clinicId,
    };
    // Save to localStorage even in fallback mode (no real token)
    localStorage.setItem(LS_USER_KEY, JSON.stringify(authUser));

    if (staffUser.role === 'doctor') {
      const links = getClinicsForDoctor(staffUser.id);
      if (links.length > 1) {
        setPendingDoctorUser(authUser);
        setPendingDoctorClinics(links);
        return { ok: true };
      }
    }
    setUser(authUser);
    return { ok: true };
  };

  const selectClinicForDoctor = (clinicId: string) => {
    if (!pendingDoctorUser) return;
    const doctorInClinic = userStore.get(u => u.clinicId === clinicId && u.role === 'doctor' && u.isActive);
    const finalUser: AuthUser = {
      ...pendingDoctorUser,
      clinicId,
      specialtyId: doctorInClinic?.specialtyId ?? pendingDoctorUser.specialtyId,
    };
    setUser(finalUser);
    localStorage.setItem(LS_USER_KEY, JSON.stringify(finalUser));
    setPendingDoctorClinics(null);
    setPendingDoctorUser(null);
  };

  const switchClinic = () => {
    if (!user || user.role !== 'doctor') return;
    const links = getClinicsForDoctor(user.id);
    if (links.length > 1) {
      setPendingDoctorUser(user);
      setPendingDoctorClinics(links);
      setUser(null);
    }
  };

  const loginAsSuperAdmin = (password: string): boolean => {
    if (password !== SUPER_ADMIN_PASSWORD) return false;
    const authUser: AuthUser = {
      id: 'super-admin', name: 'Super Admin', nameAr: 'المدير العام',
      email: 'superadmin@clinicflow.io', role: 'super_admin', clinicId: 'super',
    };
    setUser(authUser);
    localStorage.setItem(LS_USER_KEY, JSON.stringify(authUser));
    return true;
  };

  // ── Patient login — phone + password (local only, no Supabase) ─────────────
  const loginAsPatient = (phone: string, password: string): { ok: boolean; error?: string } => {
    const trimmed = phone.trim();
    if (!trimmed)  return { ok: false, error: 'أدخل رقم الهاتف.' };
    if (!password) return { ok: false, error: 'أدخل كلمة المرور.' };

    // 1. Find in patientStore
    let patient = patientStore.get(p => p.phone === trimmed);

    // 2. Fallback: registrationStore
    if (!patient) {
      const reg = registrationStore.get(r => r.type === 'patient' && r.phone === trimmed);
      if (reg) {
        const newPt: Patient = {
          id: `pt-reg-${reg.id}`, name: reg.name, nameAr: reg.name,
          phone: reg.phone, email: reg.email,
          dateOfBirth: '', gender: 'male', createdAt: reg.createdAt,
        };
        const already = patientStore.get(p => p.phone === newPt.phone);
        if (!already) { patientStore.add(newPt); persistPatient(newPt); if (reg.password) savePassword(newPt.id, reg.password); }
        patient = already ?? newPt;
      }
    }

    if (!patient) return { ok: false, error: 'لم يتم العثور على حساب بهذا الرقم.' };

    // 3. Validate password
    const storedPw = loadPasswords()[patient.id];
    const seedPw   = PATIENT_PASSWORDS[patient.id];
    const expected = storedPw ?? seedPw;
    if (expected && expected !== password) {
      return { ok: false, error: 'كلمة المرور غير صحيحة.' };
    }

    const authUser: AuthUser = {
      id: patient.id, name: patient.name, nameAr: patient.nameAr,
      email: patient.email || '', role: 'patient',
      patientId: patient.id, clinicId: patient.clinicId ?? '',
    };
    setUser(authUser);
    localStorage.setItem(LS_USER_KEY, JSON.stringify(authUser));
    return { ok: true };
  };

  const registerPatient = (data: { name: string; phone: string; email: string; password: string }): boolean => {
    const existing = patientStore.get(p => p.phone === data.phone || (data.email && p.email === data.email));
    if (existing) return false;

    const patient: Patient = {
      id: `pt-${Date.now()}`, name: data.name, nameAr: data.name,
      phone: data.phone, email: data.email,
      dateOfBirth: '', gender: 'male', createdAt: new Date().toISOString(),
    };
    patientStore.add(patient);
    persistPatient(patient);
    if (data.password) savePassword(patient.id, data.password);

    const authUser: AuthUser = {
      id: patient.id, name: patient.name, nameAr: patient.nameAr,
      email: patient.email || '', role: 'patient',
      patientId: patient.id, clinicId: '',
    };
    setUser(authUser);
    localStorage.setItem(LS_USER_KEY, JSON.stringify(authUser));
    return true;
  };

  const logout = () => {
    // Fire-and-forget server logout (don't block UI)
    const token = getToken();
    if (token) {
      fetch(`${API}/auth/logout`, {
        method:  'POST',
        headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      }).catch(() => {});
    }
    clearSession();
    setUser(null);
    setPendingDoctorClinics(null);
    setPendingDoctorUser(null);
  };

  return (
    <AuthContext.Provider value={{
      user, pendingDoctorClinics, pendingDoctorUser,
      login, loginStaff, loginAsSuperAdmin, loginAsPatient, registerPatient,
      selectClinicForDoctor, switchClinic, logout,
      isAuthenticated: !!user,
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within an AuthProvider');
  return context;
};
