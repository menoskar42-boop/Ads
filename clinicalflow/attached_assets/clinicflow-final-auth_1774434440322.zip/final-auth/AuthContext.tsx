import React, { createContext, useContext, useState, ReactNode } from 'react';
import { UserRole, Patient } from '@/types';
import { userStore } from '@/stores/userStore';
import { patientStore } from '@/stores/patientStore';
import { getClinicsForDoctor } from '@/stores/doctorClinicStore';
import { registrationStore } from '@/stores/registrationStore';

// ─────────────────────────────────────────────────────────────────────────────
// Types
// ─────────────────────────────────────────────────────────────────────────────

export interface AuthUser {
  id: string;
  name: string;
  nameAr: string;
  email: string;
  role: UserRole | 'patient' | 'super_admin';
  specialtyId?: string;
  patientId?: string;
  clinicId: string;
}

interface LoginResult {
  ok: boolean;
  error?: string;
  /** 'pending' means doctor/clinic registered but not yet approved by super admin */
  status?: 'pending';
}

interface AuthContextType {
  user: AuthUser | null;
  pendingDoctorClinics: string[] | null;
  pendingDoctorUser: AuthUser | null;
  isAuthenticated: boolean;

  // ── Primary login methods ──
  /** Patient: email + password */
  loginPatient: (email: string, password: string) => LoginResult;
  /** Clinic staff: email + password → resolves role automatically */
  loginStaff: (email: string, password: string) => LoginResult;
  /** Super admin: password only (used on hidden page) */
  loginAsSuperAdmin: (password: string) => boolean;

  // ── Registration ──
  registerPatient: (data: PatientRegData) => LoginResult;

  // ── Multi-clinic doctor ──
  selectClinicForDoctor: (clinicId: string) => void;
  switchClinic: () => void;

  // ── Legacy (kept for internal compatibility) ──
  login: (clinicId: string, role: UserRole) => void;
  loginAsPatient: (identifier: string) => boolean;

  logout: () => void;
}

interface PatientRegData {
  name: string;
  phone: string;
  email: string;
  password: string;
  usedReferralCode?: string;
}

// ─────────────────────────────────────────────────────────────────────────────
// Password store (in-memory — replace with Supabase Auth in production)
// Keyed by user id for patients, by lowercase email for staff
// ─────────────────────────────────────────────────────────────────────────────
const PATIENT_PASSWORDS: Record<string, string> = {};

// Staff passwords — set per user id (not email) to survive email changes
const STAFF_PASSWORDS: Record<string, string> = {
  // Nile Medical Center
  'u-1':  'admin123',       // admin@clinic.demo
  'u-2':  'doctor123',      // ahmed@clinic.demo
  'u-3':  'doctor123',      // sarah@clinic.demo
  'u-4':  'doctor123',      // omar@clinic.demo
  'u-5':  'doctor123',      // lisa@clinic.demo
  'u-6':  'reception123',   // reception@clinic.demo
  // Cairo Health Clinic
  'u-10': 'admin123',       // admin@cairo.demo
  'u-11': 'doctor123',      // doctor@cairo.demo
  'u-12': 'reception123',   // reception@cairo.demo
  // Alexandria Care Center
  'u-20': 'admin123',       // admin@alex.demo
  'u-21': 'doctor123',      // doctor@alex.demo
  'u-22': 'reception123',   // reception@alex.demo
};

const SUPER_ADMIN_PASSWORD = 'superadmin2024';

// ─────────────────────────────────────────────────────────────────────────────
// Context
// ─────────────────────────────────────────────────────────────────────────────
const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser]                           = useState<AuthUser | null>(null);
  const [pendingDoctorClinics, setPendingDoctorClinics] = useState<string[] | null>(null);
  const [pendingDoctorUser, setPendingDoctorUser]       = useState<AuthUser | null>(null);

  // ── helpers ────────────────────────────────────────────────────────────────
  const setStaffUser = (storeUser: ReturnType<typeof userStore.get>): LoginResult => {
    if (!storeUser) return { ok: false, error: 'حساب غير موجود.' };
    const authUser: AuthUser = {
      id: storeUser.id, name: storeUser.name, nameAr: storeUser.nameAr,
      email: storeUser.email, role: storeUser.role,
      specialtyId: storeUser.specialtyId, clinicId: storeUser.clinicId,
    };
    if (storeUser.role === 'doctor') {
      const links = getClinicsForDoctor(storeUser.id);
      if (links.length > 1) {
        setPendingDoctorUser(authUser);
        setPendingDoctorClinics(links);
        return { ok: true };
      }
    }
    setUser(authUser);
    return { ok: true };
  };

  // ── loginPatient ───────────────────────────────────────────────────────────
  // Email + password. Falls back to registrationStore for newly registered users.
  const loginPatient = (email: string, password: string): LoginResult => {
    const e = email.trim().toLowerCase();

    // 1. Existing patient in patientStore
    const patient = patientStore.get(p => p.email?.toLowerCase() === e);
    if (patient) {
      const stored = PATIENT_PASSWORDS[patient.id];
      if (stored && stored !== password) {
        return { ok: false, error: 'كلمة المرور غير صحيحة.' };
      }
      // First-time login after direct add (clinic added patient manually)
      if (!stored) PATIENT_PASSWORDS[patient.id] = password;
      setUser({
        id: patient.id, name: patient.name, nameAr: patient.nameAr,
        email: patient.email || '', role: 'patient',
        patientId: patient.id, clinicId: patient.clinicId ?? '',
      });
      return { ok: true };
    }

    // 2. Patient registered via RegisterPage (in registrationStore)
    const reg = registrationStore.get(
      r => r.type === 'patient' && r.email.toLowerCase() === e
    );
    if (reg) {
      if (reg.password && reg.password !== password) {
        return { ok: false, error: 'كلمة المرور غير صحيحة.' };
      }
      // Promote to patientStore
      const newPt: Patient = {
        id: `pt-reg-${reg.id}`, name: reg.name, nameAr: reg.name,
        phone: reg.phone, email: reg.email,
        dateOfBirth: '', gender: 'male', createdAt: reg.createdAt,
      };
      const already = patientStore.get(p => p.email?.toLowerCase() === e);
      if (!already) {
        patientStore.add(newPt);
        PATIENT_PASSWORDS[newPt.id] = reg.password || password;
      }
      const final = already ?? newPt;
      setUser({
        id: final.id, name: final.name, nameAr: final.nameAr,
        email: final.email || '', role: 'patient',
        patientId: final.id, clinicId: '',
      });
      return { ok: true };
    }

    return { ok: false, error: 'لم يتم العثور على حساب بهذا البريد الإلكتروني.' };
  };

  // ── loginStaff ─────────────────────────────────────────────────────────────
  // Email + password → finds user → checks password → sets session
  const loginStaff = (email: string, password: string): LoginResult => {
    const e = email.trim().toLowerCase();
    const staffUser = userStore.get(u => u.email.toLowerCase() === e && u.isActive);

    if (!staffUser) {
      return { ok: false, error: 'لم يتم العثور على حساب بهذا البريد الإلكتروني.' };
    }

    const stored = STAFF_PASSWORDS[staffUser.id];
    if (stored && stored !== password) {
      return { ok: false, error: 'كلمة المرور غير صحيحة.' };
    }
    // Auto-save password if first login (for newly added staff)
    if (!stored) STAFF_PASSWORDS[staffUser.id] = password;

    return setStaffUser(staffUser);
  };

  // ── loginAsSuperAdmin ──────────────────────────────────────────────────────
  const loginAsSuperAdmin = (password: string): boolean => {
    if (password !== SUPER_ADMIN_PASSWORD) return false;
    setUser({
      id: 'super-admin', name: 'Super Admin', nameAr: 'المدير العام',
      email: 'superadmin@clinicflow.io', role: 'super_admin', clinicId: 'super',
    });
    return true;
  };

  // ── registerPatient ────────────────────────────────────────────────────────
  // Creates account and logs in immediately
  const registerPatient = (data: PatientRegData): LoginResult => {
    const e = data.email.trim().toLowerCase();
    const duplicate = patientStore.get(
      p => p.phone === data.phone || p.email?.toLowerCase() === e
    ) || registrationStore.get(
      r => r.type === 'patient' && (r.phone === data.phone || r.email.toLowerCase() === e)
    );
    if (duplicate) {
      return { ok: false, error: 'يوجد حساب مسجّل بهذا البريد أو رقم الهاتف بالفعل.' };
    }

    const patient: Patient = {
      id:          `pt-${Date.now()}`,
      name:        data.name.trim(),
      nameAr:      data.name.trim(),
      phone:       data.phone.trim(),
      email:       e,
      dateOfBirth: '',
      gender:      'male',
      createdAt:   new Date().toISOString(),
    };
    patientStore.add(patient);
    PATIENT_PASSWORDS[patient.id] = data.password;

    setUser({
      id: patient.id, name: patient.name, nameAr: patient.nameAr,
      email: patient.email || '', role: 'patient',
      patientId: patient.id, clinicId: '',
    });
    return { ok: true };
  };

  // ── Multi-clinic doctor ────────────────────────────────────────────────────
  const selectClinicForDoctor = (clinicId: string) => {
    if (!pendingDoctorUser) return;
    const d = userStore.get(u => u.clinicId === clinicId && u.role === 'doctor' && u.isActive);
    setUser({ ...pendingDoctorUser, clinicId, specialtyId: d?.specialtyId ?? pendingDoctorUser.specialtyId });
    setPendingDoctorClinics(null);
    setPendingDoctorUser(null);
  };

  const switchClinic = () => {
    if (!user || user.role !== 'doctor') return;
    const links = getClinicsForDoctor(user.id);
    if (links.length > 1) {
      setPendingDoctorUser(user);
      setPendingDoctorClinics(links);
      setUser(null);
    }
  };

  // ── Legacy ─────────────────────────────────────────────────────────────────
  const login = (clinicId: string, role: UserRole) => {
    const u = userStore.get(u => u.clinicId === clinicId && u.role === role && u.isActive);
    if (u) setStaffUser(u);
  };

  const loginAsPatient = (identifier: string): boolean => {
    const t = identifier.trim();
    const p = patientStore.get(pt => pt.phone === t || (pt.email && pt.email === t));
    if (p) {
      setUser({ id: p.id, name: p.name, nameAr: p.nameAr, email: p.email || '', role: 'patient', patientId: p.id, clinicId: p.clinicId ?? '' });
      return true;
    }
    // Fallback to registrationStore
    const reg = registrationStore.get(r => r.type === 'patient' && (r.phone === t || r.email === t));
    if (reg) {
      const np: Patient = { id: `pt-reg-${reg.id}`, name: reg.name, nameAr: reg.name, phone: reg.phone, email: reg.email, dateOfBirth: '', gender: 'male', createdAt: reg.createdAt };
      const already = patientStore.get(pt => pt.phone === np.phone);
      if (!already) patientStore.add(np);
      const final = already ?? np;
      setUser({ id: final.id, name: final.name, nameAr: final.nameAr, email: final.email || '', role: 'patient', patientId: final.id, clinicId: '' });
      return true;
    }
    return false;
  };

  // ── Logout ─────────────────────────────────────────────────────────────────
  const logout = () => {
    setUser(null);
    setPendingDoctorClinics(null);
    setPendingDoctorUser(null);
  };

  return (
    <AuthContext.Provider value={{
      user, pendingDoctorClinics, pendingDoctorUser, isAuthenticated: !!user,
      loginPatient, loginStaff, loginAsSuperAdmin,
      registerPatient, selectClinicForDoctor, switchClinic,
      login, loginAsPatient, logout,
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within an AuthProvider');
  return ctx;
};
