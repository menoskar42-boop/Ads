import React, { useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { clinicStore } from '@/stores/clinicStore';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import {
  User, ArrowLeft, Building2, ChevronRight,
  Mail, Lock, Eye, EyeOff, UserPlus, Loader2,
} from 'lucide-react';
import logoImg from '@assets/Untitled_design_1772868317886.png';

type Tab = 'patient' | 'staff';

const T = {
  ar: {
    backHome: 'العودة للرئيسية',
    registerNow: 'سجل الآن',
    welcomeBack: 'مرحباً بعودتك',
    subtitle: 'سجّل دخولك إلى حسابك في ClinicFlow',
    tabPatient: 'مريض',
    tabStaff: 'موظفو العيادة',
    // Patient
    patientTitle: 'دخول المرضى',
    patientDesc: 'سجّل دخولك ببريدك الإلكتروني وكلمة المرور',
    emailLabel: 'البريد الإلكتروني',
    emailPh: 'example@email.com',
    passLabel: 'كلمة المرور',
    passPh: '••••••••',
    signIn: 'تسجيل الدخول',
    noAccount: 'ليس لديك حساب؟',
    createAccount: 'إنشاء حساب مريض',
    // Staff
    staffTitle: 'دخول موظفي العيادة',
    staffDesc: 'سجّل دخولك ببريدك الإلكتروني وكلمة المرور',
    staffEmailLabel: 'البريد الإلكتروني للعمل',
    staffEmailPh: 'you@yourclinic.com',
    staffSignIn: 'دخول',
    forgotPass: 'لإعادة تعيين كلمة المرور تواصل مع مدير العيادة.',
    registerClinic: 'تريد تسجيل عيادتك؟',
    registerClinicLink: 'سجّل هنا',
    // Multi-clinic
    multiTitle: 'اختر عيادتك',
    multiDesc: 'أنت مسجّل في أكثر من عيادة. اختر التي تريد الدخول إليها.',
    // Errors
    errEmpty: 'أدخل البريد الإلكتروني وكلمة المرور.',
    terms: 'بتسجيل دخولك فأنت توافق على',
    termsLink: 'شروط الخدمة',
    and: 'و',
    privacyLink: 'سياسة الخصوصية',
  },
  en: {
    backHome: 'Back to Home',
    registerNow: 'Sign Up',
    welcomeBack: 'Welcome back',
    subtitle: 'Sign in to your ClinicFlow account',
    tabPatient: 'Patient',
    tabStaff: 'Clinic Staff',
    patientTitle: 'Patient Login',
    patientDesc: 'Sign in with your email and password',
    emailLabel: 'Email',
    emailPh: 'example@email.com',
    passLabel: 'Password',
    passPh: '••••••••',
    signIn: 'Sign In',
    noAccount: "Don't have an account?",
    createAccount: 'Create a Patient Account',
    staffTitle: 'Clinic Staff Login',
    staffDesc: 'Sign in with your work email and password',
    staffEmailLabel: 'Work Email',
    staffEmailPh: 'you@yourclinic.com',
    staffSignIn: 'Sign In',
    forgotPass: 'Contact your clinic admin to reset your password.',
    registerClinic: 'Want to register your clinic?',
    registerClinicLink: 'Register here',
    multiTitle: 'Select Your Clinic',
    multiDesc: 'You are registered in multiple clinics. Choose which one to enter.',
    errEmpty: 'Please enter email and password.',
    terms: 'By signing in you agree to our',
    termsLink: 'Terms of Service',
    and: 'and',
    privacyLink: 'Privacy Policy',
  },
} as const;

// ── Shared email+password form ────────────────────────────────────────────────
interface CredFormProps {
  emailLabel: string; emailPh: string;
  passLabel: string;  passPh: string;
  submitLabel: string;
  loading: boolean;
  error: string;
  onSubmit: (email: string, password: string) => void;
  isRTL: boolean;
  children?: React.ReactNode; // extra content below button
}

const CredForm: React.FC<CredFormProps> = ({
  emailLabel, emailPh, passLabel, passPh, submitLabel,
  loading, error, onSubmit, isRTL, children,
}) => {
  const [email, setEmail]   = useState('');
  const [pass, setPass]     = useState('');
  const [show, setShow]     = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(email, pass);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4" noValidate>
      <div className="space-y-1.5">
        <Label htmlFor={`email-${submitLabel}`}>{emailLabel}</Label>
        <div className="relative">
          <Mail className={`absolute ${isRTL ? 'right-3' : 'left-3'} top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground`} />
          <Input
            id={`email-${submitLabel}`}
            type="email"
            className={isRTL ? 'pr-9' : 'pl-9'}
            placeholder={emailPh}
            autoComplete="email"
            value={email}
            onChange={e => setEmail(e.target.value)}
          />
        </div>
      </div>

      <div className="space-y-1.5">
        <Label htmlFor={`pass-${submitLabel}`}>{passLabel}</Label>
        <div className="relative">
          <Lock className={`absolute ${isRTL ? 'right-3' : 'left-3'} top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground`} />
          <Input
            id={`pass-${submitLabel}`}
            type={show ? 'text' : 'password'}
            className={isRTL ? 'pr-9 ps-9' : 'pl-9 pr-9'}
            placeholder={passPh}
            autoComplete="current-password"
            value={pass}
            onChange={e => setPass(e.target.value)}
          />
          <button
            type="button"
            tabIndex={-1}
            onMouseDown={e => e.preventDefault()}
            onClick={() => setShow(v => !v)}
            className={`absolute ${isRTL ? 'left-3' : 'right-3'} top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground`}
          >
            {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
          </button>
        </div>
      </div>

      {error && (
        <p className="text-sm text-destructive bg-destructive/5 border border-destructive/20 rounded px-3 py-2">
          {error}
        </p>
      )}

      <Button type="submit" className="w-full" disabled={loading}>
        {loading
          ? <><Loader2 className="h-4 w-4 animate-spin me-2" />{isRTL ? 'جاري الدخول...' : 'Signing in...'}</>
          : submitLabel
        }
      </Button>

      {children}
    </form>
  );
};

// ── Main Login page ───────────────────────────────────────────────────────────
const Login: React.FC = () => {
  const { loginPatient, loginStaff, pendingDoctorClinics, selectClinicForDoctor } = useAuth();
  const { language, setLanguage, isRTL } = useLanguage();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const returnDoctor = searchParams.get('returnDoctor');

  const t    = T[language as 'ar' | 'en'];
  const isAr = language === 'ar';

  const [tab, setTab]                 = useState<Tab>('patient');
  const [patientError, setPatientError] = useState('');
  const [staffError, setStaffError]   = useState('');
  const [patientLoading, setPatientLoading] = useState(false);
  const [staffLoading, setStaffLoading]     = useState(false);

  const clinics = clinicStore.getAll().filter(c => c.isActive);

  // ── Multi-clinic doctor selection ─────────────────────────────────────────
  if (pendingDoctorClinics) {
    const doctorClinics = pendingDoctorClinics
      .map(cid => clinicStore.filter(c => c.id === cid)[0])
      .filter(Boolean);
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4" dir={isRTL ? 'rtl' : 'ltr'}>
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <Building2 className="h-10 w-10 text-primary mx-auto mb-2" />
            <CardTitle>{t.multiTitle}</CardTitle>
            <CardDescription>{t.multiDesc}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {doctorClinics.map(clinic => (
              <button
                key={clinic.id}
                onClick={() => { selectClinicForDoctor(clinic.id); navigate('/dashboard'); }}
                className="w-full flex items-center gap-3 p-4 rounded-lg border border-border hover:border-primary hover:bg-primary/5 transition-all text-start"
                data-testid={`clinic-select-${clinic.id}`}
              >
                <Building2 className="h-5 w-5 text-primary shrink-0" />
                <div className="min-w-0 flex-1">
                  <div className="font-medium text-foreground truncate">
                    {isAr ? (clinic.nameAr || clinic.name) : clinic.name}
                  </div>
                  <div className="text-sm text-muted-foreground truncate">
                    {isAr ? (clinic.cityAr || clinic.city) : clinic.city}
                  </div>
                </div>
                <ChevronRight className={`h-4 w-4 text-muted-foreground shrink-0 ${isRTL ? 'rotate-180' : ''}`} />
              </button>
            ))}
          </CardContent>
        </Card>
      </div>
    );
  }

  // ── Handlers ──────────────────────────────────────────────────────────────
  const handlePatientLogin = async (email: string, password: string) => {
    setPatientError('');
    if (!email.trim() || !password) { setPatientError(t.errEmpty); return; }
    setPatientLoading(true);
    await new Promise(r => setTimeout(r, 300));
    const result = loginPatient(email, password);
    setPatientLoading(false);
    if (result.ok) {
      if (returnDoctor) navigate(`/patient/book?doctor=${returnDoctor}`);
      else navigate('/patient/appointments');
    } else {
      setPatientError(result.error || (isAr ? 'بيانات غير صحيحة.' : 'Invalid credentials.'));
    }
  };

  const handleStaffLogin = async (email: string, password: string) => {
    setStaffError('');
    if (!email.trim() || !password) { setStaffError(t.errEmpty); return; }
    setStaffLoading(true);
    await new Promise(r => setTimeout(r, 300));
    const result = loginStaff(email, password);
    setStaffLoading(false);
    if (result.ok) {
      navigate('/dashboard');
    } else {
      setStaffError(result.error || (isAr ? 'بيانات غير صحيحة.' : 'Invalid credentials.'));
    }
  };

  const TABS = [
    { key: 'patient' as Tab, label: t.tabPatient, icon: <User className="h-4 w-4" /> },
    { key: 'staff'   as Tab, label: t.tabStaff,   icon: <Building2 className="h-4 w-4" /> },
  ];

  return (
    <div
      className="min-h-screen bg-gradient-to-br from-blue-50 via-background to-blue-50/30 flex flex-col"
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      {/* Header */}
      <header className="border-b border-border bg-card/80 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-3 hover:opacity-80 transition-opacity">
            <img src={logoImg} alt="ClinicFlow" className="h-9 w-9 rounded-lg object-cover" />
            <span className="font-semibold text-foreground hidden sm:inline">ClinicFlow</span>
          </Link>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={() => setLanguage(isAr ? 'en' : 'ar')}>
              {isAr ? 'EN' : 'AR'}
            </Button>
            <Button variant="outline" size="sm" asChild>
              <Link to="/register" className="gap-1.5 flex items-center" data-testid="button-header-register">
                <UserPlus className="h-4 w-4" />
                {t.registerNow}
              </Link>
            </Button>
            <Button variant="ghost" size="sm" asChild>
              <Link to="/" className="gap-2 flex items-center">
                <ArrowLeft className={`h-4 w-4 ${isRTL ? 'rotate-180' : ''}`} />
                {t.backHome}
              </Link>
            </Button>
          </div>
        </div>
      </header>

      <main className="flex-1 flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          <div className="text-center mb-6">
            <h1 className="text-2xl font-bold text-foreground">{t.welcomeBack}</h1>
            <p className="text-muted-foreground mt-1">{t.subtitle}</p>
          </div>

          {/* Tabs */}
          <div className="flex rounded-lg bg-muted p-1 mb-6 gap-1">
            {TABS.map(tb => (
              <button
                key={tb.key}
                onClick={() => setTab(tb.key)}
                className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-md text-sm font-medium transition-all ${
                  tab === tb.key
                    ? 'bg-background text-foreground shadow-sm'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
                data-testid={`tab-${tb.key}`}
              >
                {tb.icon}
                <span>{tb.label}</span>
              </button>
            ))}
          </div>

          {/* ── PATIENT TAB ── */}
          {tab === 'patient' && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="h-5 w-5 text-blue-600" />
                  {t.patientTitle}
                </CardTitle>
                <CardDescription>{t.patientDesc}</CardDescription>
              </CardHeader>
              <CardContent>
                <CredForm
                  emailLabel={t.emailLabel}
                  emailPh={t.emailPh}
                  passLabel={t.passLabel}
                  passPh={t.passPh}
                  submitLabel={t.signIn}
                  loading={patientLoading}
                  error={patientError}
                  onSubmit={handlePatientLogin}
                  isRTL={isRTL}
                >
                  <Separator />
                  <div className="space-y-2 text-center">
                    <p className="text-sm text-muted-foreground">{t.noAccount}</p>
                    <Button variant="outline" className="w-full gap-2" asChild>
                      <Link to="/register?type=patient" data-testid="button-create-account">
                        <UserPlus className="h-4 w-4" />
                        {t.createAccount}
                      </Link>
                    </Button>
                  </div>
                </CredForm>
              </CardContent>
            </Card>
          )}

          {/* ── CLINIC STAFF TAB ── */}
          {tab === 'staff' && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Building2 className="h-5 w-5 text-emerald-600" />
                  {t.staffTitle}
                </CardTitle>
                <CardDescription>{t.staffDesc}</CardDescription>
              </CardHeader>
              <CardContent>
                <CredForm
                  emailLabel={t.staffEmailLabel}
                  emailPh={t.staffEmailPh}
                  passLabel={t.passLabel}
                  passPh={t.passPh}
                  submitLabel={t.staffSignIn}
                  loading={staffLoading}
                  error={staffError}
                  onSubmit={handleStaffLogin}
                  isRTL={isRTL}
                >
                  <p className="text-center text-xs text-muted-foreground">{t.forgotPass}</p>
                  <Separator />
                  <p className="text-center text-xs text-muted-foreground">
                    {t.registerClinic}{' '}
                    <Link to="/register?type=clinic" className="text-primary hover:underline font-medium" data-testid="link-register-clinic">
                      {t.registerClinicLink}
                    </Link>
                  </p>
                </CredForm>
              </CardContent>
            </Card>
          )}

          <p className="text-center text-xs text-muted-foreground mt-6">
            {t.terms}{' '}
            <span className="text-primary cursor-pointer hover:underline">{t.termsLink}</span>
            {' '}{t.and}{' '}
            <span className="text-primary cursor-pointer hover:underline">{t.privacyLink}</span>
          </p>
        </div>
      </main>
    </div>
  );
};

export default Login;
