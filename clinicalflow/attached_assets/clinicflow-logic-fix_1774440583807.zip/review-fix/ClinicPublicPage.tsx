import React, { useState, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { clinicStore } from '@/stores/clinicStore';
import { userStore } from '@/stores/userStore';
import { specialtyStore } from '@/stores/specialtyStore';
import { getDoctorProfile } from '@/stores/doctorProfileStore';
import { getAverageRating, getRatingsForTarget, addRating, hasPatientRated } from '@/stores/ratingStore';
import { getAvailableSlots } from '@/stores/scheduleStore';
import { getActiveOffersByClinic } from '@/stores/offerStore';
import { OFFER_TYPE_LABELS } from '@/stores/offerStore';
import { Clinic } from '@/types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import {
  Building2, MapPin, Phone, Clock, Globe, Star, User, Calendar, ChevronRight,
  Edit, ArrowLeft, Stethoscope, ExternalLink, Navigation, QrCode, Copy, Linkedin,
  Tag, Percent, CalendarDays,
} from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';
import { SiFacebook, SiInstagram, SiYoutube, SiTiktok, SiX } from 'react-icons/si';
import BookingWizard from '@/components/BookingWizard';

const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

function getNextSlotsForClinic(doctorIds: string[], maxPerDoctor = 2, maxTotal = 8): { doctorId: string; date: string; time: string; label: string }[] {
  const result: { doctorId: string; date: string; time: string; label: string }[] = [];
  const today = new Date();
  for (const doctorId of doctorIds) {
    let found = 0;
    for (let i = 0; i < 7 && found < maxPerDoctor; i++) {
      const d = new Date(today);
      d.setDate(today.getDate() + i);
      const dateStr = d.toISOString().split('T')[0];
      const slots = getAvailableSlots(doctorId, dateStr);
      for (const slot of slots) {
        if (found >= maxPerDoctor) break;
        let label = i === 0 ? 'Today' : i === 1 ? 'Tomorrow' : DAYS[d.getDay()];
        result.push({ doctorId, date: dateStr, time: slot, label });
        found++;
      }
    }
  }
  result.sort((a, b) => {
    const da = a.date + 'T' + a.time;
    const db = b.date + 'T' + b.time;
    return da < db ? -1 : da > db ? 1 : 0;
  });
  return result.slice(0, maxTotal);
}

function StarRating({ value, onChange, readOnly = false }: { value: number; onChange?: (v: number) => void; readOnly?: boolean }) {
  const [hover, setHover] = useState(0);
  return (
    <div className="flex gap-0.5">
      {[1, 2, 3, 4, 5].map(s => (
        <button key={s} type="button" disabled={readOnly} className={readOnly ? 'cursor-default' : 'cursor-pointer'}
          onClick={() => !readOnly && onChange?.(s)} onMouseEnter={() => !readOnly && setHover(s)} onMouseLeave={() => !readOnly && setHover(0)}>
          <Star className={`h-4 w-4 ${(hover || value) >= s ? 'fill-yellow-400 text-yellow-400' : 'text-muted-foreground'}`} />
        </button>
      ))}
    </div>
  );
}

export default function ClinicPublicPage() {
  const { clinicId } = useParams<{ clinicId: string }>();
  const { language, setLanguage, isRTL } = useLanguage();
  const { user } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const isAr = language === 'ar';

  const clinic = useMemo(() => clinicId ? clinicStore.get(c => c.id === clinicId) : undefined, [clinicId]);
  const doctors = useMemo(() => clinicId ? userStore.filter(u => u.clinicId === clinicId && u.role === 'doctor' && u.isActive) : [], [clinicId]);

  const slots = useMemo(() => getNextSlotsForClinic(doctors.map(d => d.id)), [doctors]);
  const clinicOffers = useMemo(() => clinicId ? getActiveOffersByClinic(clinicId) : [], [clinicId]);
  const { avg: clinicRating, count: ratingCount } = getAverageRating(clinicId || '', 'clinic');
  const reviews = getRatingsForTarget(clinicId || '', 'clinic');

  const canEdit = user && user.role === 'admin' && user.clinicId === clinicId;
  const [editOpen, setEditOpen] = useState(false);
  const [editData, setEditData] = useState<Partial<Clinic>>({});
  const [qrOpen, setQrOpen] = useState(false);
  const [bookingOpen, setBookingOpen] = useState(false);
  const [bookingDoctorId, setBookingDoctorId] = useState<string | undefined>(undefined);
  const clinicUrl = `${window.location.origin}/clinic/${clinicId}`;

  const [ratingOpen, setRatingOpen] = useState(false);
  const [newStars, setNewStars] = useState(5);
  const [newComment, setNewComment] = useState('');
  const patientAlreadyRated = user?.role === 'patient' && clinicId ? hasPatientRated(user.id, clinicId, 'clinic') : false;

  if (!clinic) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4">
          <Building2 className="h-12 w-12 text-muted-foreground mx-auto" />
          <p className="text-muted-foreground">{isAr ? 'العيادة غير موجودة' : 'Clinic not found'}</p>
          <Button variant="outline" onClick={() => navigate(-1)}><ArrowLeft className="h-4 w-4 mr-2" />{isAr ? 'رجوع' : 'Go Back'}</Button>
        </div>
      </div>
    );
  }

  const handleSaveEdit = () => {
    clinicStore.update(c => c.id === clinicId, editData);
    setEditOpen(false);
    toast({ title: isAr ? 'تم تحديث بيانات العيادة' : 'Clinic profile updated' });
  };

  const openEdit = () => {
    setEditData({
      description: clinic.description, descriptionAr: clinic.descriptionAr,
      workingHours: clinic.workingHours, workingHoursAr: clinic.workingHoursAr,
      latitude: clinic.latitude, longitude: clinic.longitude, website: clinic.website,
      socialLinks: clinic.socialLinks,
    });
    setEditOpen(true);
  };

  const handleSubmitRating = () => {
    if (!user?.id || !clinicId) return;
    addRating({ targetId: clinicId, targetType: 'clinic', patientId: user.id, stars: newStars, comment: newComment });
    setRatingOpen(false);
    setNewComment('');
    toast({ title: isAr ? 'شكرًا على تقييمك' : 'Thank you for your review!' });
  };

  const mapsUrl = clinic.latitude && clinic.longitude
    ? `https://www.google.com/maps?q=${clinic.latitude},${clinic.longitude}&z=15`
    : `https://www.google.com/maps/search/${encodeURIComponent((isAr ? clinic.addressAr : clinic.address) + ', ' + (isAr ? clinic.cityAr : clinic.city))}`;

  const embedUrl = clinic.latitude && clinic.longitude
    ? `https://maps.google.com/maps?q=${clinic.latitude},${clinic.longitude}&z=15&output=embed`
    : null;

  return (
    <div className="min-h-screen bg-background" dir={isRTL ? 'rtl' : 'ltr'}>
      <div className="max-w-5xl mx-auto px-4 py-6 space-y-6">

        <div className="flex items-center justify-between">
          <Button variant="ghost" size="sm" onClick={() => navigate(-1)} className="gap-2 text-muted-foreground hover:text-foreground">
            <ArrowLeft className={`h-4 w-4 ${isRTL ? 'rotate-180' : ''}`} />
            {isAr ? 'رجوع' : 'Back'}
          </Button>
          <Button variant="outline" size="sm" onClick={() => setLanguage(language === 'en' ? 'ar' : 'en')} data-testid="button-toggle-language">
            {language === 'en' ? 'AR' : 'EN'}
          </Button>
        </div>

        <div className="relative rounded-2xl overflow-hidden border border-border bg-gradient-to-r from-primary/20 via-primary/10 to-background h-40 sm:h-56 flex items-end">
          <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent" />
          <div className="relative p-6 flex items-end justify-between w-full">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <h1 className="text-2xl sm:text-3xl font-bold">{isAr ? clinic.nameAr : clinic.name}</h1>
                {clinicRating > 0 && (
                  <div className="flex items-center gap-1 bg-background/80 rounded-full px-2 py-0.5">
                    <Star className="h-3.5 w-3.5 fill-yellow-400 text-yellow-400" />
                    <span className="text-sm font-semibold">{clinicRating}</span>
                    <span className="text-xs text-muted-foreground">({ratingCount})</span>
                  </div>
                )}
              </div>
              <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                <MapPin className="h-3.5 w-3.5" />
                {isAr ? clinic.addressAr : clinic.address}
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button size="sm" variant="outline" onClick={() => setQrOpen(true)} className="gap-2 bg-background/80" data-testid="btn-clinic-qr">
                <QrCode className="h-4 w-4" />{isAr ? 'QR' : 'QR'}
              </Button>
              {canEdit && (
                <Button size="sm" variant="outline" onClick={openEdit} className="gap-2 bg-background/80" data-testid="btn-edit-clinic">
                  <Edit className="h-4 w-4" />{isAr ? 'تعديل' : 'Edit'}
                </Button>
              )}
            </div>
          </div>
        </div>

        {clinic.socialLinks && Object.values(clinic.socialLinks).some(Boolean) && (
          <div className="flex flex-wrap items-center gap-3 px-1">
            {clinic.socialLinks.facebook && (
              <a href={clinic.socialLinks.facebook} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:text-blue-700 transition-colors" title="Facebook" data-testid="clinic-social-facebook"><SiFacebook className="h-5 w-5" /></a>
            )}
            {clinic.socialLinks.instagram && (
              <a href={clinic.socialLinks.instagram} target="_blank" rel="noopener noreferrer" className="text-pink-500 hover:text-pink-600 transition-colors" title="Instagram" data-testid="clinic-social-instagram"><SiInstagram className="h-5 w-5" /></a>
            )}
            {clinic.socialLinks.linkedin && (
              <a href={clinic.socialLinks.linkedin} target="_blank" rel="noopener noreferrer" className="text-blue-700 hover:text-blue-800 transition-colors" title="LinkedIn" data-testid="clinic-social-linkedin"><Linkedin className="h-5 w-5" /></a>
            )}
            {clinic.socialLinks.youtube && (
              <a href={clinic.socialLinks.youtube} target="_blank" rel="noopener noreferrer" className="text-red-600 hover:text-red-700 transition-colors" title="YouTube" data-testid="clinic-social-youtube"><SiYoutube className="h-5 w-5" /></a>
            )}
            {clinic.socialLinks.tiktok && (
              <a href={clinic.socialLinks.tiktok} target="_blank" rel="noopener noreferrer" className="text-foreground hover:text-muted-foreground transition-colors" title="TikTok" data-testid="clinic-social-tiktok"><SiTiktok className="h-5 w-5" /></a>
            )}
            {clinic.socialLinks.twitter && (
              <a href={clinic.socialLinks.twitter} target="_blank" rel="noopener noreferrer" className="text-foreground hover:text-muted-foreground transition-colors" title="X / Twitter" data-testid="clinic-social-twitter"><SiX className="h-5 w-5" /></a>
            )}
            {clinic.socialLinks.website && (
              <a href={clinic.socialLinks.website} target="_blank" rel="noopener noreferrer" className="text-primary hover:text-primary/80 transition-colors" title="Website" data-testid="clinic-social-website"><Globe className="h-5 w-5" /></a>
            )}
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card>
            <CardContent className="pt-4 pb-4 flex items-center gap-3">
              <Phone className="h-5 w-5 text-primary shrink-0" />
              <div>
                <p className="text-xs text-muted-foreground">{isAr ? 'الهاتف' : 'Phone'}</p>
                <p className="font-medium text-sm">{clinic.phone}</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-4 pb-4 flex items-center gap-3">
              <MapPin className="h-5 w-5 text-primary shrink-0" />
              <div>
                <p className="text-xs text-muted-foreground">{isAr ? 'المدينة' : 'City'}</p>
                <p className="font-medium text-sm">{isAr ? clinic.cityAr : clinic.city}</p>
              </div>
            </CardContent>
          </Card>
          {clinic.workingHours && (
            <Card>
              <CardContent className="pt-4 pb-4 flex items-center gap-3">
                <Clock className="h-5 w-5 text-primary shrink-0" />
                <div>
                  <p className="text-xs text-muted-foreground">{isAr ? 'ساعات العمل' : 'Working Hours'}</p>
                  <p className="font-medium text-xs leading-relaxed">{isAr ? clinic.workingHoursAr || clinic.workingHours : clinic.workingHours}</p>
                </div>
              </CardContent>
            </Card>
          )}
          {clinic.website && (
            <Card>
              <CardContent className="pt-4 pb-4 flex items-center gap-3">
                <Globe className="h-5 w-5 text-primary shrink-0" />
                <div>
                  <p className="text-xs text-muted-foreground">{isAr ? 'الموقع الإلكتروني' : 'Website'}</p>
                  <a href={clinic.website} target="_blank" rel="noopener noreferrer" className="text-primary text-sm hover:underline flex items-center gap-1">
                    {isAr ? 'زيارة الموقع' : 'Visit Site'}<ExternalLink className="h-3 w-3" />
                  </a>
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {(clinic.description || clinic.descriptionAr) && (
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base">{isAr ? 'عن العيادة' : 'About the Clinic'}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground leading-relaxed">{isAr ? clinic.descriptionAr || clinic.description : clinic.description}</p>
            </CardContent>
          </Card>
        )}

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Stethoscope className="h-5 w-5 text-primary" />
              {isAr ? 'الأطباء' : 'Our Doctors'}
              <Badge variant="secondary">{doctors.length}</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {doctors.map(doc => {
                const spec = doc.specialtyId ? specialtyStore.get(s => s.id === doc.specialtyId) : undefined;
                const profile = getDoctorProfile(doc.id);
                const { avg: dr, count: dc } = getAverageRating(doc.id, 'doctor');
                return (
                  <div key={doc.id} className="flex items-center gap-3 p-3 rounded-xl border border-border hover:border-primary/50 transition-all">
                    <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                      {profile?.photoUrl ? (
                        <img src={profile.photoUrl} alt={doc.name} className="h-full w-full rounded-xl object-cover" />
                      ) : (
                        <User className="h-6 w-6 text-primary" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-sm truncate">{isAr ? doc.nameAr : doc.name}</p>
                      <p className="text-xs text-muted-foreground">{isAr ? spec?.nameAr || spec?.name : spec?.name}</p>
                      {dr > 0 && (
                        <div className="flex items-center gap-1 mt-0.5">
                          <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                          <span className="text-xs font-medium">{dr}</span>
                          <span className="text-xs text-muted-foreground">({dc})</span>
                        </div>
                      )}
                    </div>
                    <div className="flex gap-1.5 shrink-0">
                      <Button size="sm" variant="outline" className="text-xs h-7" onClick={() => navigate(`/doctor/${doc.id}`)} data-testid={`btn-view-doctor-${doc.id}`}>
                        {isAr ? 'الملف' : 'Profile'}
                      </Button>
                      <Button size="sm" className="text-xs h-7" onClick={() => {
                        if (!isAuthenticated) { navigate('/login'); return; }
                        setBookingDoctorId(doc.id);
                        setBookingOpen(true);
                      }} data-testid={`btn-book-doctor-${doc.id}`}>
                        {isAr ? 'احجز' : 'Book'}
                      </Button>
                    </div>
                  </div>
                );
              })}
              {doctors.length === 0 && (
                <div className="col-span-2 text-center py-8 text-muted-foreground">
                  <Stethoscope className="h-8 w-8 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">{isAr ? 'لا يوجد أطباء بعد' : 'No doctors yet'}</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {slots.length > 0 && (
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <Calendar className="h-5 w-5 text-primary" />
                {isAr ? 'أقرب المواعيد المتاحة' : 'Nearest Available Appointments'}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {slots.map((slot, i) => {
                  const doc = doctors.find(d => d.id === slot.doctorId);
                  const spec = doc?.specialtyId ? specialtyStore.get(s => s.id === doc.specialtyId) : undefined;
                  return (
                    <div key={i} className="flex items-center justify-between p-3 rounded-xl border border-border hover:border-primary/50 transition-all" data-testid={`slot-row-${i}`}>
                      <div className="flex items-center gap-3">
                        <div className="text-center w-16">
                          <p className="text-xs text-muted-foreground">{slot.label}</p>
                          <p className="font-semibold">{slot.time}</p>
                        </div>
                        <div>
                          <p className="font-medium text-sm">{isAr ? doc?.nameAr : doc?.name}</p>
                          <p className="text-xs text-muted-foreground">{isAr ? spec?.nameAr || spec?.name : spec?.name}</p>
                        </div>
                      </div>
                      <Button size="sm" className="text-xs h-7" onClick={() => {
                        if (!isAuthenticated) { navigate('/login'); return; }
                        setBookingDoctorId(slot.doctorId);
                        setBookingOpen(true);
                      }} data-testid={`btn-book-slot-${i}`}>
                        {isAr ? 'احجز' : 'Book Now'}
                      </Button>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Medical Offers Section */}
        {clinicOffers.length > 0 && (
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <Tag className="h-5 w-5 text-primary" />
                {isAr ? 'العروض والخصومات' : 'Offers & Discounts'}
                <Badge variant="secondary" className="ml-auto text-xs">{clinicOffers.length}</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {clinicOffers.map(offer => {
                  const days = Math.max(0, Math.ceil((new Date(offer.expiresAt).getTime() - Date.now()) / 86400000));
                  return (
                    <div key={offer.id} className="border border-border/60 rounded-xl p-4 space-y-2 hover:border-primary/40 transition-colors" data-testid={`offer-card-${offer.id}`}>
                      <div className="flex items-start justify-between gap-2">
                        <p className="font-semibold text-sm leading-snug">{isAr ? offer.titleAr : offer.title}</p>
                        <Badge className="shrink-0 text-xs px-2 bg-primary/10 text-primary border-primary/20">
                          {OFFER_TYPE_LABELS[offer.offerType]?.[isAr ? 'ar' : 'en']}
                        </Badge>
                      </div>
                      <p className="text-xs text-muted-foreground line-clamp-2">{isAr ? offer.descriptionAr : offer.description}</p>
                      {(offer.originalPrice || offer.discountedPrice) && (
                        <div className="flex items-center gap-2">
                          {offer.originalPrice && (
                            <span className="text-sm text-muted-foreground line-through">{offer.originalPrice} ج.م</span>
                          )}
                          {offer.discountedPrice && (
                            <span className="text-base font-bold text-primary">{offer.discountedPrice} ج.م</span>
                          )}
                          {offer.discountPercent && (
                            <Badge variant="outline" className="text-xs text-green-600 border-green-300 gap-0.5">
                              <Percent className="h-3 w-3" />{offer.discountPercent}%
                            </Badge>
                          )}
                        </div>
                      )}
                      <div className="flex items-center justify-between">
                        <span className={`text-xs flex items-center gap-1 ${days <= 3 ? 'text-orange-500' : 'text-muted-foreground'}`}>
                          <CalendarDays className="h-3 w-3" />
                          {days === 0
                            ? (isAr ? 'ينتهي اليوم' : 'Expires today')
                            : `${days} ${isAr ? 'يوم متبقي' : 'days left'}`}
                        </span>
                        {offer.doctorName && (
                          <span className="text-xs text-muted-foreground">{offer.doctorName}</span>
                        )}
                      </div>
                      <Button
                        size="sm"
                        className="w-full h-7 text-xs mt-1"
                        onClick={() => {
                          if (!isAuthenticated) { navigate('/login'); return; }
                          setBookingDoctorId(offer.doctorId || doctors[0]?.id);
                          setBookingOpen(true);
                        }}
                        data-testid={`btn-book-offer-${offer.id}`}
                      >
                        {isAr ? 'احجز الآن' : 'Book Now'}
                      </Button>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base flex items-center gap-2">
                  <Star className="h-5 w-5 text-primary" />
                  {isAr ? 'تقييمات المرضى' : 'Patient Reviews'}
                </CardTitle>
                {user?.role === 'patient' && !patientAlreadyRated && (
                  <Button size="sm" variant="outline" className="text-xs h-7 gap-1" onClick={() => setRatingOpen(true)} data-testid="btn-rate-clinic">
                    <Star className="h-3 w-3" />{isAr ? 'قيّم' : 'Rate'}
                  </Button>
                )}
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              {clinicRating > 0 && (
                <div className="flex items-center gap-4 p-3 bg-muted/40 rounded-xl">
                  <span className="text-3xl font-bold">{clinicRating}</span>
                  <div>
                    <StarRating value={Math.round(clinicRating)} readOnly />
                    <p className="text-xs text-muted-foreground mt-0.5">{ratingCount} {isAr ? 'تقييم' : 'reviews'}</p>
                  </div>
                </div>
              )}
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {reviews.map(r => (
                  <div key={r.id} className="p-3 border rounded-xl">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="h-7 w-7 rounded-full bg-muted flex items-center justify-center"><User className="h-3.5 w-3.5 text-muted-foreground" /></div>
                        <StarRating value={r.stars} readOnly />
                      </div>
                      <span className="text-xs text-muted-foreground">{new Date(r.createdAt).toLocaleDateString()}</span>
                    </div>
                    {r.comment && <p className="text-xs text-muted-foreground mt-2">{r.comment}</p>}
                  </div>
                ))}
                {reviews.length === 0 && (
                  <div className="text-center py-6 text-muted-foreground">
                    <Star className="h-6 w-6 mx-auto mb-1 opacity-50" />
                    <p className="text-sm">{isAr ? 'لا توجد تقييمات بعد' : 'No reviews yet'}</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <Navigation className="h-5 w-5 text-primary" />
                {isAr ? 'موقع العيادة' : 'Clinic Location'}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <p className="text-sm text-muted-foreground">{isAr ? clinic.addressAr : clinic.address}, {isAr ? clinic.cityAr : clinic.city}</p>
              {embedUrl ? (
                <div className="rounded-xl overflow-hidden border border-border h-48">
                  <iframe
                    src={embedUrl}
                    width="100%"
                    height="100%"
                    style={{ border: 0 }}
                    loading="lazy"
                    referrerPolicy="no-referrer-when-downgrade"
                    title={isAr ? 'موقع العيادة' : 'Clinic Location'}
                  />
                </div>
              ) : (
                <div className="h-48 bg-muted/40 rounded-xl flex items-center justify-center border border-border border-dashed">
                  <div className="text-center text-muted-foreground">
                    <MapPin className="h-8 w-8 mx-auto mb-2 opacity-50" />
                    <p className="text-sm">{isAr ? 'الموقع غير محدد بدقة' : 'Precise coordinates not set'}</p>
                  </div>
                </div>
              )}
              <Button variant="outline" className="w-full gap-2" onClick={() => window.open(mapsUrl, '_blank')} data-testid="btn-get-directions">
                <Navigation className="h-4 w-4" />
                {isAr ? 'احصل على الاتجاهات' : 'Get Directions'}
                <ExternalLink className="h-3.5 w-3.5 text-muted-foreground" />
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>

      <Dialog open={ratingOpen} onOpenChange={setRatingOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>{isAr ? 'تقييم العيادة' : 'Rate the Clinic'}</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="flex justify-center"><StarRating value={newStars} onChange={setNewStars} /></div>
            <div className="space-y-2">
              <Label>{isAr ? 'تعليق (اختياري)' : 'Comment (optional)'}</Label>
              <Textarea value={newComment} onChange={e => setNewComment(e.target.value)} rows={3} data-testid="input-clinic-review" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setRatingOpen(false)}>{isAr ? 'إلغاء' : 'Cancel'}</Button>
            <Button onClick={handleSubmitRating} data-testid="btn-submit-clinic-review">{isAr ? 'إرسال' : 'Submit'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={qrOpen} onOpenChange={setQrOpen}>
        <DialogContent className="max-w-xs text-center">
          <DialogHeader>
            <DialogTitle className="flex items-center justify-center gap-2">
              <QrCode className="h-5 w-5" />
              {isAr ? 'مسح رمز QR لمشاركة العيادة' : 'Scan QR to Share Clinic'}
            </DialogTitle>
          </DialogHeader>
          <div className="flex flex-col items-center gap-4 py-2">
            <div className="p-3 bg-white rounded-xl border border-border shadow-sm">
              <QRCodeSVG value={clinicUrl} size={200} />
            </div>
            <p className="text-xs text-muted-foreground break-all px-2">{clinicUrl}</p>
            <Button
              variant="outline"
              size="sm"
              className="gap-2 w-full"
              onClick={() => { navigator.clipboard.writeText(clinicUrl); toast({ title: isAr ? 'تم نسخ الرابط' : 'Link copied!' }); }}
              data-testid="btn-copy-clinic-link"
            >
              <Copy className="h-4 w-4" />
              {isAr ? 'نسخ الرابط' : 'Copy Link'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={editOpen} onOpenChange={setEditOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle className="flex items-center gap-2"><Edit className="h-5 w-5" />{isAr ? 'تعديل ملف العيادة' : 'Edit Clinic Profile'}</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="space-y-1">
              <Label>{isAr ? 'الوصف (إنجليزي)' : 'Description (English)'}</Label>
              <Textarea value={editData.description || ''} onChange={e => setEditData(p => ({ ...p, description: e.target.value }))} rows={3} />
            </div>
            <div className="space-y-1">
              <Label>{isAr ? 'الوصف (عربي)' : 'Description (Arabic)'}</Label>
              <Textarea value={editData.descriptionAr || ''} onChange={e => setEditData(p => ({ ...p, descriptionAr: e.target.value }))} rows={3} dir="rtl" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label>{isAr ? 'ساعات العمل (إنجليزي)' : 'Working Hours (EN)'}</Label>
                <Input value={editData.workingHours || ''} onChange={e => setEditData(p => ({ ...p, workingHours: e.target.value }))} />
              </div>
              <div className="space-y-1">
                <Label>{isAr ? 'ساعات العمل (عربي)' : 'Working Hours (AR)'}</Label>
                <Input value={editData.workingHoursAr || ''} onChange={e => setEditData(p => ({ ...p, workingHoursAr: e.target.value }))} dir="rtl" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label>{isAr ? 'خط العرض' : 'Latitude'}</Label>
                <Input type="number" step="0.0001" value={editData.latitude || ''} onChange={e => setEditData(p => ({ ...p, latitude: Number(e.target.value) || undefined }))} placeholder="30.0444" />
              </div>
              <div className="space-y-1">
                <Label>{isAr ? 'خط الطول' : 'Longitude'}</Label>
                <Input type="number" step="0.0001" value={editData.longitude || ''} onChange={e => setEditData(p => ({ ...p, longitude: Number(e.target.value) || undefined }))} placeholder="31.2357" />
              </div>
            </div>
            <div className="space-y-1">
              <Label>{isAr ? 'الموقع الإلكتروني' : 'Website URL'}</Label>
              <Input value={editData.website || ''} onChange={e => setEditData(p => ({ ...p, website: e.target.value }))} placeholder="https://..." />
            </div>
            <Separator />
            <p className="text-sm font-semibold text-muted-foreground uppercase tracking-wide">{isAr ? 'روابط التواصل الاجتماعي' : 'Social Media Links'}</p>
            {[
              { key: 'facebook', label: 'Facebook', placeholder: 'https://facebook.com/...' },
              { key: 'instagram', label: 'Instagram', placeholder: 'https://instagram.com/...' },
              { key: 'linkedin', label: 'LinkedIn', placeholder: 'https://linkedin.com/...' },
              { key: 'youtube', label: 'YouTube', placeholder: 'https://youtube.com/@...' },
              { key: 'tiktok', label: 'TikTok', placeholder: 'https://tiktok.com/@...' },
              { key: 'twitter', label: 'X / Twitter', placeholder: 'https://x.com/...' },
              { key: 'website', label: isAr ? 'موقع' : 'Website', placeholder: 'https://...' },
            ].map(({ key, label, placeholder }) => (
              <div key={key} className="flex items-center gap-2">
                <Label className="w-24 shrink-0 text-xs">{label}</Label>
                <Input
                  value={(editData.socialLinks as Record<string, string> | undefined)?.[key] || ''}
                  onChange={e => setEditData(p => ({ ...p, socialLinks: { ...p.socialLinks, [key]: e.target.value || undefined } }))}
                  placeholder={placeholder}
                  className="text-xs"
                />
              </div>
            ))}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditOpen(false)}>{isAr ? 'إلغاء' : 'Cancel'}</Button>
            <Button onClick={handleSaveEdit} data-testid="btn-save-clinic-profile">{isAr ? 'حفظ' : 'Save'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ─── Doctor Booking Wizard ──────────────────────────────────────── */}
      <Dialog open={bookingOpen} onOpenChange={setBookingOpen}>
        <DialogContent className="max-w-2xl p-0 overflow-hidden">
          <DialogHeader className="px-6 pt-5 pb-0">
            <DialogTitle>{isAr ? 'حجز موعد' : 'Book Appointment'}</DialogTitle>
          </DialogHeader>
          {bookingOpen && (
            <BookingWizard
              patientId={user?.patientId || user?.id}
              initialDoctorId={bookingDoctorId}
              initialClinicId={clinicId}
              onComplete={() => setBookingOpen(false)}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
