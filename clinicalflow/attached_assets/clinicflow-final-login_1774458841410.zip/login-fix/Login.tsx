import React, { useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { UserRole } from '@/types';
import { clinicStore } from '@/stores/clinicStore';
import { userStore } from '@/stores/userStore';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import {
  Shield, Stethoscope, ClipboardList, User, ArrowLeft,
  Building2, ChevronRight, Smartphone, Lock, Eye, EyeOff, UserPlus,
} from 'lucide-react';
import logoImg from '@assets/Untitled_design_1772868317886.png';

type Tab = 'patient' | 'staff';

const T = {
  ar: {
    backHome: 'العودة للرئيسية', registerNow: 'سجل الآن',
    welcomeBack: 'مرحباً بعودتك', subtitle: 'سجّل دخولك إلى حسابك في ClinicFlow',
    tabPatient: 'مريض', tabStaff: 'موظفو العيادة',
    patientTitle: 'دخول المرضى', patientDesc: 'أدخل رقم هاتفك وكلمة المرور',
    phoneLabel: 'رقم الهاتف', phonePh: '01xxxxxxxxx',
    passLabel: 'كلمة المرور', passPh: '••••••••',
    signIn: 'تسجيل الدخول',
    noAccount: 'ليس لديك حساب؟', createAccount: 'إنشاء حساب مريض',
    errEmpty: 'أدخل رقم الهاتف وكلمة المرور.',
    errNotFound: 'لم يتم العثور على حساب. تحقق من البيانات أو سجّل أولاً.',
    selectClinic: 'اختر عيادتك', selectClinicDesc: 'اختر العيادة التي تعمل فيها',
    loginTo: 'دخول إلى', selectRoleDesc: 'اختر دورك للمتابعة',
    roleAdmin: 'مدير', roleAdminDesc: 'صلاحيات كاملة للنظام',
    roleDoctor: 'طبيب', roleDoctorDesc: 'رعاية المرضى والاستشارات',
    roleReception: 'موظف استقبال', roleReceptionDesc: 'عمليات الاستقبال',
    registerClinic: 'تريد تسجيل عيادتك؟', registerClinicLink: 'سجّل هنا',
    multiTitle: 'اختر عيادتك', multiDesc: 'أنت مسجّل في أكثر من عيادة.',
    terms: 'بتسجيل دخولك فأنت توافق على', termsLink: 'شروط الخدمة',
    and: 'و', privacyLink: 'سياسة الخصوصية',
  },
  en: {
    backHome: 'Back to Home', registerNow: 'Sign Up',
    welcomeBack: 'Welcome back', subtitle: 'Sign in to your ClinicFlow account',
    tabPatient: 'Patient', tabStaff: 'Clinic Staff',
    patientTitle: 'Patient Login', patientDesc: 'Enter your phone number and password',
    phoneLabel: 'Phone Number', phonePh: '01xxxxxxxxx',
    passLabel: 'Password', passPh: '••••••••',
    signIn: 'Sign In',
    noAccount: "Don't have an account?", createAccount: 'Create a Patient Account',
    errEmpty: 'Please enter your phone and password.',
    errNotFound: 'No account found. Check your details or register first.',
    selectClinic: 'Select Your Clinic', selectClinicDesc: 'Choose the clinic you work in',
    loginTo: 'Login to', selectRoleDesc: 'Select your role to continue',
    roleAdmin: 'Admin', roleAdminDesc: 'Full system access',
    roleDoctor: 'Doctor', roleDoctorDesc: 'Patient care & consultations',
    roleReception: 'Receptionist', roleReceptionDesc: 'Front desk operations',
    registerClinic: 'Want to register your clinic?', registerClinicLink: 'Register here',
    multiTitle: 'Select Your Clinic', multiDesc: 'You are registered in multiple clinics.',
    terms: 'By signing in you agree to our', termsLink: 'Terms of Service',
    and: 'and', privacyLink: 'Privacy Policy',
  },
} as const;

const Login: React.FC = () => {
  const { login, loginAsSuperAdmin, loginAsPatient, pendingDoctorClinics, selectClinicForDoctor } = useAuth();
  const { language, setLanguage, isRTL } = useLanguage();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const returnDoctor = searchParams.get('returnDoctor');

  const t = T[language as 'ar' | 'en'];
  const isAr = language === 'ar';

  const [tab, setTab] = useState<Tab>('patient');

  // Patient state
  const [phone, setPhone]           = useState('');
  const [password, setPassword]     = useState('');
  const [showPass, setShowPass]     = useState(false);
  const [patientError, setPatientError] = useState('');

  // Staff state
  const [staffStep, setStaffStep]               = useState<'clinic' | 'role'>('clinic');
  const [selectedClinicId, setSelectedClinicId] = useState('');

  const clinics = clinicStore.getAll().filter(c => c.isActive);

  // ── Doctor multi-clinic selection ─────────────────────────────────────────
  if (pendingDoctorClinics) {
    const doctorClinics = pendingDoctorClinics
      .map(cid => clinicStore.filter(c => c.id === cid)[0])
      .filter(Boolean);
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4" dir={isRTL ? 'rtl' : 'ltr'}>
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <Building2 className="h-10 w-10 text-primary mx-auto mb-2" />
            <CardTitle>{t.multiTitle}</CardTitle>
            <CardDescription>{t.multiDesc}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {doctorClinics.map(clinic => (
              <button
                key={clinic.id}
                onClick={() => { selectClinicForDoctor(clinic.id); navigate('/dashboard'); }}
                className="w-full flex items-center gap-3 p-4 rounded-lg border border-border hover:border-primary hover:bg-primary/5 transition-all text-start"
                data-testid={`clinic-select-${clinic.id}`}
              >
                <Building2 className="h-5 w-5 text-primary shrink-0" />
                <div className="min-w-0 flex-1">
                  <div className="font-medium text-foreground truncate">{isAr ? clinic.nameAr : clinic.name}</div>
                  <div className="text-sm text-muted-foreground truncate">{isAr ? clinic.cityAr : clinic.city}</div>
                </div>
                <ChevronRight className={`h-4 w-4 text-muted-foreground shrink-0 ${isRTL ? 'rotate-180' : ''}`} />
              </button>
            ))}
          </CardContent>
        </Card>
      </div>
    );
  }

  const getRoleAccounts = (clinicId: string) => {
    const roles: { role: UserRole; icon: React.ReactNode; color: string; label: string; description: string }[] = [];
    const clinicUsers = userStore.filter(u => u.clinicId === clinicId && u.isActive);
    if (clinicUsers.find(u => u.role === 'admin'))
      roles.push({ role: 'admin',     icon: <Shield className="h-5 w-5" />,        color: 'text-primary',  label: t.roleAdmin,     description: t.roleAdminDesc });
    if (clinicUsers.find(u => u.role === 'doctor'))
      roles.push({ role: 'doctor',    icon: <Stethoscope className="h-5 w-5" />,   color: 'text-chart-1',  label: t.roleDoctor,    description: t.roleDoctorDesc });
    if (clinicUsers.find(u => u.role === 'reception'))
      roles.push({ role: 'reception', icon: <ClipboardList className="h-5 w-5" />, color: 'text-chart-2',  label: t.roleReception, description: t.roleReceptionDesc });
    return roles;
  };

  const handlePatientLogin = () => {
    setPatientError('');
    if (!phone.trim() || !password) { setPatientError(t.errEmpty); return; }

    // Check password from localStorage before calling loginAsPatient
    const LS_PASS = 'cf_patient_passwords';
    const LS_PTS  = 'cf_registered_patients';
    let passwords: Record<string, string> = {};
    let persisted: { id: string; phone: string; email?: string }[] = [];
    try { passwords = JSON.parse(localStorage.getItem(LS_PASS) || '{}'); } catch {}
    try { persisted = JSON.parse(localStorage.getItem(LS_PTS)  || '[]'); } catch {}

    const ph = phone.trim();
    const match = persisted.find(p => p.phone === ph || (p.email && p.email === ph));
    if (match && passwords[match.id] && passwords[match.id] !== password) {
      setPatientError(isAr ? 'كلمة المرور غير صحيحة.' : 'Incorrect password.');
      return;
    }

    const ok = loginAsPatient(ph);
    if (ok) {
      if (returnDoctor) navigate(`/patient/book?doctor=${returnDoctor}`);
      else navigate('/patient/appointments');
    } else {
      setPatientError(t.errNotFound);
    }
  };

  const handleStaffLogin = (role: UserRole) => {
    login(selectedClinicId, role);
    if (role !== 'doctor') navigate('/dashboard');
  };

  const selectedClinic = clinics.find(c => c.id === selectedClinicId);
  const TABS = [
    { key: 'patient' as Tab, label: t.tabPatient, icon: <User className="h-4 w-4" /> },
    { key: 'staff'   as Tab, label: t.tabStaff,   icon: <Building2 className="h-4 w-4" /> },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-background to-blue-50/30 flex flex-col" dir={isRTL ? 'rtl' : 'ltr'}>
      <header className="border-b border-border bg-card/80 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-3 hover:opacity-80 transition-opacity">
            <img src={logoImg} alt="ClinicFlow" className="h-9 w-9 rounded-lg object-cover" />
            <span className="font-semibold text-foreground hidden sm:inline">ClinicFlow</span>
          </Link>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={() => setLanguage(isAr ? 'en' : 'ar')}>
              {isAr ? 'EN' : 'AR'}
            </Button>
            <Button variant="outline" size="sm" asChild>
              <Link to="/register" className="gap-1.5 flex items-center" data-testid="button-header-register">
                <UserPlus className="h-4 w-4" />
                {t.registerNow}
              </Link>
            </Button>
            <Button variant="ghost" size="sm" asChild>
              <Link to="/" className="gap-2 flex items-center">
                <ArrowLeft className={`h-4 w-4 ${isRTL ? 'rotate-180' : ''}`} />
                {t.backHome}
              </Link>
            </Button>
          </div>
        </div>
      </header>

      <main className="flex-1 flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          <div className="text-center mb-6">
            <h1 className="text-2xl font-bold text-foreground">{t.welcomeBack}</h1>
            <p className="text-muted-foreground mt-1">{t.subtitle}</p>
          </div>

          <div className="flex rounded-lg bg-muted p-1 mb-6 gap-1">
            {TABS.map(tb => (
              <button
                key={tb.key}
                onClick={() => setTab(tb.key)}
                className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-md text-sm font-medium transition-all ${
                  tab === tb.key ? 'bg-background text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground'
                }`}
                data-testid={`tab-${tb.key}`}
              >
                {tb.icon}
                <span>{tb.label}</span>
              </button>
            ))}
          </div>

          {/* ── PATIENT TAB ── */}
          {tab === 'patient' && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="h-5 w-5 text-blue-600" />
                  {t.patientTitle}
                </CardTitle>
                <CardDescription>{t.patientDesc}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Phone */}
                <div className="space-y-1.5">
                  <Label htmlFor="patient-phone">{t.phoneLabel}</Label>
                  <div className="relative">
                    <Smartphone className={`absolute ${isRTL ? 'right-3' : 'left-3'} top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground`} />
                    <Input
                      id="patient-phone"
                      type="tel"
                      className={isRTL ? 'pr-9' : 'pl-9'}
                      placeholder={t.phonePh}
                      autoComplete="tel"
                      value={phone}
                      onChange={e => { setPhone(e.target.value); setPatientError(''); }}
                      onKeyDown={e => e.key === 'Enter' && handlePatientLogin()}
                      data-testid="input-patient-phone"
                    />
                  </div>
                </div>

                {/* Password */}
                <div className="space-y-1.5">
                  <Label htmlFor="patient-pass">{t.passLabel}</Label>
                  <div className="relative">
                    <Lock className={`absolute ${isRTL ? 'right-3' : 'left-3'} top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground`} />
                    <Input
                      id="patient-pass"
                      type={showPass ? 'text' : 'password'}
                      className={isRTL ? 'pr-9 ps-9' : 'pl-9 pr-9'}
                      placeholder={t.passPh}
                      autoComplete="current-password"
                      value={password}
                      onChange={e => { setPassword(e.target.value); setPatientError(''); }}
                      onKeyDown={e => e.key === 'Enter' && handlePatientLogin()}
                      data-testid="input-patient-password"
                    />
                    <button
                      type="button"
                      tabIndex={-1}
                      onMouseDown={e => e.preventDefault()}
                      onClick={() => setShowPass(v => !v)}
                      className={`absolute ${isRTL ? 'left-3' : 'right-3'} top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground`}
                    >
                      {showPass ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </div>

                {patientError && (
                  <p className="text-sm text-destructive bg-destructive/5 border border-destructive/20 rounded px-3 py-2">
                    {patientError}
                  </p>
                )}

                <Button className="w-full" onClick={handlePatientLogin} data-testid="button-patient-login">
                  {t.signIn}
                </Button>

                <Separator />

                <div className="space-y-2 text-center">
                  <p className="text-sm text-muted-foreground">{t.noAccount}</p>
                  <Button variant="outline" className="w-full gap-2" asChild>
                    <Link to="/register?type=patient" data-testid="button-create-account">
                      <UserPlus className="h-4 w-4" />
                      {t.createAccount}
                    </Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* ── CLINIC STAFF TAB ── */}
          {tab === 'staff' && (
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  {staffStep === 'role' && (
                    <button onClick={() => setStaffStep('clinic')} className="p-1 rounded hover:bg-muted transition-colors" data-testid="button-back-clinic">
                      <ArrowLeft className={`h-4 w-4 ${isRTL ? 'rotate-180' : ''}`} />
                    </button>
                  )}
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      <Building2 className="h-5 w-5 text-emerald-600" />
                      {staffStep === 'clinic' ? t.selectClinic : `${t.loginTo} ${isAr ? selectedClinic?.nameAr : selectedClinic?.name}`}
                    </CardTitle>
                    <CardDescription>{staffStep === 'clinic' ? t.selectClinicDesc : t.selectRoleDesc}</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                {staffStep === 'clinic' && clinics.map(clinic => (
                  <button
                    key={clinic.id}
                    onClick={() => { setSelectedClinicId(clinic.id); setStaffStep('role'); }}
                    className="w-full flex items-center gap-3 p-3 rounded-lg border border-border hover:border-primary hover:bg-primary/5 transition-all text-start"
                    data-testid={`staff-clinic-${clinic.id}`}
                  >
                    <div className="h-9 w-9 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                      <Building2 className="h-4 w-4 text-primary" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="font-medium text-foreground text-sm truncate">{isAr ? clinic.nameAr : clinic.name}</div>
                      <div className="text-xs text-muted-foreground truncate">{isAr ? clinic.cityAr : clinic.city}</div>
                    </div>
                    <ChevronRight className={`h-4 w-4 text-muted-foreground shrink-0 ${isRTL ? 'rotate-180' : ''}`} />
                  </button>
                ))}

                {staffStep === 'role' && selectedClinic && getRoleAccounts(selectedClinic.id).map(r => (
                  <button
                    key={r.role}
                    onClick={() => handleStaffLogin(r.role)}
                    className="w-full flex items-center gap-3 p-3 rounded-lg border border-border hover:border-primary hover:bg-primary/5 transition-all text-start"
                    data-testid={`staff-role-${r.role}`}
                  >
                    <div className={`h-9 w-9 rounded-lg bg-muted flex items-center justify-center shrink-0 ${r.color}`}>{r.icon}</div>
                    <div className="min-w-0 flex-1">
                      <div className="font-medium text-foreground text-sm">{r.label}</div>
                      <div className="text-xs text-muted-foreground">{r.description}</div>
                    </div>
                    <ChevronRight className={`h-4 w-4 text-muted-foreground shrink-0 ${isRTL ? 'rotate-180' : ''}`} />
                  </button>
                ))}

                <Separator />
                <p className="text-center text-xs text-muted-foreground">
                  {t.registerClinic}{' '}
                  <Link to="/register?type=clinic" className="text-primary hover:underline font-medium" data-testid="link-register-clinic">
                    {t.registerClinicLink}
                  </Link>
                </p>
              </CardContent>
            </Card>
          )}

          <p className="text-center text-xs text-muted-foreground mt-6">
            {t.terms}{' '}
            <span className="text-primary cursor-pointer hover:underline">{t.termsLink}</span>
            {' '}{t.and}{' '}
            <span className="text-primary cursor-pointer hover:underline">{t.privacyLink}</span>
          </p>
        </div>
      </main>
    </div>
  );
};

export default Login;
