import { RegistrationEntry, RegistrationType } from '@/types';
import { createStore } from './createStore';

// ── localStorage key ──────────────────────────────────────────────────────────
const LS_KEY = 'cf_registrations';

function loadPersistedRegistrations(): RegistrationEntry[] {
  try {
    const raw = localStorage.getItem(LS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch { return []; }
}

function persistRegistration(entry: RegistrationEntry) {
  try {
    const all = loadPersistedRegistrations();
    if (all.some(r => r.id === entry.id)) return;
    localStorage.setItem(LS_KEY, JSON.stringify([...all, entry]));
  } catch { /* graceful */ }
}

// ── Seed data (demo existing registrations) ───────────────────────────────────
const mockRegistrations: RegistrationEntry[] = [
  {
    id: 'reg-seed-1', regNumber: 'DOC-20001', referralCode: 'DOC-20001',
    type: 'doctor', name: 'Dr. Ahmed Hassan', email: 'ahmed@nilemedical.com',
    phone: '01012345678', password: '', specialtyId: 'sp-1', userId: 'u-2',
    createdAt: '2024-01-01T00:00:00.000Z',
  },
  {
    id: 'reg-seed-2', regNumber: 'DOC-20002', referralCode: 'DOC-20002',
    type: 'doctor', name: 'Dr. Sara Ibrahim', email: 'sara@cairohealth.com',
    phone: '01098765432', password: '', specialtyId: 'sp-2', userId: 'u-3',
    createdAt: '2024-01-01T00:00:00.000Z',
  },
  {
    id: 'reg-seed-3', regNumber: 'DOC-20003', referralCode: 'DOC-20003',
    type: 'doctor', name: 'Dr. Omar Farouk', email: 'omar@alexandriacare.com',
    phone: '01023456789', password: '', specialtyId: 'sp-3', userId: 'u-4',
    createdAt: '2024-01-01T00:00:00.000Z',
  },
  {
    id: 'reg-seed-4', regNumber: 'DOC-20004', referralCode: 'DOC-20004',
    type: 'doctor', name: 'Dr. Nour Salah', email: 'nour@nilemedical.com',
    phone: '01056789012', password: '', specialtyId: 'sp-4', userId: 'u-5',
    createdAt: '2024-01-01T00:00:00.000Z',
  },
  {
    id: 'reg-seed-5', regNumber: 'CLN-30001', referralCode: 'CLN-30001',
    type: 'clinic', name: 'Nile Medical Center', clinicName: 'Nile Medical Center',
    email: 'info@nilemedical.com', phone: '0223456789', password: '',
    address: '15 Nile Street, Cairo', city: 'Cairo', adminName: 'Admin Nile',
    userId: 'u-1', createdAt: '2024-01-01T00:00:00.000Z',
  },
];

// ── Merge seed + persisted (no duplicates) ────────────────────────────────────
const persisted = loadPersistedRegistrations();
const allInitial = [
  ...mockRegistrations,
  ...persisted.filter(p => !mockRegistrations.some(m => m.id === p.id)),
];

export const registrationStore = createStore<RegistrationEntry>(allInitial);

const getNextNumber = (type: RegistrationType): string => {
  const prefix = type === 'patient' ? 'PAT' : type === 'doctor' ? 'DOC' : 'CLN';
  const base = type === 'patient' ? 10001 : type === 'doctor' ? 20001 : 30001;
  const all = registrationStore.filter(r => r.type === type);
  const num = base + all.length;
  return `${prefix}-${num}`;
};

const generateReferralCode = (type: RegistrationType, regNumber: string): string => {
  const num = regNumber.split('-')[1];
  const prefix = type === 'patient' ? 'PAT' : type === 'doctor' ? 'DOC' : 'CLN';
  return `${prefix}-${num}`;
};

export const registerUser = (data: Omit<RegistrationEntry, 'id' | 'regNumber' | 'referralCode' | 'createdAt'>): RegistrationEntry => {
  const regNumber = getNextNumber(data.type);
  const referralCode = generateReferralCode(data.type, regNumber);
  const entry: RegistrationEntry = {
    ...data,
    id: `reg-${Date.now()}`,
    regNumber,
    referralCode,
    createdAt: new Date().toISOString(),
  };
  registrationStore.add(entry);
  // ── Persist to localStorage ──
  persistRegistration(entry);
  return entry;
};

export const findByReferralCode = (code: string): RegistrationEntry | undefined =>
  registrationStore.get(r => r.referralCode === code);

export const getRegistrationByEmail = (email: string): RegistrationEntry | undefined =>
  registrationStore.get(r => r.email === email);

export const getRegistrationByUserId = (userId: string): RegistrationEntry | undefined =>
  registrationStore.get(r => r.userId === userId);
