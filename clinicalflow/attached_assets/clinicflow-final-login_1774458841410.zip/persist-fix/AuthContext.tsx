import React, { createContext, useContext, useState, ReactNode } from 'react';
import { UserRole, Patient } from '@/types';
import { userStore } from '@/stores/userStore';
import { patientStore, persistPatient } from '@/stores/patientStore';
import { getClinicsForDoctor } from '@/stores/doctorClinicStore';
import { registrationStore } from '@/stores/registrationStore';

// ── localStorage keys ─────────────────────────────────────────────────────────
const LS_PASS_KEY = 'cf_patient_passwords';

function loadPasswords(): Record<string, string> {
  try {
    const raw = localStorage.getItem(LS_PASS_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch { return {}; }
}

function savePassword(id: string, hash: string) {
  try {
    const all = loadPasswords();
    all[id] = hash;
    localStorage.setItem(LS_PASS_KEY, JSON.stringify(all));
  } catch { /* graceful */ }
}

export interface AuthUser {
  id: string;
  name: string;
  nameAr: string;
  email: string;
  role: UserRole | 'patient' | 'super_admin';
  specialtyId?: string;
  patientId?: string;
  clinicId: string;
}

interface AuthContextType {
  user: AuthUser | null;
  pendingDoctorClinics: string[] | null;
  pendingDoctorUser: AuthUser | null;
  login: (clinicId: string, role: UserRole) => void;
  loginAsSuperAdmin: (password: string) => boolean;
  loginAsPatient: (identifier: string) => boolean;
  registerPatient: (data: { name: string; phone: string; email: string; password: string }) => boolean;
  selectClinicForDoctor: (clinicId: string) => void;
  switchClinic: () => void;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const SUPER_ADMIN_PASSWORD = 'superadmin2024';

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [pendingDoctorClinics, setPendingDoctorClinics] = useState<string[] | null>(null);
  const [pendingDoctorUser, setPendingDoctorUser] = useState<AuthUser | null>(null);

  const login = (clinicId: string, role: UserRole) => {
    const storeUser = userStore.get(u => u.clinicId === clinicId && u.role === role && u.isActive);
    if (storeUser) {
      const authUser: AuthUser = {
        id: storeUser.id,
        name: storeUser.name,
        nameAr: storeUser.nameAr,
        email: storeUser.email,
        role: storeUser.role,
        specialtyId: storeUser.specialtyId,
        clinicId: storeUser.clinicId,
      };

      if (role === 'doctor') {
        const clinicLinks = getClinicsForDoctor(storeUser.id);
        if (clinicLinks.length > 1) {
          setPendingDoctorUser(authUser);
          setPendingDoctorClinics(clinicLinks);
          return;
        }
      }

      setUser(authUser);
    }
  };

  const selectClinicForDoctor = (clinicId: string) => {
    if (!pendingDoctorUser) return;
    const doctorInClinic = userStore.get(u => u.clinicId === clinicId && u.role === 'doctor' && u.isActive);
    const finalUser: AuthUser = {
      ...pendingDoctorUser,
      clinicId,
      specialtyId: doctorInClinic?.specialtyId ?? pendingDoctorUser.specialtyId,
    };
    setUser(finalUser);
    setPendingDoctorClinics(null);
    setPendingDoctorUser(null);
  };

  const switchClinic = () => {
    if (!user || user.role !== 'doctor') return;
    const clinicLinks = getClinicsForDoctor(user.id);
    if (clinicLinks.length > 1) {
      setPendingDoctorUser(user);
      setPendingDoctorClinics(clinicLinks);
      setUser(null);
    }
  };

  const loginAsSuperAdmin = (password: string): boolean => {
    if (password !== SUPER_ADMIN_PASSWORD) return false;
    setUser({
      id: 'super-admin',
      name: 'Super Admin',
      nameAr: 'المدير العام',
      email: 'superadmin@clinicflow.io',
      role: 'super_admin',
      clinicId: 'super',
    });
    return true;
  };

  // Patients are platform-level — no clinic required
  // Checks patientStore first, then registrationStore (newly registered patients)
  const loginAsPatient = (identifier: string): boolean => {
    const trimmed = identifier.trim();
    const lower  = trimmed.toLowerCase();

    // 1. Check patientStore (includes persisted patients loaded from localStorage)
    const patient = patientStore.get(
      p => p.phone === trimmed ||
           (p.email && p.email.toLowerCase() === lower)
    );
    if (patient) {
      setUser({
        id: patient.id, name: patient.name, nameAr: patient.nameAr,
        email: patient.email || '', role: 'patient',
        patientId: patient.id, clinicId: patient.clinicId ?? '',
      });
      return true;
    }

    // 2. Fallback: check registrationStore (patient registered this session)
    const reg = registrationStore.get(
      r => r.type === 'patient' &&
           (r.phone === trimmed || r.email.toLowerCase() === lower)
    );
    if (reg) {
      // Promote to patientStore + persist for future refreshes
      const newPt: Patient = {
        id: `pt-reg-${reg.id}`, name: reg.name, nameAr: reg.name,
        phone: reg.phone, email: reg.email,
        dateOfBirth: '', gender: 'male', createdAt: reg.createdAt,
      };
      const already = patientStore.get(p => p.phone === newPt.phone);
      if (!already) {
        patientStore.add(newPt);
        persistPatient(newPt);
      }
      const final = already ?? newPt;
      setUser({
        id: final.id, name: final.name, nameAr: final.nameAr,
        email: final.email || '', role: 'patient',
        patientId: final.id, clinicId: '',
      });
      return true;
    }

    return false;
  };

  const registerPatient = (data: { name: string; phone: string; email: string; password: string }): boolean => {
    const existing = patientStore.get(p => p.phone === data.phone || (data.email && p.email === data.email));
    if (existing) return false;

    const patient: Patient = {
      id: `pt-${Date.now()}`,
      name: data.name,
      nameAr: data.name,
      phone: data.phone,
      email: data.email,
      dateOfBirth: '',
      gender: 'male',
      createdAt: new Date().toISOString(),
    };
    // Add to in-memory store
    patientStore.add(patient);
    // ── Persist to localStorage so data survives page refresh ──
    persistPatient(patient);
    if (data.password) savePassword(patient.id, data.password);

    setUser({
      id: patient.id,
      name: patient.name,
      nameAr: patient.nameAr,
      email: patient.email || '',
      role: 'patient',
      patientId: patient.id,
      clinicId: '',
    });
    return true;
  };

  const logout = () => {
    setUser(null);
    setPendingDoctorClinics(null);
    setPendingDoctorUser(null);
  };

  return (
    <AuthContext.Provider value={{
      user, pendingDoctorClinics, pendingDoctorUser,
      login, loginAsSuperAdmin, loginAsPatient, registerPatient,
      selectClinicForDoctor, switchClinic, logout,
      isAuthenticated: !!user,
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
