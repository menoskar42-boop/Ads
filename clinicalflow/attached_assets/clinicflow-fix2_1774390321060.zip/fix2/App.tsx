import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { LanguageProvider } from "@/contexts/LanguageContext";
import { AuthProvider, useAuth } from "@/contexts/AuthContext";
import Login from "./pages/Login";
import MainLayout from "./components/MainLayout";
import SuperAdmin from "./pages/SuperAdmin";
import QueueScreen from "./pages/QueueScreen";
import DoctorProfilePage from "./pages/DoctorProfilePage";
import ClinicPublicPage from "./pages/ClinicPublicPage";
import LandingPage from "./pages/LandingPage";
import RegisterPage from "./pages/RegisterPage";
import SearchPage from "./pages/SearchPage";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: { retry: 1, staleTime: 30_000 },
  },
});

// ── Where to send an authenticated user ──────────────────────────────────────
function homeRoute(role: string): string {
  if (role === 'super_admin') return '/super-admin';
  return '/dashboard';
}

// ── Guard for dashboard routes ────────────────────────────────────────────────
const ProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { isAuthenticated, user } = useAuth();
  if (!isAuthenticated) return <Navigate to="/login" replace />;
  // super_admin has its own separate page
  if (user?.role === 'super_admin') return <Navigate to="/super-admin" replace />;
  return <>{children}</>;
};

// ── Main routing tree ─────────────────────────────────────────────────────────
const AppRoutes = () => {
  const { isAuthenticated, user } = useAuth();
  const home = isAuthenticated && user ? homeRoute(user.role) : null;

  return (
    <Routes>
      {/* ── Public / Marketing ── */}
      <Route
        path="/"
        element={home ? <Navigate to={home} replace /> : <LandingPage />}
      />
      <Route path="/search" element={<SearchPage />} />

      {/* ── Auth pages: redirect if already logged in ── */}
      <Route
        path="/login"
        element={home ? <Navigate to={home} replace /> : <Login />}
      />
      <Route
        path="/register"
        element={home ? <Navigate to={home} replace /> : <RegisterPage />}
      />

      {/* ── Public profile pages (SEO / no auth needed) ── */}
      <Route path="/doctor/:doctorId" element={<DoctorProfilePage />} />
      <Route path="/clinic/:clinicId"  element={<ClinicPublicPage />} />

      {/* ── TV queue screen (no auth — for waiting room display) ── */}
      <Route path="/queue-screen" element={<QueueScreen />} />

      {/* ── Super Admin (own standalone page) ── */}
      <Route
        path="/super-admin"
        element={
          isAuthenticated && user?.role === 'super_admin'
            ? <SuperAdmin />
            : <Navigate to="/login" replace />
        }
      />

      {/* ── Authenticated clinic staff (admin / doctor / reception) ── */}
      <Route
        path="/*"
        element={
          <ProtectedRoute>
            <MainLayout />
          </ProtectedRoute>
        }
      />

      <Route path="*" element={<NotFound />} />
    </Routes>
  );
};

const App = () => (
  <QueryClientProvider client={queryClient}>
    <LanguageProvider>
      <AuthProvider>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <AppRoutes />
          </BrowserRouter>
        </TooltipProvider>
      </AuthProvider>
    </LanguageProvider>
  </QueryClientProvider>
);

export default App;
