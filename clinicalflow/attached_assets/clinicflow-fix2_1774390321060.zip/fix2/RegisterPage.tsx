import { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import {
  Stethoscope, Building2, User, CheckCircle, ArrowLeft, Copy, Share2, Gift
} from 'lucide-react';
import { specialtyStore } from '@/stores/specialtyStore';
import { registerUser } from '@/stores/registrationStore';
import { RegistrationEntry } from '@/types';
import logoImg from '@assets/Untitled_design_1772868317886.png';

type RegType = 'patient' | 'doctor' | 'clinic';

interface PatientForm {
  name: string;
  phone: string;
  email: string;
  password: string;
  usedReferralCode?: string;
}

interface DoctorForm {
  name: string;
  phone: string;
  email: string;
  specialtyId: string;
  graduationYear: string;
  password: string;
  usedReferralCode?: string;
}

interface ClinicForm {
  clinicName: string;
  address: string;
  city: string;
  phone: string;
  adminName: string;
  email: string;
  password: string;
  usedReferralCode?: string;
}

const TYPE_CONFIG = {
  patient: {
    icon: <User className="h-5 w-5" />,
    label: 'Patient',
    color: 'bg-blue-50 text-blue-700 border-blue-200',
    activeColor: 'bg-blue-600 text-white border-blue-600',
    prefix: 'PAT',
  },
  doctor: {
    icon: <Stethoscope className="h-5 w-5" />,
    label: 'Doctor',
    color: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    activeColor: 'bg-emerald-600 text-white border-emerald-600',
    prefix: 'DOC',
  },
  clinic: {
    icon: <Building2 className="h-5 w-5" />,
    label: 'Clinic',
    color: 'bg-violet-50 text-violet-700 border-violet-200',
    activeColor: 'bg-violet-600 text-white border-violet-600',
    prefix: 'CLN',
  },
};

const RegisterPage = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [activeType, setActiveType] = useState<RegType>((searchParams.get('type') as RegType) || 'patient');
  const [registered, setRegistered] = useState<RegistrationEntry | null>(null);
  const [copied, setCopied] = useState(false);

  const specialties = specialtyStore.filter((s) => s.isActive);

  const patientForm = useForm<PatientForm>({ defaultValues: { name: '', phone: '', email: '', password: '', usedReferralCode: '' } });
  const doctorForm = useForm<DoctorForm>({ defaultValues: { name: '', phone: '', email: '', specialtyId: '', graduationYear: '', password: '', usedReferralCode: '' } });
  const clinicForm = useForm<ClinicForm>({ defaultValues: { clinicName: '', address: '', city: '', phone: '', adminName: '', email: '', password: '', usedReferralCode: '' } });

  useEffect(() => {
    const t = searchParams.get('type') as RegType;
    if (t && ['patient', 'doctor', 'clinic'].includes(t)) setActiveType(t);
  }, [searchParams]);

  const onPatientSubmit = (data: PatientForm) => {
    const entry = registerUser({
      type: 'patient',
      name: data.name,
      email: data.email,
      phone: data.phone,
      password: data.password,
      usedReferralCode: data.usedReferralCode || undefined,
    });
    setRegistered(entry);
  };

  const onDoctorSubmit = (data: DoctorForm) => {
    const entry = registerUser({
      type: 'doctor',
      name: data.name,
      email: data.email,
      phone: data.phone,
      password: data.password,
      specialtyId: data.specialtyId,
      graduationYear: parseInt(data.graduationYear) || undefined,
      usedReferralCode: data.usedReferralCode || undefined,
    });
    setRegistered(entry);
  };

  const onClinicSubmit = (data: ClinicForm) => {
    const entry = registerUser({
      type: 'clinic',
      name: data.adminName,
      clinicName: data.clinicName,
      email: data.email,
      phone: data.phone,
      password: data.password,
      address: data.address,
      city: data.city,
      adminName: data.adminName,
      usedReferralCode: data.usedReferralCode || undefined,
    });
    setRegistered(entry);
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  // ─── Success Screen ─────────────────────────────────────────────────────────
  if (registered) {
    const referralLink = `https://clinicflow.eg/ref/${registered.referralCode}`;
    return (
      <div className="min-h-screen bg-gradient-to-br from-background to-muted/30 flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardContent className="p-8 text-center">
            <div className="h-16 w-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="h-8 w-8 text-emerald-600" />
            </div>
            <h2 className="text-2xl font-bold text-foreground mb-1">Registration Successful!</h2>
            <p className="text-muted-foreground text-sm mb-6">
              Welcome to ClinicFlow, {registered.name}.
            </p>

            {/* Registration Number */}
            <div className="bg-muted/50 rounded-xl p-4 mb-4">
              <p className="text-xs text-muted-foreground mb-1">Your Registration Number</p>
              <div className="flex items-center justify-center gap-2">
                <span className="text-2xl font-bold text-primary tracking-wider" data-testid="text-reg-number">
                  {registered.regNumber}
                </span>
                <button
                  onClick={() => handleCopy(registered.regNumber)}
                  className="text-muted-foreground hover:text-primary transition-colors"
                  data-testid="button-copy-reg-number"
                >
                  <Copy className="h-4 w-4" />
                </button>
              </div>
              <p className="text-xs text-muted-foreground mt-1">Save this number for future reference</p>
            </div>

            {/* Referral Code */}
            <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 mb-6">
              <div className="flex items-center justify-center gap-1.5 mb-2">
                <Gift className="h-4 w-4 text-amber-600" />
                <p className="text-xs font-semibold text-amber-700">Your Referral Code</p>
              </div>
              <div className="flex items-center justify-center gap-2 mb-2">
                <span className="text-lg font-bold text-amber-700 tracking-widest" data-testid="text-referral-code">
                  {registered.referralCode}
                </span>
                <button
                  onClick={() => handleCopy(registered.referralCode)}
                  className="text-amber-600 hover:text-amber-800 transition-colors"
                  data-testid="button-copy-referral-code"
                >
                  <Copy className="h-4 w-4" />
                </button>
              </div>
              <p className="text-xs text-amber-600 mb-3">Share this link to earn rewards when friends join</p>
              <div className="flex items-center gap-2 bg-white rounded-lg px-3 py-2 border border-amber-200">
                <span className="text-xs text-muted-foreground truncate flex-1">{referralLink}</span>
                <button onClick={() => handleCopy(referralLink)} className="text-amber-600 flex-shrink-0" data-testid="button-copy-referral-link">
                  {copied ? <CheckCircle className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
                </button>
              </div>
            </div>

            {registered.usedReferralCode && (
              <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3 mb-4 text-xs text-emerald-700">
                Referral code <strong>{registered.usedReferralCode}</strong> applied — rewards will be issued after your first activity.
              </div>
            )}

            <div className="flex gap-3 flex-col">
              <Button className="w-full" onClick={() => navigate('/login')} data-testid="button-go-to-login">
                Go to Login
              </Button>
              <Button variant="outline" className="w-full" onClick={() => navigate('/')} data-testid="button-go-to-home">
                Back to Home
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // ─── Registration Form ──────────────────────────────────────────────────────
  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-muted/30">
      {/* Minimal nav */}
      <div className="border-b bg-white/95 backdrop-blur">
        <div className="max-w-3xl mx-auto px-4 h-14 flex items-center justify-between">
          <button onClick={() => navigate('/')} className="flex items-center gap-2" data-testid="link-logo-home">
            <img src={logoImg} alt="ClinicFlow" className="h-7 w-7 rounded-lg" />
            <span className="font-bold text-foreground">ClinicFlow</span>
          </button>
          <button onClick={() => navigate('/')} className="text-sm text-muted-foreground hover:text-foreground flex items-center gap-1" data-testid="button-back-to-home">
            <ArrowLeft className="h-4 w-4" />
            Back to Home
          </button>
        </div>
      </div>

      <div className="max-w-xl mx-auto px-4 py-10">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Create Your Account</h1>
          <p className="text-muted-foreground text-sm">Join thousands of patients, doctors, and clinics on ClinicFlow</p>
        </div>

        {/* Type Tabs */}
        <div className="flex gap-3 mb-6">
          {(Object.keys(TYPE_CONFIG) as RegType[]).map((type) => {
            const cfg = TYPE_CONFIG[type];
            const isActive = activeType === type;
            return (
              <button
                key={type}
                className={`flex-1 flex flex-col items-center gap-1.5 py-3 px-2 rounded-xl border-2 transition-all ${isActive ? cfg.activeColor : cfg.color}`}
                onClick={() => setActiveType(type)}
                data-testid={`tab-register-${type}`}
              >
                {cfg.icon}
                <span className="text-xs font-semibold">{cfg.label}</span>
              </button>
            );
          })}
        </div>

        <Card>
          <CardHeader className="pb-4">
            <CardTitle className="text-lg">
              {TYPE_CONFIG[activeType].label} Registration
            </CardTitle>
            <CardDescription>
              Your unique registration number will be generated automatically (e.g., {TYPE_CONFIG[activeType].prefix}-10001)
            </CardDescription>
          </CardHeader>
          <CardContent>

            {/* ─── Patient Form ─────────────────────────────────── */}
            {activeType === 'patient' && (
              <form onSubmit={patientForm.handleSubmit(onPatientSubmit)} className="space-y-4">
                <div className="space-y-1.5">
                  <Label htmlFor="p-name">Full Name *</Label>
                  <Input id="p-name" placeholder="Ahmed Mohamed" {...patientForm.register('name', { required: true })} data-testid="input-patient-name" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="p-phone">Phone Number *</Label>
                  <Input id="p-phone" placeholder="+20 1XX XXX XXXX" {...patientForm.register('phone', { required: true })} data-testid="input-patient-phone" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="p-email">Email *</Label>
                  <Input id="p-email" type="email" placeholder="ahmed@email.com" {...patientForm.register('email', { required: true })} data-testid="input-patient-email" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="p-password">Password *</Label>
                  <Input id="p-password" type="password" placeholder="Create a password" {...patientForm.register('password', { required: true, minLength: 6 })} data-testid="input-patient-password" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="p-ref" className="flex items-center gap-1.5">
                    <Gift className="h-3.5 w-3.5 text-amber-500" />
                    Referral Code (optional)
                  </Label>
                  <Input id="p-ref" placeholder="e.g. PAT-10001" {...patientForm.register('usedReferralCode')} data-testid="input-patient-referral" />
                </div>
                <Button type="submit" className="w-full" data-testid="button-patient-submit">
                  Create Patient Account
                </Button>
              </form>
            )}

            {/* ─── Doctor Form ──────────────────────────────────── */}
            {activeType === 'doctor' && (
              <form onSubmit={doctorForm.handleSubmit(onDoctorSubmit)} className="space-y-4">
                <div className="space-y-1.5">
                  <Label htmlFor="d-name">Full Name *</Label>
                  <Input id="d-name" placeholder="Dr. Sarah Hassan" {...doctorForm.register('name', { required: true })} data-testid="input-doctor-name" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="d-phone">Phone Number *</Label>
                  <Input id="d-phone" placeholder="+20 1XX XXX XXXX" {...doctorForm.register('phone', { required: true })} data-testid="input-doctor-phone" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="d-email">Email *</Label>
                  <Input id="d-email" type="email" placeholder="doctor@email.com" {...doctorForm.register('email', { required: true })} data-testid="input-doctor-email" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="d-spec">Specialty *</Label>
                  <Select
                    onValueChange={(v) => doctorForm.setValue('specialtyId', v)}
                    defaultValue=""
                  >
                    <SelectTrigger id="d-spec" data-testid="select-doctor-specialty">
                      <SelectValue placeholder="Select your specialty" />
                    </SelectTrigger>
                    <SelectContent>
                      {specialties.map((s) => (
                        <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="d-grad">Graduation Year *</Label>
                  <Input id="d-grad" type="number" placeholder="2015" min={1970} max={new Date().getFullYear()} {...doctorForm.register('graduationYear', { required: true })} data-testid="input-doctor-grad-year" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="d-password">Password *</Label>
                  <Input id="d-password" type="password" placeholder="Create a password" {...doctorForm.register('password', { required: true, minLength: 6 })} data-testid="input-doctor-password" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="d-ref" className="flex items-center gap-1.5">
                    <Gift className="h-3.5 w-3.5 text-amber-500" />
                    Referral Code (optional)
                  </Label>
                  <Input id="d-ref" placeholder="e.g. DOC-20001" {...doctorForm.register('usedReferralCode')} data-testid="input-doctor-referral" />
                </div>
                <Button type="submit" className="w-full" data-testid="button-doctor-submit">
                  Create Doctor Account
                </Button>
              </form>
            )}

            {/* ─── Clinic Form ──────────────────────────────────── */}
            {activeType === 'clinic' && (
              <form onSubmit={clinicForm.handleSubmit(onClinicSubmit)} className="space-y-4">
                <div className="space-y-1.5">
                  <Label htmlFor="c-name">Clinic Name *</Label>
                  <Input id="c-name" placeholder="Al Salam Medical Center" {...clinicForm.register('clinicName', { required: true })} data-testid="input-clinic-name" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="c-address">Address *</Label>
                  <Input id="c-address" placeholder="12 Tahrir Square, Cairo" {...clinicForm.register('address', { required: true })} data-testid="input-clinic-address" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="c-city">City *</Label>
                  <Input id="c-city" placeholder="Cairo" {...clinicForm.register('city', { required: true })} data-testid="input-clinic-city" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="c-phone">Phone Number *</Label>
                  <Input id="c-phone" placeholder="+20 2 XXXX XXXX" {...clinicForm.register('phone', { required: true })} data-testid="input-clinic-phone" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="c-admin">Clinic Admin Name *</Label>
                  <Input id="c-admin" placeholder="Dr. Khaled Ibrahim" {...clinicForm.register('adminName', { required: true })} data-testid="input-clinic-admin" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="c-email">Email *</Label>
                  <Input id="c-email" type="email" placeholder="admin@clinic.com" {...clinicForm.register('email', { required: true })} data-testid="input-clinic-email" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="c-password">Password *</Label>
                  <Input id="c-password" type="password" placeholder="Create a password" {...clinicForm.register('password', { required: true, minLength: 6 })} data-testid="input-clinic-password" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="c-ref" className="flex items-center gap-1.5">
                    <Gift className="h-3.5 w-3.5 text-amber-500" />
                    Referral Code (optional)
                  </Label>
                  <Input id="c-ref" placeholder="e.g. CLN-30001" {...clinicForm.register('usedReferralCode')} data-testid="input-clinic-referral" />
                </div>
                <Button type="submit" className="w-full" data-testid="button-clinic-submit">
                  Register Clinic
                </Button>
              </form>
            )}

            <p className="text-center text-sm text-muted-foreground mt-4">
              Already have an account?{' '}
              <button onClick={() => navigate('/login')} className="text-primary hover:underline" data-testid="link-login">
                Login here
              </button>
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default RegisterPage;
