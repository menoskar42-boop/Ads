import React, { useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { UserRole } from '@/types';
import { clinicStore } from '@/stores/clinicStore';
import { userStore } from '@/stores/userStore';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import {
  Shield, Stethoscope, ClipboardList, User, ArrowLeft,
  Building2, Lock, ChevronRight, Smartphone, Eye, EyeOff, UserPlus,
} from 'lucide-react';
import logoImg from '@assets/Untitled_design_1772868317886.png';

type Tab = 'patient' | 'staff' | 'admin';

// ── Translations ──────────────────────────────────────────────────────────────
const T = {
  en: {
    backHome:           'Back to Home',
    registerNow:        'Sign Up',
    welcomeBack:        'Welcome back',
    signInSubtitle:     'Sign in to your ClinicFlow account',
    tabPatient:         'Patient',
    tabStaff:           'Clinic Staff',
    tabAdmin:           'Super Admin',
    patientLoginTitle:  'Patient Login',
    patientLoginDesc:   'Enter your registered phone number or email',
    phonePlaceholder:   '01xxxxxxxxx or email@example.com',
    phoneLabel:         'Phone Number or Email',
    signInBtn:          'Sign In as Patient',
    noAccount:          "Don't have an account?",
    registerLink:       'Register as Patient',
    errorEmpty:         'Please enter your phone or email.',
    errorNotFound:      'No account found. Check your phone/email or register first.',
    selectClinic:       'Select Your Clinic',
    selectClinicDesc:   'Choose the clinic you work in',
    loginTo:            'Login to',
    selectRoleDesc:     'Select your role to continue',
    registerClinic:     'Want to register your clinic?',
    registerClinicLink: 'Register here',
    roleAdmin:          'Admin',
    roleAdminDesc:      'Full system access',
    roleDoctor:         'Doctor',
    roleDoctorDesc:     'Patient care & consultations',
    roleReception:      'Receptionist',
    roleReceptionDesc:  'Front desk operations',
    superAdminTitle:    'Super Admin',
    superAdminDesc:     'Platform-level administration access',
    adminPassLabel:     'Admin Password',
    adminPassPlaceholder: 'Enter admin password',
    adminLoginBtn:      'Access Admin Panel',
    adminError:         'Incorrect password. Please try again.',
    multiClinicTitle:   'Select Your Clinic',
    multiClinicDesc:    'You are registered in multiple clinics. Choose which to enter.',
    terms:              'By signing in you agree to our',
    termsLink:          'Terms of Service',
    and:                'and',
    privacyLink:        'Privacy Policy',
    createAccount:      'Create a Patient Account',
  },
  ar: {
    backHome:           'العودة للرئيسية',
    registerNow:        'سجل الآن',
    welcomeBack:        'مرحباً بعودتك',
    signInSubtitle:     'سجّل دخولك إلى حسابك في ClinicFlow',
    tabPatient:         'مريض',
    tabStaff:           'موظفو العيادة',
    tabAdmin:           'المدير العام',
    patientLoginTitle:  'دخول المرضى',
    patientLoginDesc:   'أدخل رقم هاتفك أو بريدك الإلكتروني المسجّل',
    phonePlaceholder:   '01xxxxxxxxx أو email@example.com',
    phoneLabel:         'رقم الهاتف أو البريد الإلكتروني',
    signInBtn:          'تسجيل الدخول كمريض',
    noAccount:          'ليس لديك حساب؟',
    registerLink:       'سجّل كمريض',
    errorEmpty:         'من فضلك أدخل رقم الهاتف أو البريد الإلكتروني.',
    errorNotFound:      'لم يتم العثور على حساب. تحقق من البيانات أو سجّل أولاً.',
    selectClinic:       'اختر عيادتك',
    selectClinicDesc:   'اختر العيادة التي تعمل فيها',
    loginTo:            'دخول إلى',
    selectRoleDesc:     'اختر دورك للمتابعة',
    registerClinic:     'تريد تسجيل عيادتك؟',
    registerClinicLink: 'سجّل هنا',
    roleAdmin:          'مدير',
    roleAdminDesc:      'صلاحيات كاملة للنظام',
    roleDoctor:         'طبيب',
    roleDoctorDesc:     'رعاية المرضى والاستشارات',
    roleReception:      'موظف استقبال',
    roleReceptionDesc:  'عمليات الاستقبال',
    superAdminTitle:    'المدير العام',
    superAdminDesc:     'إدارة المنصة بالكامل',
    adminPassLabel:     'كلمة مرور الإدارة',
    adminPassPlaceholder: 'أدخل كلمة المرور',
    adminLoginBtn:      'دخول لوحة الإدارة',
    adminError:         'كلمة المرور غير صحيحة. حاول مرة أخرى.',
    multiClinicTitle:   'اختر عيادتك',
    multiClinicDesc:    'أنت مسجّل في أكثر من عيادة. اختر التي تريد الدخول إليها.',
    terms:              'بتسجيل دخولك فأنت توافق على',
    termsLink:          'شروط الخدمة',
    and:                'و',
    privacyLink:        'سياسة الخصوصية',
    createAccount:      'إنشاء حساب مريض',
  },
} as const;

const Login: React.FC = () => {
  const { login, loginAsSuperAdmin, loginAsPatient, pendingDoctorClinics, selectClinicForDoctor } = useAuth();
  const { language, setLanguage, isRTL } = useLanguage();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const returnDoctor = searchParams.get('returnDoctor');

  const t = T[language as 'en' | 'ar'];
  const isAr = language === 'ar';

  const [tab, setTab] = useState<Tab>('patient');
  const [patientId, setPatientId]       = useState('');
  const [patientError, setPatientError] = useState('');
  const [staffStep, setStaffStep]       = useState<'clinic' | 'role'>('clinic');
  const [selectedClinicId, setSelectedClinicId] = useState('');
  const [superPassword, setSuperPassword] = useState('');
  const [superError, setSuperError]       = useState(false);
  const [showSuperPass, setShowSuperPass] = useState(false);

  const clinics = clinicStore.getAll().filter(c => c.isActive);

  // ── Doctor multi-clinic selection ─────────────────────────────────────────
  if (pendingDoctorClinics) {
    const doctorClinics = pendingDoctorClinics
      .map(cid => clinicStore.filter(c => c.id === cid)[0])
      .filter(Boolean);
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4" dir={isRTL ? 'rtl' : 'ltr'}>
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <Building2 className="h-10 w-10 text-primary mx-auto mb-2" />
            <CardTitle>{t.multiClinicTitle}</CardTitle>
            <CardDescription>{t.multiClinicDesc}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {doctorClinics.map(clinic => (
              <button
                key={clinic.id}
                onClick={() => { selectClinicForDoctor(clinic.id); navigate('/dashboard'); }}
                className="w-full flex items-center gap-3 p-4 rounded-lg border border-border hover:border-primary hover:bg-primary/5 transition-all text-start"
                data-testid={`clinic-select-${clinic.id}`}
              >
                <Building2 className="h-5 w-5 text-primary shrink-0" />
                <div className="min-w-0 flex-1">
                  <div className="font-medium text-foreground truncate">
                    {isAr ? clinic.nameAr : clinic.name}
                  </div>
                  <div className="text-sm text-muted-foreground truncate">
                    {isAr ? clinic.cityAr : clinic.city}
                  </div>
                </div>
                <ChevronRight className={`h-4 w-4 text-muted-foreground shrink-0 ${isRTL ? 'rotate-180' : ''}`} />
              </button>
            ))}
          </CardContent>
        </Card>
      </div>
    );
  }

  // ── Helpers ───────────────────────────────────────────────────────────────
  const getRoleAccounts = (clinicId: string) => {
    const roles: { role: UserRole; icon: React.ReactNode; color: string; label: string; description: string }[] = [];
    const clinicUsers = userStore.filter(u => u.clinicId === clinicId && u.isActive);
    if (clinicUsers.find(u => u.role === 'admin'))
      roles.push({ role: 'admin', icon: <Shield className="h-5 w-5" />, color: 'text-primary', label: t.roleAdmin, description: t.roleAdminDesc });
    if (clinicUsers.find(u => u.role === 'doctor'))
      roles.push({ role: 'doctor', icon: <Stethoscope className="h-5 w-5" />, color: 'text-chart-1', label: t.roleDoctor, description: t.roleDoctorDesc });
    if (clinicUsers.find(u => u.role === 'reception'))
      roles.push({ role: 'reception', icon: <ClipboardList className="h-5 w-5" />, color: 'text-chart-2', label: t.roleReception, description: t.roleReceptionDesc });
    return roles;
  };

  const handlePatientLogin = () => {
    setPatientError('');
    if (!patientId.trim()) { setPatientError(t.errorEmpty); return; }
    const ok = loginAsPatient(patientId);
    if (ok) {
      if (returnDoctor) navigate(`/patient/book?doctor=${returnDoctor}`);
      else navigate('/patient/appointments');
    } else {
      setPatientError(t.errorNotFound);
    }
  };

  const handleStaffLogin = (role: UserRole) => {
    login(selectedClinicId, role);
    if (role !== 'doctor') navigate('/dashboard');
  };

  const handleSuperAdmin = () => {
    const ok = loginAsSuperAdmin(superPassword);
    if (ok) navigate('/super-admin');
    else { setSuperError(true); setSuperPassword(''); }
  };

  const selectedClinic = clinics.find(c => c.id === selectedClinicId);

  const TABS = [
    { key: 'patient' as Tab, label: t.tabPatient,  icon: <User className="h-4 w-4" /> },
    { key: 'staff'   as Tab, label: t.tabStaff,    icon: <Building2 className="h-4 w-4" /> },
    { key: 'admin'   as Tab, label: t.tabAdmin,    icon: <Shield className="h-4 w-4" /> },
  ];

  // ── Render ────────────────────────────────────────────────────────────────
  return (
    <div
      className="min-h-screen bg-gradient-to-br from-blue-50 via-background to-blue-50/30 flex flex-col"
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      {/* Header */}
      <header className="border-b border-border bg-card/80 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-3 hover:opacity-80 transition-opacity">
            <img src={logoImg} alt="ClinicFlow" className="h-9 w-9 rounded-lg object-cover" />
            <span className="font-semibold text-foreground hidden sm:inline">ClinicFlow</span>
          </Link>
          <div className="flex items-center gap-2">
            {/* Language toggle */}
            <Button
              variant="outline" size="sm"
              onClick={() => setLanguage(isAr ? 'en' : 'ar')}
              data-testid="button-toggle-lang"
            >
              {isAr ? 'EN' : 'AR'}
            </Button>
            {/* Sign Up */}
            <Button variant="outline" size="sm" asChild>
              <Link to="/register" className="gap-1.5 flex items-center" data-testid="button-header-register">
                <UserPlus className="h-4 w-4" />
                {t.registerNow}
              </Link>
            </Button>
            <Button variant="ghost" size="sm" asChild>
              <Link to="/" className="gap-2 flex items-center">
                <ArrowLeft className={`h-4 w-4 ${isRTL ? 'rotate-180' : ''}`} />
                {t.backHome}
              </Link>
            </Button>
          </div>
        </div>
      </header>

      {/* Main */}
      <main className="flex-1 flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          <div className="text-center mb-6">
            <h1 className="text-2xl font-bold text-foreground">{t.welcomeBack}</h1>
            <p className="text-muted-foreground mt-1">{t.signInSubtitle}</p>
          </div>

          {/* Tabs */}
          <div className="flex rounded-lg bg-muted p-1 mb-6 gap-1">
            {TABS.map(tab_ => (
              <button
                key={tab_.key}
                onClick={() => setTab(tab_.key)}
                className={`flex-1 flex items-center justify-center gap-1.5 py-2 px-2 rounded-md text-sm font-medium transition-all ${
                  tab === tab_.key
                    ? 'bg-background text-foreground shadow-sm'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
                data-testid={`tab-${tab_.key}`}
              >
                {tab_.icon}
                <span className="hidden sm:inline">{tab_.label}</span>
              </button>
            ))}
          </div>

          {/* ── PATIENT TAB ── */}
          {tab === 'patient' && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="h-5 w-5 text-blue-600" />
                  {t.patientLoginTitle}
                </CardTitle>
                <CardDescription>{t.patientLoginDesc}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="patient-id">{t.phoneLabel}</Label>
                  <div className="relative">
                    <Smartphone className={`absolute ${isRTL ? 'right-3' : 'left-3'} top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground`} />
                    <Input
                      id="patient-id"
                      className={isRTL ? 'pr-9 text-right' : 'pl-9'}
                      placeholder={t.phonePlaceholder}
                      value={patientId}
                      onChange={e => { setPatientId(e.target.value); setPatientError(''); }}
                      onKeyDown={e => e.key === 'Enter' && handlePatientLogin()}
                      data-testid="input-patient-identifier"
                    />
                  </div>
                  {patientError && <p className="text-sm text-destructive">{patientError}</p>}
                </div>

                <Button className="w-full" onClick={handlePatientLogin} data-testid="button-patient-login">
                  {t.signInBtn}
                </Button>

                <Separator />

                <div className="space-y-2 text-center">
                  <p className="text-sm text-muted-foreground">{t.noAccount}</p>
                  <Button variant="outline" className="w-full gap-2" asChild>
                    <Link to="/register?type=patient" data-testid="button-create-account">
                      <UserPlus className="h-4 w-4" />
                      {t.createAccount}
                    </Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* ── CLINIC STAFF TAB ── */}
          {tab === 'staff' && (
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  {staffStep === 'role' && (
                    <button
                      onClick={() => setStaffStep('clinic')}
                      className="p-1 rounded hover:bg-muted transition-colors"
                      data-testid="button-back-clinic"
                    >
                      <ArrowLeft className={`h-4 w-4 ${isRTL ? 'rotate-180' : ''}`} />
                    </button>
                  )}
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      <Building2 className="h-5 w-5 text-emerald-600" />
                      {staffStep === 'clinic'
                        ? t.selectClinic
                        : `${t.loginTo} ${isAr ? selectedClinic?.nameAr : selectedClinic?.name}`}
                    </CardTitle>
                    <CardDescription>
                      {staffStep === 'clinic' ? t.selectClinicDesc : t.selectRoleDesc}
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                {staffStep === 'clinic' && clinics.map(clinic => (
                  <button
                    key={clinic.id}
                    onClick={() => { setSelectedClinicId(clinic.id); setStaffStep('role'); }}
                    className="w-full flex items-center gap-3 p-3 rounded-lg border border-border hover:border-primary hover:bg-primary/5 transition-all text-start"
                    data-testid={`staff-clinic-${clinic.id}`}
                  >
                    <div className="h-9 w-9 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                      <Building2 className="h-4 w-4 text-primary" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="font-medium text-foreground text-sm truncate">
                        {isAr ? clinic.nameAr : clinic.name}
                      </div>
                      <div className="text-xs text-muted-foreground truncate">
                        {isAr ? clinic.cityAr : clinic.city} · {isAr ? clinic.addressAr : clinic.address}
                      </div>
                    </div>
                    <ChevronRight className={`h-4 w-4 text-muted-foreground shrink-0 ${isRTL ? 'rotate-180' : ''}`} />
                  </button>
                ))}

                {staffStep === 'role' && selectedClinic && getRoleAccounts(selectedClinic.id).map(r => (
                  <button
                    key={r.role}
                    onClick={() => handleStaffLogin(r.role)}
                    className="w-full flex items-center gap-3 p-3 rounded-lg border border-border hover:border-primary hover:bg-primary/5 transition-all text-start"
                    data-testid={`staff-role-${r.role}`}
                  >
                    <div className={`h-9 w-9 rounded-lg bg-muted flex items-center justify-center shrink-0 ${r.color}`}>
                      {r.icon}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="font-medium text-foreground text-sm">{r.label}</div>
                      <div className="text-xs text-muted-foreground">{r.description}</div>
                    </div>
                    <ChevronRight className={`h-4 w-4 text-muted-foreground shrink-0 ${isRTL ? 'rotate-180' : ''}`} />
                  </button>
                ))}

                <Separator />
                <p className="text-center text-xs text-muted-foreground">
                  {t.registerClinic}{' '}
                  <Link to="/register?type=clinic" className="text-primary hover:underline font-medium" data-testid="link-register-clinic">
                    {t.registerClinicLink}
                  </Link>
                </p>
              </CardContent>
            </Card>
          )}

          {/* ── SUPER ADMIN TAB ── */}
          {tab === 'admin' && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="h-5 w-5 text-violet-600" />
                  {t.superAdminTitle}
                </CardTitle>
                <CardDescription>{t.superAdminDesc}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="super-password">{t.adminPassLabel}</Label>
                  <div className="relative">
                    <Lock className={`absolute ${isRTL ? 'right-3' : 'left-3'} top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground`} />
                    <Input
                      id="super-password"
                      type={showSuperPass ? 'text' : 'password'}
                      className={isRTL ? 'pr-9 ps-9' : 'pl-9 pr-9'}
                      placeholder={t.adminPassPlaceholder}
                      value={superPassword}
                      onChange={e => { setSuperPassword(e.target.value); setSuperError(false); }}
                      onKeyDown={e => e.key === 'Enter' && handleSuperAdmin()}
                      data-testid="input-admin-password"
                    />
                    <button
                      type="button"
                      onClick={() => setShowSuperPass(v => !v)}
                      className={`absolute ${isRTL ? 'left-3' : 'right-3'} top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground`}
                    >
                      {showSuperPass ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                  {superError && <p className="text-sm text-destructive">{t.adminError}</p>}
                </div>
                <Button
                  className="w-full bg-violet-600 hover:bg-violet-700"
                  onClick={handleSuperAdmin}
                  data-testid="button-admin-login"
                >
                  {t.adminLoginBtn}
                </Button>
              </CardContent>
            </Card>
          )}

          <p className="text-center text-xs text-muted-foreground mt-6">
            {t.terms}{' '}
            <span className="text-primary cursor-pointer hover:underline">{t.termsLink}</span>
            {' '}{t.and}{' '}
            <span className="text-primary cursor-pointer hover:underline">{t.privacyLink}</span>
          </p>
        </div>
      </main>
    </div>
  );
};

export default Login;
