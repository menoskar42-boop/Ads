import React, { createContext, useContext, useState, ReactNode } from 'react';
import { UserRole, Patient } from '@/types';
import { userStore } from '@/stores/userStore';
import { patientStore } from '@/stores/patientStore';
import { getClinicsForDoctor } from '@/stores/doctorClinicStore';
import { registrationStore } from '@/stores/registrationStore';

export interface AuthUser {
  id: string;
  name: string;
  nameAr: string;
  email: string;
  role: UserRole | 'patient' | 'super_admin';
  specialtyId?: string;
  patientId?: string;
  clinicId: string;
}

interface AuthContextType {
  user: AuthUser | null;
  pendingDoctorClinics: string[] | null;
  pendingDoctorUser: AuthUser | null;
  login: (clinicId: string, role: UserRole) => void;
  loginAsSuperAdmin: (password: string) => boolean;
  loginAsPatient: (identifier: string) => boolean;
  registerPatient: (data: { name: string; phone: string; email: string; password: string }) => boolean;
  selectClinicForDoctor: (clinicId: string) => void;
  switchClinic: () => void;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const SUPER_ADMIN_PASSWORD = 'superadmin2024';

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [pendingDoctorClinics, setPendingDoctorClinics] = useState<string[] | null>(null);
  const [pendingDoctorUser, setPendingDoctorUser] = useState<AuthUser | null>(null);

  const login = (clinicId: string, role: UserRole) => {
    const storeUser = userStore.get(u => u.clinicId === clinicId && u.role === role && u.isActive);
    if (storeUser) {
      const authUser: AuthUser = {
        id: storeUser.id,
        name: storeUser.name,
        nameAr: storeUser.nameAr,
        email: storeUser.email,
        role: storeUser.role,
        specialtyId: storeUser.specialtyId,
        clinicId: storeUser.clinicId,
      };
      if (role === 'doctor') {
        const clinicLinks = getClinicsForDoctor(storeUser.id);
        if (clinicLinks.length > 1) {
          setPendingDoctorUser(authUser);
          setPendingDoctorClinics(clinicLinks);
          return;
        }
      }
      setUser(authUser);
    }
  };

  const selectClinicForDoctor = (clinicId: string) => {
    if (!pendingDoctorUser) return;
    const doctorInClinic = userStore.get(u => u.clinicId === clinicId && u.role === 'doctor' && u.isActive);
    setUser({
      ...pendingDoctorUser,
      clinicId,
      specialtyId: doctorInClinic?.specialtyId ?? pendingDoctorUser.specialtyId,
    });
    setPendingDoctorClinics(null);
    setPendingDoctorUser(null);
  };

  const switchClinic = () => {
    if (!user || user.role !== 'doctor') return;
    const clinicLinks = getClinicsForDoctor(user.id);
    if (clinicLinks.length > 1) {
      setPendingDoctorUser(user);
      setPendingDoctorClinics(clinicLinks);
      setUser(null);
    }
  };

  const loginAsSuperAdmin = (password: string): boolean => {
    if (password !== SUPER_ADMIN_PASSWORD) return false;
    setUser({
      id: 'super-admin',
      name: 'Super Admin',
      nameAr: 'المدير العام',
      email: 'superadmin@clinicflow.io',
      role: 'super_admin',
      clinicId: 'super',
    });
    return true;
  };

  const loginAsPatient = (identifier: string): boolean => {
    const trimmed = identifier.trim();

    // 1. Search patientStore (existing + demo patients)
    const patient = patientStore.get(
      p => p.phone === trimmed || (p.email && p.email === trimmed)
    );
    if (patient) {
      setUser({
        id: patient.id,
        name: patient.name,
        nameAr: patient.nameAr,
        email: patient.email || '',
        role: 'patient',
        patientId: patient.id,
        clinicId: patient.clinicId ?? '',
      });
      return true;
    }

    // 2. Fallback: search registrationStore (patients registered via RegisterPage)
    const reg = registrationStore.get(
      r => r.type === 'patient' && (r.phone === trimmed || r.email === trimmed)
    );
    if (reg) {
      // Promote to patientStore so future logins skip this step
      const newPatient: Patient = {
        id:          `pt-reg-${reg.id}`,
        name:        reg.name,
        nameAr:      reg.name,
        phone:       reg.phone,
        email:       reg.email,
        dateOfBirth: '',
        gender:      'male',
        createdAt:   reg.createdAt,
      };
      const alreadyAdded = patientStore.get(p => p.phone === newPatient.phone);
      if (!alreadyAdded) patientStore.add(newPatient);
      const finalPatient = alreadyAdded ?? newPatient;
      setUser({
        id:        finalPatient.id,
        name:      finalPatient.name,
        nameAr:    finalPatient.nameAr,
        email:     finalPatient.email || '',
        role:      'patient',
        patientId: finalPatient.id,
        clinicId:  '',
      });
      return true;
    }

    return false;
  };

  const registerPatient = (data: { name: string; phone: string; email: string; password: string }): boolean => {
    const existing = patientStore.get(p => p.phone === data.phone || (data.email && p.email === data.email));
    if (existing) return false;
    const patient: Patient = {
      id:          `pt-${Date.now()}`,
      name:        data.name,
      nameAr:      data.name,
      phone:       data.phone,
      email:       data.email,
      dateOfBirth: '',
      gender:      'male',
      createdAt:   new Date().toISOString(),
    };
    patientStore.add(patient);
    setUser({
      id:        patient.id,
      name:      patient.name,
      nameAr:    patient.nameAr,
      email:     patient.email || '',
      role:      'patient',
      patientId: patient.id,
      clinicId:  '',
    });
    return true;
  };

  const logout = () => {
    setUser(null);
    setPendingDoctorClinics(null);
    setPendingDoctorUser(null);
  };

  return (
    <AuthContext.Provider value={{
      user, pendingDoctorClinics, pendingDoctorUser,
      login, loginAsSuperAdmin, loginAsPatient, registerPatient,
      selectClinicForDoctor, switchClinic, logout,
      isAuthenticated: !!user,
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within an AuthProvider');
  return context;
};
