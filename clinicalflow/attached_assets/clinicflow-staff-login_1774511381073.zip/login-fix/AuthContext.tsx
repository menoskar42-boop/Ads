import React, { createContext, useContext, useState, ReactNode } from 'react';
import { UserRole, Patient } from '@/types';
import { userStore } from '@/stores/userStore';
import { patientStore } from '@/stores/patientStore';
import { getClinicsForDoctor } from '@/stores/doctorClinicStore';

export interface AuthUser {
  id: string;
  name: string;
  nameAr: string;
  email: string;
  role: UserRole | 'patient' | 'super_admin';
  specialtyId?: string;
  patientId?: string;
  clinicId: string;
}

interface AuthContextType {
  user: AuthUser | null;
  pendingDoctorClinics: string[] | null;
  pendingDoctorUser: AuthUser | null;
  login: (clinicId: string, role: UserRole) => void;
  loginStaff: (email: string, password: string) => { ok: boolean; error?: string };
  loginAsSuperAdmin: (password: string) => boolean;
  loginAsPatient: (identifier: string) => boolean;
  registerPatient: (data: { name: string; phone: string; email: string; password: string }) => boolean;
  selectClinicForDoctor: (clinicId: string) => void;
  switchClinic: () => void;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const SUPER_ADMIN_PASSWORD = 'superadmin2024';

// Staff passwords by userId
const STAFF_PASSWORDS: Record<string, string> = {
  'u-1':  'admin123',     // admin@clinic.demo      — Nile admin
  'u-2':  'doctor123',    // ahmed@clinic.demo       — Nile doctor
  'u-3':  'doctor123',    // sarah@clinic.demo       — Nile doctor
  'u-4':  'doctor123',    // omar@clinic.demo        — Nile doctor
  'u-5':  'doctor123',    // lisa@clinic.demo        — Nile doctor
  'u-6':  'reception123', // reception@clinic.demo   — Nile reception
  'u-10': 'admin123',     // admin@cairo.demo        — Cairo admin
  'u-11': 'doctor123',    // doctor@cairo.demo       — Cairo doctor
  'u-12': 'reception123', // reception@cairo.demo    — Cairo reception
  'u-20': 'admin123',     // admin@alex.demo         — Alex admin
  'u-21': 'doctor123',    // doctor@alex.demo        — Alex doctor
  'u-22': 'reception123', // reception@alex.demo     — Alex reception
};

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [pendingDoctorClinics, setPendingDoctorClinics] = useState<string[] | null>(null);
  const [pendingDoctorUser, setPendingDoctorUser] = useState<AuthUser | null>(null);

  const login = (clinicId: string, role: UserRole) => {
    const storeUser = userStore.get(u => u.clinicId === clinicId && u.role === role && u.isActive);
    if (storeUser) {
      const authUser: AuthUser = {
        id: storeUser.id,
        name: storeUser.name,
        nameAr: storeUser.nameAr,
        email: storeUser.email,
        role: storeUser.role,
        specialtyId: storeUser.specialtyId,
        clinicId: storeUser.clinicId,
      };

      if (role === 'doctor') {
        const clinicLinks = getClinicsForDoctor(storeUser.id);
        if (clinicLinks.length > 1) {
          setPendingDoctorUser(authUser);
          setPendingDoctorClinics(clinicLinks);
          return;
        }
      }

      setUser(authUser);
    }
  };

  // Staff login by email + password
  const loginStaff = (email: string, password: string): { ok: boolean; error?: string } => {
    const e = email.trim().toLowerCase();
    const staffUser = userStore.get(u => u.email.toLowerCase() === e && u.isActive);
    if (!staffUser) {
      return { ok: false, error: 'لم يتم العثور على حساب بهذا البريد الإلكتروني.' };
    }
    const expected = STAFF_PASSWORDS[staffUser.id];
    if (expected && expected !== password) {
      return { ok: false, error: 'كلمة المرور غير صحيحة.' };
    }
    const authUser: AuthUser = {
      id: staffUser.id, name: staffUser.name, nameAr: staffUser.nameAr,
      email: staffUser.email, role: staffUser.role,
      specialtyId: staffUser.specialtyId, clinicId: staffUser.clinicId,
    };
    if (staffUser.role === 'doctor') {
      const clinicLinks = getClinicsForDoctor(staffUser.id);
      if (clinicLinks.length > 1) {
        setPendingDoctorUser(authUser);
        setPendingDoctorClinics(clinicLinks);
        return { ok: true };
      }
    }
    setUser(authUser);
    return { ok: true };
  }; = (clinicId: string) => {
    if (!pendingDoctorUser) return;
    const doctorInClinic = userStore.get(u => u.clinicId === clinicId && u.role === 'doctor' && u.isActive);
    const finalUser: AuthUser = {
      ...pendingDoctorUser,
      clinicId,
      specialtyId: doctorInClinic?.specialtyId ?? pendingDoctorUser.specialtyId,
    };
    setUser(finalUser);
    setPendingDoctorClinics(null);
    setPendingDoctorUser(null);
  };

  const switchClinic = () => {
    if (!user || user.role !== 'doctor') return;
    const clinicLinks = getClinicsForDoctor(user.id);
    if (clinicLinks.length > 1) {
      setPendingDoctorUser(user);
      setPendingDoctorClinics(clinicLinks);
      setUser(null);
    }
  };

  const loginAsSuperAdmin = (password: string): boolean => {
    if (password !== SUPER_ADMIN_PASSWORD) return false;
    setUser({
      id: 'super-admin',
      name: 'Super Admin',
      nameAr: 'المدير العام',
      email: 'superadmin@clinicflow.io',
      role: 'super_admin',
      clinicId: 'super',
    });
    return true;
  };

  // Patients are platform-level — no clinic required
  const loginAsPatient = (identifier: string): boolean => {
    const trimmed = identifier.trim();
    const patient = patientStore.get(p => p.phone === trimmed || (p.email && p.email === trimmed));
    if (!patient) return false;
    setUser({
      id: patient.id,
      name: patient.name,
      nameAr: patient.nameAr,
      email: patient.email || '',
      role: 'patient',
      patientId: patient.id,
      clinicId: patient.clinicId ?? '',
    });
    return true;
  };

  const registerPatient = (data: { name: string; phone: string; email: string; password: string }): boolean => {
    const existing = patientStore.get(p => p.phone === data.phone || (data.email && p.email === data.email));
    if (existing) return false;

    const patient: Patient = {
      id: `pt-${Date.now()}`,
      name: data.name,
      nameAr: data.name,
      phone: data.phone,
      email: data.email,
      dateOfBirth: '',
      gender: 'male',
      createdAt: new Date().toISOString(),
    };
    patientStore.add(patient);

    setUser({
      id: patient.id,
      name: patient.name,
      nameAr: patient.nameAr,
      email: patient.email || '',
      role: 'patient',
      patientId: patient.id,
      clinicId: '',
    });
    return true;
  };

  const logout = () => {
    setUser(null);
    setPendingDoctorClinics(null);
    setPendingDoctorUser(null);
  };

  return (
    <AuthContext.Provider value={{
      user, pendingDoctorClinics, pendingDoctorUser,
      login, loginStaff, loginAsSuperAdmin, loginAsPatient, registerPatient,
      selectClinicForDoctor, switchClinic, logout,
      isAuthenticated: !!user,
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
